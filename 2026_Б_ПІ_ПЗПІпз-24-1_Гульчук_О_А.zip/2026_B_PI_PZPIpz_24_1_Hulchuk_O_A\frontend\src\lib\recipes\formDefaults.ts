export const DEFAULT_STEPS = 5;
export const MIN_STEPS = 1;
export const MAX_STEPS = 20;

export function createRowId(): string {
    if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
        return crypto.randomUUID();
    }
    return Math.random().toString(36).slice(2);
}
