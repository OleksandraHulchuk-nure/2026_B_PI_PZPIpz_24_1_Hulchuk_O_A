import { Card } from '@/components/ui/card';
import { Select } from '@/components/ui/select';

import { MEAL_TYPE_LABELS, MEAL_TYPES } from '@/lib/constants/enums';

import type { MealTimePreferencesSectionProps } from './profile.types';

const TIME_OPTIONS = [
    { value: 15, label: 'До 15 хв' },
    { value: 30, label: 'До 30 хв' },
    { value: 45, label: 'До 45 хв' },
    { value: 60, label: 'До 60 хв' },
    { value: 90, label: 'До 90 хв' },
];

export function MealTimePreferencesSection({
    mealTimePrefs,
    onMealTimeChange,
}: MealTimePreferencesSectionProps) {
    return (
        <Card className="flex h-full flex-col gap-5">
            <div className="space-y-1">
                <h3 className="section-title">Максимальний час приготування</h3>
                <p className="section-subtitle">
                    Вкажіть, скільки часу комфортно витрачати на приготування.
                </p>
            </div>

            <div className="grid flex-1 content-start gap-3 sm:grid-cols-2">
                {MEAL_TYPES.map((mealType) => {
                    const preference = mealTimePrefs.find((item) => item.mealType === mealType);
                    const currentValue = preference?.maxCookingTimeMinutes ?? 30;
                    const label = MEAL_TYPE_LABELS[mealType];

                    return (
                        <div
                            key={mealType}
                            className="space-y-2 rounded-2xl border border-border bg-background/70 p-3"
                        >
                            <label className="block text-xs font-semibold uppercase tracking-[0.08em] text-text-muted">
                                {label}
                            </label>

                            <Select
                                value={String(currentValue)}
                                onChange={(event) => onMealTimeChange(mealType, Number(event.target.value))}
                            >
                                {TIME_OPTIONS.map((option) => (
                                    <option key={option.value} value={option.value}>
                                        {option.label}
                                    </option>
                                ))}
                            </Select>
                        </div>
                    );
                })}
            </div>
        </Card>
    );
}
