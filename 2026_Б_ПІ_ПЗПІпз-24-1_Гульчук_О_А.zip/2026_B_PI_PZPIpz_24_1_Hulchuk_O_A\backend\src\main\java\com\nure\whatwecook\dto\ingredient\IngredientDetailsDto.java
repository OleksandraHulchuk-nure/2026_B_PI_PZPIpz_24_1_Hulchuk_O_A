package com.nure.whatwecook.dto.ingredient;

import com.nure.whatwecook.domain.enums.MeasurementUnit;
import com.nure.whatwecook.domain.enums.ProductCategory;
import lombok.Data;

import java.time.Instant;
import java.util.UUID;

@Data
public class IngredientDetailsDto {

    private UUID id;
    private String nameUk;
    private String nameEn;
    private ProductCategory category;
    private MeasurementUnit defaultUnit;
    private Instant createdAt;
    private Instant updatedAt;
}
