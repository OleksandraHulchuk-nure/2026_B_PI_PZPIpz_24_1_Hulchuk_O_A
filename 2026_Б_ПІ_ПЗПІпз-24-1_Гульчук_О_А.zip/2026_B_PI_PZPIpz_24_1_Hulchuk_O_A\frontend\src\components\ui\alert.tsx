'use client';

import {cn} from '@/lib/utils';

type AlertVariant = 'error' | 'success' | 'info' | 'warning';

export interface AlertProps {
    variant?: AlertVariant;
    title?: string;
    children?: React.ReactNode;
    className?: string;
}

const variantClasses: Record<AlertVariant, string> = {
    error: 'border-error/20 bg-error/5 text-error',
    success: 'border-success/20 bg-success/5 text-success',
    info: 'border-accent-info/20 bg-accent-info/5 text-accent-info',
    warning: 'border-warning/20 bg-warning/5 text-warning',
};

export function Alert({
                          variant = 'info',
                          title,
                          children,
                          className,
                      }: AlertProps) {
    return (
        <div
            role="alert"
            className={cn(
                'rounded-lg border px-3 py-2 text-sm',
                variantClasses[variant],
                className,
            )}
        >
            {title && (
                <div className="mb-0.5 font-semibold">
                    {title}
                </div>
            )}
            {children}
        </div>
    );
}
