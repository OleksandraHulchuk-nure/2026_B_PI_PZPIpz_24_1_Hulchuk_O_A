import {apiFetch} from "@/lib/api/apiClient";
import {API_ROUTES} from "@/lib/api/endpoints";
import {MeasurementUnit, ProductCategory} from "@/lib/constants/enums";

export interface ShoppingItemDto {
    id: string;
    ingredientId: string;
    ingredientNameUk: string;
    category: ProductCategory;
    unit: MeasurementUnit;
    neededQuantity: number;
    haveQuantity: number;
}

export interface ShoppingListResponseDto {
    id: string;
    items: ShoppingItemDto[];
    weekStart?: string;
}


export async function generateShoppingListFromWeeklyMenu(weeklyMenuId: string): Promise<ShoppingListResponseDto> {
    return apiFetch<ShoppingListResponseDto>(API_ROUTES.shoppingLists.fromWeeklyMenu, {
        method: 'POST',
        body: JSON.stringify({ weeklyMenuId }),
    });
}

export async function getShoppingList(id: string) {
    return apiFetch<ShoppingListResponseDto>(`${API_ROUTES.shoppingLists.root}/${id}`, { method: 'GET' });
}

export async function getShoppingListByStartDate(startDate: string) {
    return apiFetch<ShoppingListResponseDto>(`${API_ROUTES.shoppingLists.byStartDate}?startDate=${startDate}`, { method: 'GET' });
}

export async function updateHaveQuantities(
    shoppingListId: string,
    items: Array<{ itemId: string; haveQuantity: number }>,
) {
    return apiFetch<ShoppingListResponseDto>(`${API_ROUTES.shoppingLists.root}/${shoppingListId}/items`, {
        method: 'PUT',
        body: JSON.stringify({ items }),
    });
}

export async function updateHaveQuantity(
    shoppingListId: string,
    itemId: string,
    haveQuantity: number,
) {
    return apiFetch<ShoppingListResponseDto>(
        `${API_ROUTES.shoppingLists.root}/${shoppingListId}/items/${itemId}`,
        {
            method: 'PUT',
            body: JSON.stringify({ haveQuantity }),
        },
    );
}

