'use client';

import {RecipeEditorPageClient} from '@/components/recipes/editor/RecipeEditorPageClient';

export function EditRecipePageClient({recipeId}: {recipeId: string}) {
    return <RecipeEditorPageClient mode="edit" recipeId={recipeId}/>;
}
