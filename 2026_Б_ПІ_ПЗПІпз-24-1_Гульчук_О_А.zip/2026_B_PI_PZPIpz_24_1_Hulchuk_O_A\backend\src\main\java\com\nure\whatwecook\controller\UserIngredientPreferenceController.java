package com.nure.whatwecook.controller;

import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.domain.entity.profile.UserIngredientPreference;
import com.nure.whatwecook.domain.enums.IngredientPreferenceType;
import com.nure.whatwecook.dto.ingredient.IngredientShortDto;
import com.nure.whatwecook.dto.preferences.UserIngredientPreferencesResponseDto;
import com.nure.whatwecook.dto.preferences.UserIngredientPreferencesUpdateRequestDto;
import com.nure.whatwecook.mapper.IngredientMapper;
import com.nure.whatwecook.service.UserIngredientPreferenceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@Tag(name = "Ingredient Preferences", description = "User ingredient likes/dislikes/allergies/exclusions")
@RestController
@RequestMapping("/api/preferences/ingredients")
@RequiredArgsConstructor
public class UserIngredientPreferenceController {

    private final CurrentUserProvider currentUserProvider;
    private final UserIngredientPreferenceService userIngredientPreferenceService;
    private final IngredientMapper ingredientMapper;

    @Operation(summary = "Get ingredient preferences of current user")
    @GetMapping
    public ResponseEntity<UserIngredientPreferencesResponseDto> getPreferences() {
        UUID userId = currentUserProvider.getCurrentUserId();
        List<UserIngredientPreference> prefs =
                userIngredientPreferenceService.getUserIngredientPreferences(userId);

        UserIngredientPreferencesResponseDto response = toResponseDto(prefs);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Replace ingredient preferences of current user")
    @PutMapping
    public ResponseEntity<UserIngredientPreferencesResponseDto> updatePreferences(
            @RequestBody UserIngredientPreferencesUpdateRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();

        Map<IngredientPreferenceType, List<UUID>> idsByType = new EnumMap<>(IngredientPreferenceType.class);
        idsByType.put(IngredientPreferenceType.FAVORITE,
                orEmpty(requestDto.getFavoriteIngredientIds()));
        idsByType.put(IngredientPreferenceType.DISLIKED,
                orEmpty(requestDto.getDislikedIngredientIds()));
        idsByType.put(IngredientPreferenceType.ALLERGY,
                orEmpty(requestDto.getAllergyIngredientIds()));
        idsByType.put(IngredientPreferenceType.EXCLUSION,
                orEmpty(requestDto.getExclusionIngredientIds()));

        List<UserIngredientPreference> saved =
                userIngredientPreferenceService.replaceUserIngredientPreferences(userId, idsByType);

        UserIngredientPreferencesResponseDto response = toResponseDto(saved);
        return ResponseEntity.ok(response);
    }

    private List<UUID> orEmpty(List<UUID> ids) {
        return ids != null ? ids : Collections.emptyList();
    }

    private UserIngredientPreferencesResponseDto toResponseDto(List<UserIngredientPreference> prefs) {
        Map<IngredientPreferenceType, List<UserIngredientPreference>> byType = prefs.stream()
                .collect(Collectors.groupingBy(UserIngredientPreference::getPreferenceType));

        UserIngredientPreferencesResponseDto dto = new UserIngredientPreferencesResponseDto();

        dto.setFavorites(toIngredientDtos(byType.get(IngredientPreferenceType.FAVORITE)));
        dto.setDisliked(toIngredientDtos(byType.get(IngredientPreferenceType.DISLIKED)));
        dto.setAllergies(toIngredientDtos(byType.get(IngredientPreferenceType.ALLERGY)));
        dto.setExclusions(toIngredientDtos(byType.get(IngredientPreferenceType.EXCLUSION)));

        return dto;
    }

    private List<IngredientShortDto> toIngredientDtos(List<UserIngredientPreference> prefs) {
        if (prefs == null || prefs.isEmpty()) {
            return Collections.emptyList();
        }
        return ingredientMapper.toShortDtoList(
                prefs.stream()
                        .map(UserIngredientPreference::getIngredient)
                        .collect(Collectors.toList())
        );
    }
}
