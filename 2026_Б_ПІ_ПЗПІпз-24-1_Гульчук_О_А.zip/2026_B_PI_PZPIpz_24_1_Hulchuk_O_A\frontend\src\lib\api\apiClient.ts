import { getAuthToken, clearAuthToken } from '@/lib/auth/tokenStorage';

const API_BASE_URL =
    process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:8080';

export class ApiError extends Error {
    status: number;
    body: unknown;

    constructor(message: string, status: number, body: unknown) {
        super(message);
        this.name = 'ApiError';
        this.status = status;
        this.body = body;
    }
}

function handleUnauthorized() {
    clearAuthToken();

    if (typeof window === 'undefined') return;

    const currentPath = window.location.pathname;
    const isAuthPage =
        currentPath === '/login' ||
        currentPath === '/register' ||
        currentPath.startsWith('/register/');

    if (!isAuthPage) {
        window.location.assign('/login');
    }
}

export interface ApiRequestOptions extends RequestInit {
    auth?: boolean;
}

export async function apiFetch<TResponse>(
    path: string,
    options: ApiRequestOptions = {},
): Promise<TResponse> {
    const { auth = true, headers, ...rest } = options;

    const url =
        path.startsWith('http://') || path.startsWith('https://')
            ? path
            : `${API_BASE_URL}${path}`;

    const finalHeaders = new Headers(headers as HeadersInit | undefined);

    if (auth) {
        const { accessToken, tokenType } = getAuthToken();

        if (!accessToken) {
            handleUnauthorized();
            throw new ApiError('Ви не авторизовані.', 401, null);
        }

        finalHeaders.set('Authorization', `${tokenType || 'Bearer'} ${accessToken}`);
    }

    const hasBody =
        rest.body !== undefined && rest.body !== null && rest.method !== 'GET';

    const isFormData =
        typeof FormData !== 'undefined' && rest.body instanceof FormData;

    if (hasBody && !finalHeaders.has('Content-Type') && !isFormData) {
        finalHeaders.set('Content-Type', 'application/json');
    }

    const response = await fetch(url, {
        ...rest,
        headers: finalHeaders,
        credentials: rest.credentials ?? 'include',
    });

    const text = await response.text();
    let data: unknown = undefined;

    if (text) {
        try {
            data = JSON.parse(text);
        } catch {
            data = text;
        }
    }

    if (!response.ok) {
        let message = 'Сталася помилка при зверненні до сервера.';

        if (
            data &&
            typeof data === 'object' &&
            'message' in data &&
            typeof (data as { message?: unknown }).message === 'string'
        ) {
            message = (data as { message: string }).message;
        } else if (typeof data === 'string' && data.trim().length > 0) {
            message = data;
        }

        if (response.status === 401 || response.status === 403) {
            handleUnauthorized();
        }

        throw new ApiError(message, response.status, data);
    }

    if (!text) {
        return undefined as TResponse;
    }

    return data as TResponse;
}

export async function apiFetchBlob(
    path: string,
    options: ApiRequestOptions = {},
): Promise<Blob> {
    const {auth = true, headers, ...rest} = options;

    const url =
        path.startsWith('http://') || path.startsWith('https://')
            ? path
            : `${API_BASE_URL}${path}`;

    const finalHeaders = new Headers(headers as HeadersInit | undefined);

    if (auth) {
        const {accessToken, tokenType} = getAuthToken();

        if (!accessToken) {
            handleUnauthorized();
            throw new ApiError('Ви не авторизовані.', 401, null);
        }

        finalHeaders.set('Authorization', `${tokenType || 'Bearer'} ${accessToken}`);
    }

    const response = await fetch(url, {
        ...rest,
        headers: finalHeaders,
        credentials: rest.credentials ?? 'include',
    });

    if (!response.ok) {
        const text = await response.text();
        let data: unknown = text;

        try {
            data = text ? JSON.parse(text) : null;
        } catch {
            // ignore JSON parse errors for non-JSON bodies
        }

        let message = 'Сталася помилка при зверненні до сервера.';

        if (
            data &&
            typeof data === 'object' &&
            'message' in data &&
            typeof (data as { message?: unknown }).message === 'string'
        ) {
            message = (data as { message: string }).message;
        } else if (typeof data === 'string' && data.trim().length > 0) {
            message = data;
        }

        if (response.status === 401 || response.status === 403) {
            handleUnauthorized();
        }

        throw new ApiError(message, response.status, data);
    }

    return response.blob();
}

export function buildQuery(params: Record<string, string | number | boolean |undefined | null>): string {
    const usp = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
        if (v === undefined || v === null || v === '') return;
        usp.set(k, String(v));
    });
    const qs = usp.toString();
    return qs ? `?${qs}` : '';
}
