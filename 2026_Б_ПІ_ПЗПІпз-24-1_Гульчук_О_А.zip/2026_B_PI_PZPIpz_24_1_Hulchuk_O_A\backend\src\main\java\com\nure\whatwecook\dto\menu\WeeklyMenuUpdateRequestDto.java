package com.nure.whatwecook.dto.menu;

import lombok.Data;

import java.util.List;

@Data
public class WeeklyMenuUpdateRequestDto {

    private List<MenuDayPlanDto> days;
}
