package com.nure.whatwecook.mapper;

import com.nure.whatwecook.domain.entity.shopping.ShoppingItem;
import com.nure.whatwecook.domain.entity.shopping.ShoppingList;
import com.nure.whatwecook.dto.shopping.ShoppingItemDto;
import com.nure.whatwecook.dto.shopping.ShoppingListResponseDto;
import org.mapstruct.Mapper;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface ShoppingListMapper {

    default ShoppingListResponseDto toDto(ShoppingList entity) {
        if (entity == null) {
            return null;
        }
        ShoppingListResponseDto dto = new ShoppingListResponseDto();
        dto.setId(entity.getId());
        dto.setItems(toItemDtos(entity.getItems()));
        dto.setWeekStart(entity.getWeeklyMenu().getStartDate());
        return dto;
    }

    default List<ShoppingItemDto> toItemDtos(List<ShoppingItem> items) {
        if (items == null || items.isEmpty()) {
            return Collections.emptyList();
        }
        return items.stream()
                .map(this::toItemDto)
                .collect(Collectors.toList());
    }

    default ShoppingItemDto toItemDto(ShoppingItem item) {
        if (item == null) {
            return null;
        }
        ShoppingItemDto dto = new ShoppingItemDto();
        dto.setId(item.getId());
        if (item.getIngredient() != null) {
            dto.setIngredientId(item.getIngredient().getId());
            dto.setIngredientNameUk(item.getIngredient().getNameUk());
            dto.setCategory(item.getIngredient().getCategory());
        }
        dto.setUnit(item.getQuantityUnit());
        dto.setNeededQuantity(item.getNeededQuantity());
        dto.setHaveQuantity(item.getHaveQuantity());
        return dto;
    }
}
