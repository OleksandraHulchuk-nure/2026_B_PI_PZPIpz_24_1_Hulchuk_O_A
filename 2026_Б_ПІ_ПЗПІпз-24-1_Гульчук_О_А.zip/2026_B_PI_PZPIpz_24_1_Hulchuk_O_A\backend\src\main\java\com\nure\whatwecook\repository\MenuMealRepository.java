package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.menu.MenuMeal;
import com.nure.whatwecook.domain.enums.MealType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface MenuMealRepository extends JpaRepository<MenuMeal, UUID> {

    List<MenuMeal> findByMenuDayId(UUID menuDayId);

    Optional<MenuMeal> findByMenuDayIdAndMealType(UUID menuDayId, MealType mealType);
}
