package com.nure.whatwecook.domain.enums;

import lombok.Getter;

@Getter
public enum RecipeStatus {

    TO_VERIFY("Не тестований"),
    VERIFIED("Перевірений"),
    REJECTED("Не сподобалось");

    private final String ukrainianName;

    RecipeStatus(String ukrainianName) {
        this.ukrainianName = ukrainianName;
    }

}
