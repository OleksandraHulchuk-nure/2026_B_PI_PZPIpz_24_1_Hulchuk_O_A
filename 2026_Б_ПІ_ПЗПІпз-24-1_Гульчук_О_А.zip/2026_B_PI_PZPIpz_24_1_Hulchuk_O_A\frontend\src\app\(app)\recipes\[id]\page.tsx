import {RecipeDetailsPageClient} from '@/components/recipes/details/RecipeDetailsPageClient';

export default async function RecipeDetailsPage({
                                                    params,
                                                }: {
    params: Promise<{ id: string }>;
}) {
    const {id} = await params;

    return <RecipeDetailsPageClient recipeId={id}/>;
}
