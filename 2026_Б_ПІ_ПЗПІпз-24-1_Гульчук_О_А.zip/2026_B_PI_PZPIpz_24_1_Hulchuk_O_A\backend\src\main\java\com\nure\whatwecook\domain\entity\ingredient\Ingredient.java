package com.nure.whatwecook.domain.entity.ingredient;

import com.nure.whatwecook.domain.entity.profile.UserIngredientPreference;
import com.nure.whatwecook.domain.enums.MeasurementUnit;
import com.nure.whatwecook.domain.enums.ProductCategory;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "ingredient")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Ingredient {

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private UUID id;

    @Column(name = "name_uk", nullable = false, length = 255)
    private String nameUk;

    @Column(name = "name_en", length = 255)
    private String nameEn;

    @Enumerated(EnumType.STRING)
    @Column(name = "category", nullable = false, length = 50)
    private ProductCategory category;

    @Enumerated(EnumType.STRING)
    @Column(name = "default_unit", nullable = false, length = 32)
    private MeasurementUnit defaultUnit;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @OneToMany(mappedBy = "ingredient", fetch = FetchType.LAZY)
    private List<UserIngredientPreference> userPreferences;

    @PrePersist
    public void prePersist() {
        if (id == null) {
            id = UUID.randomUUID();
        }
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = Instant.now();
    }
}
