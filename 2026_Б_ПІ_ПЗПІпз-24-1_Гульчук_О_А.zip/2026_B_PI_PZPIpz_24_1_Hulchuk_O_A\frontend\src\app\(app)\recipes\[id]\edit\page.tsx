import {EditRecipePageClient} from '@/components/recipes/edit/EditRecipePageClient';

export default async function EditRecipePage({
    params,
}: {
    params: Promise<{id: string}>;
}) {
    const {id} = await params;

    return <EditRecipePageClient recipeId={id}/>;
}
