package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.domain.entity.profile.User;
import com.nure.whatwecook.domain.entity.profile.UserMealPreference;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.repository.UserMealPreferenceRepository;
import com.nure.whatwecook.repository.UserRepository;
import com.nure.whatwecook.service.UserMealPreferenceService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserMealPreferenceServiceImpl implements UserMealPreferenceService {

    private final UserRepository userRepository;
    private final UserMealPreferenceRepository userMealPreferenceRepository;

    @Override
    public List<UserMealPreference> getUserMealPreferences(UUID userId) {
        return userMealPreferenceRepository.findByUserId(userId);
    }

    @Override
    @Transactional
    public List<UserMealPreference> replaceUserMealPreferences(UUID userId,
                                                               List<UserMealPreference> newPreferences) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));

        List<UserMealPreference> existing = userMealPreferenceRepository.findByUserId(userId);

        Map<MealType, UserMealPreference> existingByMealType = existing.stream()
                .collect(Collectors.toMap(
                        UserMealPreference::getMealType,
                        pref -> pref
                ));

        List<UserMealPreference> toSave = new ArrayList<>();

        for (UserMealPreference incoming : newPreferences) {
            MealType mealType = incoming.getMealType();
            Integer maxTime = incoming.getMaxCookingTimeMinutes();

            UserMealPreference target = existingByMealType.remove(mealType);
            if (target == null) {
                target = new UserMealPreference();
                target.setUser(user);
                target.setMealType(mealType);
            }

            target.setMaxCookingTimeMinutes(maxTime);
            toSave.add(target);
        }

        if (!existingByMealType.isEmpty()) {
            userMealPreferenceRepository.deleteAll(existingByMealType.values());
        }

        return userMealPreferenceRepository.saveAll(toSave);
    }
}
