package com.nure.whatwecook.dto.menu;

import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.dto.recipe.RecipeListItemDto;
import lombok.Data;

import java.util.UUID;

@Data
public class MenuMealPlanDto {

    private UUID id;
    private MealType mealType;
    private UUID recipeId;
    private RecipeListItemDto recipe;
}
