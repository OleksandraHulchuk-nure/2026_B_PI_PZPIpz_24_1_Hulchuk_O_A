'use client';

import * as React from 'react';
import {Card} from '@/components/ui/card';
import {Input} from '@/components/ui/input';

import {type RecipeDetailsDto} from '@/lib/api/recipeApi';
import {formatQty, normalizeSteps} from '@/lib/recipes/format';
import {getUnitLabel} from '@/lib/recipes/labels';

export function RecipeIngredientsStepsViewCard({
                                                   recipe,
                                                   ingredientNames,
                                               }: {
    recipe: RecipeDetailsDto;
    ingredientNames: Record<string, string>;
}) {
    const [servingsView, setServingsView] = React.useState<string>(String(recipe.defaultServings ?? 1));

    const scaledIngredients = React.useMemo(() => {
        const list = recipe.ingredients ?? [];
        if (!list.length) return [];

        const base = recipe.defaultServings ?? 1;
        const target = Number(servingsView);
        if (!Number.isFinite(target) || target <= 0) return list;

        const k = target / base;
        return list.map((x) => ({
            ...x,
            quantity: Number.isFinite(x.quantity) ? x.quantity * k : x.quantity,
        }));
    }, [recipe, servingsView]);

    const steps = normalizeSteps(recipe.steps, recipe.description);

    return (
        <Card className="grid gap-4 md:grid-cols-2 p-4">
            {/* INGREDIENTS VIEW */}
            <div className="md:border-r md:border-border/60 md:pr-4">
                <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
                    <div>
                        <h3 className="section-title">Інгредієнти</h3>
                        <p className="section-subtitle">Можна змінити порції — кількість перераховується автоматично.</p>
                    </div>
                </div>

                <div className="mb-3 flex justify-end">
                    <div className="flex items-center gap-2">
                        <label className="whitespace-nowrap text-xs text-text-muted">
                            Порції (база: {recipe.defaultServings ?? 1})
                        </label>
                        <div className="w-14">
                            <Input
                                inputMode="numeric"
                                value={servingsView}
                                onChange={(e) => setServingsView(e.target.value)}
                                placeholder={String(recipe.defaultServings ?? 1)}
                            />
                        </div>
                    </div>
                </div>

                <div className="space-y-2">
                    {scaledIngredients.length ? (
                        scaledIngredients.map((ing, idx) => (
                            <div
                                key={`${ing.ingredientId}-${idx}`}
                                className="flex items-center justify-between gap-3 rounded-xl border border-border bg-background px-3 py-2"
                            >
                                <div className="min-w-0">
                                    <div className="text-sm truncate">
                                        {ingredientNames[ing.ingredientId] ?? ing.ingredientId.slice(0, 8)}
                                        {ing.optional ?
                                            <span className="ml-2 text-xs text-text-muted">(опційно)</span> : null}
                                    </div>
                                </div>
                                <div className="shrink-0 text-sm font-semibold">
                                    {formatQty(ing.quantity)} {getUnitLabel(ing.unit)}
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="text-sm text-text-muted">Інгредієнти не вказані.</div>
                    )}
                </div>
            </div>

            {/* STEPS VIEW */}
            <div className="md:pl-4">
                <div className="mb-3">
                    <h3 className="section-title">Кроки приготування</h3>
                </div>

                <div className="space-y-2">
                    {steps.length ? (
                        steps.map((s, idx) => (
                            <div key={idx} className="flex items-start gap-2">
                                <div className="flex-1 space-y-1">
                                    <label>Крок {idx + 1}</label>
                                    <div className="rounded-xl border border-border bg-background px-3 py-2 text-sm">
                                        {s}
                                    </div>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="text-sm text-text-muted">Кроки не вказані.</div>
                    )}
                </div>
            </div>
        </Card>
    );
}
