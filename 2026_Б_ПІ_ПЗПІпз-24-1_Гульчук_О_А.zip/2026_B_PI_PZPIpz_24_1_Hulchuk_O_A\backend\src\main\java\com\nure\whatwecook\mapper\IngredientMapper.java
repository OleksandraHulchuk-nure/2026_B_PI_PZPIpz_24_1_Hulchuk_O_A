package com.nure.whatwecook.mapper;

import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.dto.ingredient.IngredientDetailsDto;
import com.nure.whatwecook.dto.ingredient.IngredientShortDto;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface IngredientMapper {

    IngredientShortDto toShortDto(Ingredient entity);

    List<IngredientShortDto> toShortDtoList(List<Ingredient> entities);

    IngredientDetailsDto toDetailsDto(Ingredient entity);
}
