'use client';

import type { ComponentProps } from 'react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MaterialIcon } from '@/components/ui/materialIcon';

import type {
    MenuDayPlanDto,
    MenuMealPlanDto,
    RecipeListItemDto,
    WeeklyMenuResponseDto,
} from '@/lib/api/weeklyMenuApi';
import {
    MEAL_TYPE_LABELS,
    MealType,
    RECIPE_SOURCE_ICONS,
    RECIPE_SOURCE_LABELS,
    RECIPE_STATUS_LABELS, recipeSourceBadgeVariant,
    recipeStatusBadgeVariant,
} from '@/lib/constants/enums';
import { cn } from '@/lib/utils';
import { formatUkDateShort, formatUkDayShort } from '@/lib/utils/date';

export interface SlotRef {
    slotId: string;
    date: string; // YYYY-MM-DD
    mealType: MealType;
}

interface WeeklyMenuGridProps {
    menu: WeeklyMenuResponseDto;
    meals: MealType[];
    readOnly: boolean;
    onOpenReplace: (slot: SlotRef) => void;
    onOpenPreview: (recipeId: string) => void;
}

interface DaySummary {
    totalMeals: number;
    totalMinutes: number;
    hasTime: boolean;
    hasApproximateTime: boolean;
}

function formatDayShort(isoDate: string) {
    return formatUkDayShort(isoDate).replace('.', '').toUpperCase();
}

function formatMinutes(minutes: number, approximate = false) {
    return `${approximate ? '≈' : ''}${minutes} хв`;
}

function formatMealCount(count: number) {
    if (count % 10 === 1 && count % 100 !== 11) return `${count} страва`;
    if ([2, 3, 4].includes(count % 10) && ![12, 13, 14].includes(count % 100)) return `${count} страви`;
    return `${count} страв`;
}

function getDaySummary(day: MenuDayPlanDto): DaySummary {
    const plannedMeals = day.meals.filter((slot) => !!slot.recipeId);
    const timedMeals = plannedMeals.filter((slot) => typeof slot.recipe?.totalTimeMinutes === 'number');

    return {
        totalMeals: plannedMeals.length,
        totalMinutes: timedMeals.reduce((sum, slot) => sum + (slot.recipe?.totalTimeMinutes ?? 0), 0),
        hasTime: timedMeals.length > 0,
        hasApproximateTime: timedMeals.length > 0 && timedMeals.length < plannedMeals.length,
    };
}

function getSlotServings(slot: MenuMealPlanDto, recipe?: RecipeListItemDto) {
    if (typeof slot.servings === 'number') return slot.servings;
    if (typeof recipe?.defaultServings === 'number') return recipe.defaultServings;
    return null;
}

function formatDaySummary(day: MenuDayPlanDto) {
    const summary = getDaySummary(day);
    const mealSummary = formatMealCount(summary.totalMeals);

    if (!summary.hasTime) return mealSummary;

    return `${mealSummary} • ${formatMinutes(summary.totalMinutes, summary.hasApproximateTime)}`;
}

function SlotBadge({
    children,
    variant,
}: {
    children: string;
    variant: ComponentProps<typeof Badge>['variant'];
}) {
    return (
        <Badge
            variant={variant}
            className="min-w-0 max-w-full px-2 py-0.5 text-[10px] normal-case tracking-normal"
            title={children}
        >
            <span className="truncate">{children}</span>
        </Badge>
    );
}

function WeeklyMealSlot({
    dayDate,
    mealType,
    slot,
    readOnly,
    onOpenReplace,
    onOpenPreview,
}: {
    dayDate: string;
    mealType: MealType;
    slot?: MenuMealPlanDto;
    readOnly: boolean;
    onOpenReplace: (slot: SlotRef) => void;
    onOpenPreview: (recipeId: string) => void;
}) {
    if (!slot?.recipeId) {
        return (
            <div className="flex min-h-[96px] items-center justify-center rounded-xl border border-dashed border-border/60 bg-background/50 px-2.5 text-center text-xs text-text-muted">
                Не заплановано
            </div>
        );
    }

    const recipe = slot.recipe;
    const servings = getSlotServings(slot, recipe);
    const timeLabel = typeof recipe?.totalTimeMinutes === 'number' ? formatMinutes(recipe.totalTimeMinutes) : null;
    const servingsLabel = servings !== null ? `${servings} порції` : null;
    const meta = [timeLabel, servingsLabel].filter(Boolean).join(' • ') || 'Дані відсутні';

    return (
        <div
            className={cn(
                'min-h-[96px] rounded-xl border px-2.5 py-2',
                readOnly
                    ? 'border-border/60 bg-background/55'
                    : 'border-border/70 bg-background/70',
            )}
        >
            <div className="flex items-start gap-2">
                <button
                    type="button"
                    onClick={() => onOpenPreview(slot.recipeId)}
                    className={cn(
                        'min-w-0 flex-1 cursor-pointer rounded-md -mx-1 -my-0.5 px-1 py-0.5 text-left transition-colors',
                        'hover:bg-surface/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-soft',
                    )}
                    title={recipe?.name ?? 'Рецепт'}
                >
                    <div className="line-clamp-2 text-[13px] font-semibold leading-5 text-text-primary transition-colors hover:text-primary">
                        {recipe?.name ?? 'Рецепт'}
                    </div>
                </button>

                {!readOnly ? (
                    <Button
                        variant="icon"
                        size="icon"
                        onClick={() => onOpenReplace({ slotId: slot.id, date: dayDate, mealType })}
                        className={cn(
                            'h-8 w-8 shrink-0 rounded-full border border-border/60 bg-surface/70 p-0 shadow-none',
                            'hover:border-primary/30 hover:bg-primary-soft focus-visible:ring-primary-soft',
                        )}
                        title="Змінити рецепт"
                        aria-label="Замінити рецепт"
                    >
                        <MaterialIcon name="edit" className="text-[18px]" />
                    </Button>
                ) : null}
            </div>

            <div className="mt-2 truncate text-xs text-text-muted" title={meta}>
                {meta}
            </div>

            <div className="mt-2 flex items-center gap-1.5 overflow-hidden">
                {recipe?.status ? (
                    <SlotBadge variant={recipeStatusBadgeVariant(recipe.status)}>
                        {RECIPE_STATUS_LABELS[recipe.status]}
                    </SlotBadge>
                ) : null}

                {recipe?.sourceType && (
                    <MaterialIcon
                        name={RECIPE_SOURCE_ICONS[recipe.sourceType]}
                        variant={recipeSourceBadgeVariant(recipe.sourceType)}
                        label={RECIPE_SOURCE_LABELS[recipe.sourceType]}
                        className="text-[18px]"
                    />
                )}
            </div>
        </div>
    );
}

export default function WeeklyMenuGrid({
    menu,
    meals,
    readOnly,
    onOpenReplace,
    onOpenPreview,
}: WeeklyMenuGridProps) {
    return (
        <div className="max-w-full overflow-x-auto rounded-2xl border border-border bg-surface">
            <table className="w-full min-w-[960px] table-fixed border-collapse">
                <thead>
                <tr className="border-b border-border/70 bg-background/70">
                    <th className="sticky left-0 z-10 w-[136px] bg-surface px-3 py-2.5 text-left text-xs font-semibold text-text-muted">
                        День
                    </th>
                    {meals.map((mealType) => (
                        <th
                            key={mealType}
                            className="px-2.5 py-2.5 text-left text-xs font-semibold text-text-muted"
                        >
                            {MEAL_TYPE_LABELS[mealType]}
                        </th>
                    ))}
                </tr>
                </thead>

                <tbody>
                {menu.days.map((day) => (
                    <tr key={day.date} className="border-b border-border/60 last:border-b-0">
                        <td className="sticky left-0 z-10 align-top bg-surface px-3 py-2.5">
                            <div className="space-y-1">
                                <div className="flex items-baseline gap-2">
                                    <span className="text-sm font-semibold text-text-primary">{formatDayShort(day.date)}</span>
                                    <span className="text-xs text-text-muted">{formatUkDateShort(day.date)}</span>
                                </div>
                                <div className="text-xs leading-5 text-text-muted">
                                    {formatDaySummary(day)}
                                </div>
                            </div>
                        </td>

                        {meals.map((mealType) => {
                            const slot = day.meals.find((meal) => meal.mealType === mealType);

                            return (
                                <td key={`${day.date}-${mealType}`} className="align-top px-1.5 py-2">
                                    <WeeklyMealSlot
                                        dayDate={day.date}
                                        mealType={mealType}
                                        slot={slot}
                                        readOnly={readOnly}
                                        onOpenReplace={onOpenReplace}
                                        onOpenPreview={onOpenPreview}
                                    />
                                </td>
                            );
                        })}
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    );
}
