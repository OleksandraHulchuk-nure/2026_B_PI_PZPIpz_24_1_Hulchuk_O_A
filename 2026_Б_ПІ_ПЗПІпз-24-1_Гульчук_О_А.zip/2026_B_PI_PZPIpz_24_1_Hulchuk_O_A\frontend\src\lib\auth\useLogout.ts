'use client';

import { useCallback, useState } from 'react';
import { useRouter } from 'next/navigation';
import { logoutUser } from '@/lib/api/authApi';
import { clearAuthToken } from './tokenStorage';

export function useLogout() {
    const router = useRouter();
    const [isLoggingOut, setIsLoggingOut] = useState(false);

    const logout = useCallback(async () => {
        if (isLoggingOut) return;

        setIsLoggingOut(true);
        try {
            await logoutUser();
        } catch {
        } finally {
            clearAuthToken();
            setIsLoggingOut(false);
            router.push('/login');
        }
    }, [isLoggingOut, router]);

    return { logout, isLoggingOut };
}
