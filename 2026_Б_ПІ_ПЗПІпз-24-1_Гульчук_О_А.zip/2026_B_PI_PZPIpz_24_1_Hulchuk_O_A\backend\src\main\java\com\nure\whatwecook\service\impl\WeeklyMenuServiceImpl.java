package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.domain.entity.menu.MenuDay;
import com.nure.whatwecook.domain.entity.menu.MenuMeal;
import com.nure.whatwecook.domain.entity.menu.WeeklyMenu;
import com.nure.whatwecook.domain.entity.profile.User;
import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MenuStatus;
import com.nure.whatwecook.repository.RecipeRepository;
import com.nure.whatwecook.repository.UserRepository;
import com.nure.whatwecook.repository.WeeklyMenuRepository;
import com.nure.whatwecook.service.AiRecipeService;
import com.nure.whatwecook.service.WeeklyMenuService;
import com.nure.whatwecook.service.helper.WeeklyMenuGenerationHelper;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class WeeklyMenuServiceImpl implements WeeklyMenuService {

    private final WeeklyMenuRepository weeklyMenuRepository;
    private final UserRepository userRepository;
    private final RecipeRepository recipeRepository;

    private final AiRecipeService aiRecipeService;
    private final WeeklyMenuGenerationHelper weeklyMenuGenerationHelper;

    @Override
    @Transactional
    public WeeklyMenu generateWeeklyMenu(UUID userId,
                                         LocalDate startDate,
                                         Integer days,
                                         List<MealType> mealsPerDay) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));

        LocalDate effectiveStart = (startDate != null)
                ? startDate
                : startOfCurrentWeek(LocalDate.now());

        int length = (days != null && days > 0) ? days : 7;

        List<MealType> meals = (mealsPerDay != null && !mealsPerDay.isEmpty())
                ? mealsPerDay
                : List.of(MealType.BREAKFAST, MealType.LUNCH, MealType.DINNER);

        WeeklyMenu existing = weeklyMenuRepository
                .findByUserIdAndStartDate(userId, effectiveStart)
                .orElse(null);

        if (existing != null && existing.getStatus() == MenuStatus.APPROVED) {
            throw new IllegalStateException(
                    "Weekly menu for this start date is already approved and cannot be regenerated"
            );
        }

        int generationVersion = 1;
        Set<UUID> avoidRecipeIds = Set.of();

        if (existing != null) {
            generationVersion = (existing.getGenerationVersion() == null)
                    ? 2
                    : existing.getGenerationVersion() + 1;


            avoidRecipeIds = existing.getDays().stream()
                    .flatMap(d -> d.getMeals().stream())
                    .map(MenuMeal::getRecipe)
                    .filter(Objects::nonNull)
                    .map(Recipe::getId)
                    .collect(Collectors.toSet());

            weeklyMenuRepository.delete(existing);
            weeklyMenuRepository.flush();
        }

        WeeklyMenu weeklyMenu = new WeeklyMenu();
        weeklyMenu.setUser(user);
        weeklyMenu.setStartDate(effectiveStart);
        weeklyMenu.setStatus(MenuStatus.DRAFT);
        weeklyMenu.setGenerationVersion(generationVersion);

        if (weeklyMenu.getDays() == null) weeklyMenu.setDays(new ArrayList<>());

        Map<MealType, List<Recipe>> recipesByMealType =
                prepareRecipesForWeek(user, meals, length, effectiveStart, generationVersion, avoidRecipeIds);

        for (int i = 0; i < length; i++) {
            LocalDate dayDate = effectiveStart.plusDays(i);

            MenuDay day = new MenuDay();
            day.setWeeklyMenu(weeklyMenu);
            day.setDate(dayDate);

            if (day.getMeals() == null) {
                day.setMeals(new ArrayList<>());
            }

            for (MealType mealType : meals) {
                MenuMeal meal = new MenuMeal();
                meal.setMenuDay(day);
                meal.setMealType(mealType);
                meal.setRecipe(popRecipe(recipesByMealType, mealType));

                day.getMeals().add(meal);
            }

            weeklyMenu.getDays().add(day);
        }

        return weeklyMenuRepository.save(weeklyMenu);
    }

    private Map<MealType, List<Recipe>> prepareRecipesForWeek(User user,
                                                              List<MealType> meals,
                                                              int days,
                                                              LocalDate weekStart,
                                                              int generationVersion,
                                                              Set<UUID> avoidRecipeIds) {
        Map<MealType, List<Recipe>> recipesByMealType = new EnumMap<>(MealType.class);
        for (MealType mealType : meals) {
            List<Recipe> selected = weeklyMenuGenerationHelper.selectRecipesForMealType(
                    user,
                    mealType,
                    weekStart,
                    generationVersion,
                    avoidRecipeIds,
                    days
            );
            recipesByMealType.put(mealType, new ArrayList<>(selected));
        }
        return recipesByMealType;
    }

    private Recipe popRecipe(Map<MealType, List<Recipe>> recipesByMealType, MealType mealType) {
        List<Recipe> recipes = recipesByMealType.getOrDefault(mealType, new ArrayList<>());
        if (recipes.isEmpty()) {
            return null;
        }
        return recipes.remove(0);
    }

    @Override
    public WeeklyMenu getWeeklyMenu(UUID userId, UUID weeklyMenuId) {
        WeeklyMenu menu = weeklyMenuRepository.findById(weeklyMenuId)
                .orElseThrow(() -> new EntityNotFoundException("Weekly menu not found"));
        if (!menu.getUser().getId().equals(userId)) {
            throw new EntityNotFoundException("Weekly menu not found");
        }
        return menu;
    }

    @Override
    public List<WeeklyMenu> getWeeklyMenus(UUID userId) {
        return weeklyMenuRepository.findByUserIdOrderByStartDateDesc(userId);
    }

    @Override
    @Transactional
    public WeeklyMenu updateWeeklyMenuStructure(UUID userId,
                                                UUID weeklyMenuId,
                                                WeeklyMenu updatedStructure) {
        WeeklyMenu existing = getWeeklyMenu(userId, weeklyMenuId);

        existing.getDays().clear();

        for (MenuDay newDay : updatedStructure.getDays()) {
            MenuDay persistedDay = new MenuDay();
            persistedDay.setWeeklyMenu(existing);
            persistedDay.setDate(newDay.getDate());

            persistedDay.getMeals().clear();
            for (MenuMeal newMeal : newDay.getMeals()) {
                MenuMeal persistedMeal = new MenuMeal();
                persistedMeal.setMenuDay(persistedDay);
                persistedMeal.setMealType(newMeal.getMealType());

                if (newMeal.getRecipe() != null) {
                    UUID recipeId = newMeal.getRecipe().getId();
                    Recipe recipe = recipeRepository.findById(recipeId)
                            .orElseThrow(() -> new EntityNotFoundException("Recipe not found"));
                    persistedMeal.setRecipe(recipe);
                }

                persistedDay.getMeals().add(persistedMeal);
            }

            existing.getDays().add(persistedDay);
        }

        return weeklyMenuRepository.save(existing);
    }

    @Override
    @Transactional
    public WeeklyMenu updateWeeklyMenuStatus(UUID userId, UUID weeklyMenuId, MenuStatus status) {
        WeeklyMenu existing = getWeeklyMenu(userId, weeklyMenuId);
        existing.setStatus(status);
        return weeklyMenuRepository.save(existing);
    }

    @Override
    @Transactional
    public WeeklyMenu replaceMenuMeal(UUID userId, UUID weeklyMenuId, UUID menuMealId, UUID recipeId) {
        WeeklyMenu menu = getWeeklyMenu(userId, weeklyMenuId);

        MenuMeal targetMeal = menu.getDays().stream()
                .flatMap(day -> day.getMeals().stream())
                .filter(meal -> meal.getId().equals(menuMealId))
                .findFirst()
                .orElseThrow(() -> new EntityNotFoundException("Menu meal not found"));

        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new EntityNotFoundException("Recipe not found"));

        targetMeal.setRecipe(recipe);

        return weeklyMenuRepository.save(menu);
    }

    @Override
    @Transactional
    public WeeklyMenu approveWeeklyMenu(UUID userId, UUID weeklyMenuId) {
        return updateWeeklyMenuStatus(userId, weeklyMenuId, MenuStatus.APPROVED);
    }

    private LocalDate startOfCurrentWeek(LocalDate date) {
        DayOfWeek dow = date.getDayOfWeek();
        int diff = dow.getValue() - DayOfWeek.MONDAY.getValue();
        return date.minusDays(diff);
    }

    @Override
    @Transactional(readOnly = true)
    public WeeklyMenu getUserMenuByStartDate(UUID userId, LocalDate startDate) {
        return weeklyMenuRepository.findByUserIdAndStartDate(userId, startDate)
                .orElseThrow(() -> new EntityNotFoundException(
                        "Weekly menu not found for user " + userId + " and startDate " + startDate
                ));
    }

    @Override
    @Transactional
    public WeeklyMenu generateAiRecipeForSlot(UUID userId,
                                              UUID weeklyMenuId,
                                              UUID slotId,
                                              Integer maxTimeMinutes,
                                              String extraNotes) {

        WeeklyMenu weeklyMenu = weeklyMenuRepository.findByIdAndUserId(weeklyMenuId, userId)
                .orElseThrow(() -> new EntityNotFoundException(
                        "Weekly menu not found for id " + weeklyMenuId
                ));

        MenuMeal slot = findSlotInMenu(weeklyMenu, slotId);

        Recipe aiRecipe = aiRecipeService.generateRecipeForMenuSlot(
                userId,
                slot.getMealType(),
                maxTimeMinutes,
                extraNotes
        );

        slot.setRecipe(aiRecipe);

        return weeklyMenuRepository.save(weeklyMenu);
    }

    private MenuMeal findSlotInMenu(WeeklyMenu weeklyMenu, UUID slotId) {
        return weeklyMenu.getDays().stream()
                .flatMap(day -> day.getMeals().stream())
                .filter(meal -> slotId.equals(meal.getId()))
                .findFirst()
                .orElseThrow(() -> new EntityNotFoundException(
                        "Menu slot " + slotId + " not found in weekly menu " + weeklyMenu.getId()
                ));
    }
}
