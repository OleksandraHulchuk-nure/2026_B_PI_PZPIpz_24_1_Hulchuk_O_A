import * as React from 'react';
import { cn } from '@/lib/utils';

type BadgeVariant =
    | 'soft'
    | 'secondary'
    | 'ai'
    | 'warm'
    | 'info'
    | 'status'
    | 'statusWarning'
    | 'statusError'
    | 'outline';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
    variant?: BadgeVariant;
}

const base =
    'inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold tracking-[0.08em] uppercase';

const badgeVariants: Record<BadgeVariant, string> = {
    soft:
        'border-transparent bg-primary-soft text-primary',
    secondary:
        'border-transparent bg-secondary text-text-inverted',
    ai: 'border border-accent-ai/20 bg-accent-soft-ai text-accent-ai',
    warm: 'border border-accent-warm/25 bg-accent-soft-warm text-accent-warm',
    info:
        'border border-accent-info/25 bg-accent-info/10 text-accent-info',
    status:
        'border border-success/30 bg-success/10 text-success',
    statusWarning:
        'border border-warning/25 bg-warning/10 text-warning',
    statusError:
        'border border-error/25 bg-error/10 text-error',
    outline:
        'border border-border bg-transparent text-text-muted',
};

export const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
    ({ className, variant = 'soft', ...props }, ref) => {
        return (
            <span
                ref={ref}
                className={cn(base, badgeVariants[variant], className)}
                {...props}
            />
        );
    },
);

Badge.displayName = 'Badge';
