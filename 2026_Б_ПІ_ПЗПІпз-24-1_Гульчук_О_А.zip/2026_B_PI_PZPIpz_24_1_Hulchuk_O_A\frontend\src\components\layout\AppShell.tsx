﻿import {AppNavbar} from './AppNavbar';
import React from 'react';

interface AppShellProps {
    children: React.ReactNode;
}

export function AppShell({children}: AppShellProps) {
    return (
        <div className="min-h-screen bg-background text-text-primary">
            <div aria-hidden="true" className="pointer-events-none fixed inset-0 overflow-hidden">
                <div
                    className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(67,106,111,0.18),transparent_34%),radial-gradient(circle_at_85%_15%,rgba(194,106,70,0.12),transparent_24%),linear-gradient(180deg,rgba(255,255,255,0.3),transparent_32%)] dark:bg-[radial-gradient(circle_at_top_left,rgba(196,122,90,0.16),transparent_32%),radial-gradient(circle_at_84%_14%,rgba(183,154,126,0.10),transparent_22%),linear-gradient(180deg,rgba(255,244,236,0.03),transparent_34%)]"/>
            </div>

            <div
                className="relative mx-auto flex min-h-screen w-full max-w-[1720px] flex-col gap-4 px-3 py-4 sm:px-4 lg:flex-row lg:gap-5 lg:px-5 lg:py-5 xl:gap-6 xl:px-6 2xl:px-8 2xl:py-6">
                <AppNavbar/>

                <main className="w-full min-w-0 max-w-full flex-1 pb-10 lg:pt-1">
                    {children}
                </main>
            </div>
        </div>
    );
}
