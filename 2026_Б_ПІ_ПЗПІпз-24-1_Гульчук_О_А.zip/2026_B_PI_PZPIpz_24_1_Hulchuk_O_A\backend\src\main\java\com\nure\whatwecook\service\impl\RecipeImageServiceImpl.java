package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.entity.recipe.RecipeImage;
import com.nure.whatwecook.repository.RecipeImageRepository;
import com.nure.whatwecook.repository.RecipeRepository;
import com.nure.whatwecook.service.RecipeImageService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class RecipeImageServiceImpl implements RecipeImageService {

    private final RecipeRepository recipeRepository;
    private final RecipeImageRepository recipeImageRepository;

    @Override
    @Transactional
    public RecipeImage saveOrUpdatePrimaryImage(UUID userId,
                                                UUID recipeId,
                                                byte[] data,
                                                String contentType,
                                                String fileName) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new EntityNotFoundException("Recipe not found"));
        if (!recipe.getUser().getId().equals(userId)) {
            throw new EntityNotFoundException("Recipe not found");
        }

        RecipeImage image = recipeImageRepository
                .findFirstByRecipeIdAndPrimaryIsTrue(recipeId)
                .orElseGet(RecipeImage::new);

        image.setRecipe(recipe);
        image.setData(data);
        image.setContentType(contentType);
        image.setFileName(fileName);
        image.setPrimary(true);

        return recipeImageRepository.save(image);
    }

    @Override
    public RecipeImage getPrimaryImage(UUID userId, UUID recipeId) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new EntityNotFoundException("Recipe not found"));
        if (!recipe.getUser().getId().equals(userId)) {
            throw new EntityNotFoundException("Recipe not found");
        }

        return recipeImageRepository.findFirstByRecipeIdAndPrimaryIsTrue(recipeId)
                .orElseThrow(() -> new EntityNotFoundException("Image not found"));
    }
}
