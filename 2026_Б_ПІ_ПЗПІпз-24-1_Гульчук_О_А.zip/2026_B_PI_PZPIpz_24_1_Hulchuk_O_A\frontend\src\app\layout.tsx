import './globals.css';
import type {Metadata} from 'next';
import {dmSans} from '@/lib/fonts';
import React from "react";

export const metadata: Metadata = {
    title: 'WhatWeCook',
    description: 'Інтелігентний планувальник сімейного меню',
};

export default function RootLayout({
                                       children,
                                   }: {
    children: React.ReactNode;
}) {
    return (
        <html lang="uk">
        <head>
            <link
                rel="stylesheet"
                href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@400&display=swap"
            />
        </head>
        <body className={dmSans.className}>{children}</body>
        </html>
    );
}
