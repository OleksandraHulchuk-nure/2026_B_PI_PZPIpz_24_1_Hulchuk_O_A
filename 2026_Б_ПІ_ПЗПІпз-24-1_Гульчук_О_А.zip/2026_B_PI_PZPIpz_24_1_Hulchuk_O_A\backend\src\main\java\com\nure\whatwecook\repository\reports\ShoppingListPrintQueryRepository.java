package com.nure.whatwecook.repository.reports;

import com.nure.whatwecook.dto.reports.WeeklyShoppingListReportDto;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.DataClassRowMapper;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Repository
@RequiredArgsConstructor
public class ShoppingListPrintQueryRepository {

    private final JdbcClient jdbc;

    public MetaRow loadMeta(UUID userId, UUID shoppingListId) {
        return jdbc.sql("""
                            SELECT
                              sl.id         AS shoppingListId,
                              wm.id         AS weeklyMenuId,
                              wm.user_id    AS userId,
                              wm.start_date AS startDate
                            FROM shopping_list sl
                            JOIN weekly_menu wm ON wm.id = sl.weekly_menu_id
                            WHERE sl.id = :shoppingListId
                              AND wm.user_id = :userId
                        """)
                .param("shoppingListId", shoppingListId)
                .param("userId", userId)
                .query(new DataClassRowMapper<>(MetaRow.class))
                .single();
    }

    public List<ItemRow> loadItems(UUID userId, UUID shoppingListId) {
        return jdbc.sql("""
                            SELECT
                              shopping_list_id  AS shoppingListId,
                              user_id           AS userId,
                              start_date        AS startDate,
                              category          AS category,
                              ingredient_name_uk AS ingredientNameUk,
                              quantity_unit     AS quantityUnit,
                              needed_quantity   AS neededQuantity,
                              have_quantity     AS haveQuantity,
                              to_buy_quantity   AS toBuyQuantity,
                              is_fully_covered  AS isFullyCovered
                            FROM vw_print_shopping_list_weekly_item
                            WHERE shopping_list_id = :shoppingListId
                              AND user_id = :userId
                            ORDER BY category, ingredient_name_uk, quantity_unit
                        """)
                .param("shoppingListId", shoppingListId)
                .param("userId", userId)
                .query(new DataClassRowMapper<>(ItemRow.class))
                .list();
    }

    public List<CategoryTotalRow> loadCategoryTotals(UUID userId, UUID shoppingListId) {
        return jdbc.sql("""
                            SELECT
                              shopping_list_id AS shoppingListId,
                              user_id          AS userId,
                              start_date       AS startDate,
                              category         AS category,
                              items_cnt        AS itemsCnt,
                              to_buy_items_cnt AS toBuyItemsCnt,
                              fully_covered_items_cnt AS fullyCoveredItemsCnt,
                              fully_covered_share_pct AS fullyCoveredSharePct
                            FROM vw_print_shopping_list_weekly_category_totals
                            WHERE shopping_list_id = :shoppingListId
                              AND user_id = :userId
                            ORDER BY category
                        """)
                .param("shoppingListId", shoppingListId)
                .param("userId", userId)
                .query(new DataClassRowMapper<>(CategoryTotalRow.class))
                .list();
    }

    public WeeklyShoppingListReportDto loadWeeklyShoppingListReport(UUID userId, UUID shoppingListId) {
        var meta = loadMeta(userId, shoppingListId);
        var items = loadItems(userId, shoppingListId);
        var totals = loadCategoryTotals(userId, shoppingListId);

        Map<String, WeeklyShoppingListReportDto.CategoryBlock> byCategory = new LinkedHashMap<>();

        for (var t : totals) {
            byCategory.put(t.category(), new WeeklyShoppingListReportDto.CategoryBlock(
                    t.category(),
                    t.itemsCnt(),
                    t.toBuyItemsCnt(),
                    t.fullyCoveredSharePct(),
                    new ArrayList<>()
            ));
        }

        for (var it : items) {
            byCategory.computeIfAbsent(it.category(), c ->
                    new WeeklyShoppingListReportDto.CategoryBlock(c, 0, 0, null, new ArrayList<>())
            ).items().add(new WeeklyShoppingListReportDto.ItemLine(
                    it.ingredientNameUk(),
                    it.neededQuantity(),
                    it.haveQuantity(),
                    it.toBuyQuantity(),
                    it.quantityUnit(),
                    it.isFullyCovered()
            ));
        }

        return new WeeklyShoppingListReportDto(
                meta.shoppingListId(),
                meta.startDate(),
                new ArrayList<>(byCategory.values())
        );
    }

    public record MetaRow(UUID shoppingListId, UUID weeklyMenuId, UUID userId, LocalDate startDate) {
    }

    public record ItemRow(
            UUID shoppingListId,
            UUID userId,
            LocalDate startDate,
            String category,
            String ingredientNameUk,
            String quantityUnit,
            BigDecimal neededQuantity,
            BigDecimal haveQuantity,
            BigDecimal toBuyQuantity,
            boolean isFullyCovered
    ) {
    }

    public record CategoryTotalRow(
            UUID shoppingListId,
            UUID userId,
            LocalDate startDate,
            String category,
            long itemsCnt,
            long toBuyItemsCnt,
            long fullyCoveredItemsCnt,
            BigDecimal fullyCoveredSharePct
    ) {
    }
}
