package com.nure.whatwecook.dto.recipe;

import com.nure.whatwecook.domain.enums.RecipeStatus;
import lombok.Data;

@Data
public class RecipeRatingUpdateRequestDto {

    private Integer complexityRating;
    private Integer tasteRating;
    private String ratingComment;
    private RecipeStatus status;
}
