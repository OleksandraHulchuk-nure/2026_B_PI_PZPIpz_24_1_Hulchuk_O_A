import { useEffect, useMemo, useState } from 'react';

import {
    getIngredientPreferences,
    type IngredientPreference,
} from '@/lib/api/profileApi';

import { KINDS } from '../ingredientPreferences.constants';
import type { IngredientPreferencesSectionProps, PreferencesByKind } from '../profile.types';

const createEmptyPreferencesState = (): PreferencesByKind => ({
    FAVORITE: [],
    DISLIKED: [],
    ALLERGY: [],
    EXCLUDED: [],
});

const groupPreferences = (preferences: IngredientPreference[]): PreferencesByKind => {
    const grouped = createEmptyPreferencesState();

    for (const preference of preferences) {
        grouped[preference.kind].push(preference);
    }

    return grouped;
};

type UseIngredientPreferencesResult = {
    state: PreferencesByKind;
    loading: boolean;
    error: string | null;
    handleRemove: (kind: keyof PreferencesByKind, ingredientId: string) => void;
    handleAdd: (
        kind: keyof PreferencesByKind,
        ingredient: IngredientPreference,
    ) => void;
};

export function useIngredientPreferences({
    onPreferencesChange,
    initialPreferences,
}: IngredientPreferencesSectionProps): UseIngredientPreferencesResult {
    const [state, setState] = useState<PreferencesByKind>(() => (
        initialPreferences ? groupPreferences(initialPreferences) : createEmptyPreferencesState()
    ));
    const [loading, setLoading] = useState(!initialPreferences);
    const [error, setError] = useState<string | null>(null);

    const allPreferences = useMemo(
        () => KINDS.flatMap((kind) => state[kind]),
        [state],
    );

    useEffect(() => {
        let isMounted = true;

        const load = async () => {
            if (initialPreferences) {
                setState(groupPreferences(initialPreferences));
                setLoading(false);
                setError(null);
                return;
            }

            setLoading(true);
            setError(null);

            try {
                const preferences = await getIngredientPreferences();
                if (!isMounted) return;

                setState(groupPreferences(preferences));
            } catch (err) {
                if (!isMounted) return;
                const message =
                    err instanceof Error
                        ? err.message
                        : 'Не вдалося завантажити вподобання інгредієнтів.';
                setError(message);
            } finally {
                if (isMounted) {
                    setLoading(false);
                }
            }
        };

        void load();

        return () => {
            isMounted = false;
        };
    }, [initialPreferences]);

    useEffect(() => {
        if (!onPreferencesChange || loading || error) return;

        onPreferencesChange(allPreferences);
    }, [allPreferences, error, loading, onPreferencesChange]);

    const handleRemove = (
        kind: keyof PreferencesByKind,
        ingredientId: string,
    ) => {
        setState((prev) => ({
            ...prev,
            [kind]: prev[kind].filter(
                (preference) => preference.ingredientId !== ingredientId,
            ),
        }));
    };

    const handleAdd = (
        kind: keyof PreferencesByKind,
        ingredient: IngredientPreference,
    ) => {
        setState((prev) => {
            const already = prev[kind].some(
                (preference) => preference.ingredientId === ingredient.ingredientId,
            );
            if (already) return prev;

            return {
                ...prev,
                [kind]: [...prev[kind], ingredient],
            };
        });
    };

    return { state, loading, error, handleRemove, handleAdd };
}
