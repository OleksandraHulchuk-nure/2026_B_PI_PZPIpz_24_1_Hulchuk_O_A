package com.nure.whatwecook.service.reports.pdf.request;

import java.util.UUID;

public record WeeklyShoppingListPdfRequest(UUID userId, UUID shoppingListId) {}
