package com.nure.whatwecook.service;

import com.nure.whatwecook.domain.entity.profile.UserProfile;

import java.util.UUID;

public interface UserProfileService {

    UserProfile getCurrentUserProfile(UUID userId);

    UserProfile upsertUserProfile(UUID userId, UserProfile updatedProfile);
}
