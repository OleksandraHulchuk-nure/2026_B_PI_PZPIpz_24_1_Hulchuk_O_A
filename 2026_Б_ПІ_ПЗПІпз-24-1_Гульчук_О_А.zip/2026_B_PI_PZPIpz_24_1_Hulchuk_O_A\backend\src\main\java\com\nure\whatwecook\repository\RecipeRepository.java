package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.RecipeSourceType;
import com.nure.whatwecook.domain.enums.RecipeStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface RecipeRepository extends JpaRepository<Recipe, UUID> {

    @Query(value = """
            select r from Recipe r
            where r.user.id = :userId
              and (:status is null or r.status = :status)
              and (:sourceType is null or r.sourceType = :sourceType)
              and (:mealType is null or r.mealType = :mealType)
              and (:maxTotalTimeMinutes is null or r.totalTimeMinutes <= :maxTotalTimeMinutes)
              and (:search is null or lower(r.name) like :search)
            """,
            countQuery = """
                    select count(r) from Recipe r
                    where r.user.id = :userId
                      and (:status is null or r.status = :status)
                      and (:sourceType is null or r.sourceType = :sourceType)
                      and (:mealType is null or r.mealType = :mealType)
                      and (:maxTotalTimeMinutes is null or r.totalTimeMinutes <= :maxTotalTimeMinutes)
                      and (:search is null or lower(r.name) like :search)
                    """)
    Page<Recipe> findByUserAndFilters(
            @Param("userId") UUID userId,
            @Param("search") String search,
            @Param("status") RecipeStatus status,
            @Param("sourceType") RecipeSourceType sourceType,
            @Param("mealType") MealType mealType,
            @Param("maxTotalTimeMinutes") Integer maxTotalTimeMinutes,
            Pageable pageable
    );

    Optional<Recipe> findByUserIdAndMealType(UUID userId, MealType mealType);

}
