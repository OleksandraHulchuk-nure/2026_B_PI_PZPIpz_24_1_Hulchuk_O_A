package com.nure.whatwecook.dto.auth;

import lombok.Data;

@Data
public class AuthResponseDto {

    private String accessToken;
    private String tokenType;
}
