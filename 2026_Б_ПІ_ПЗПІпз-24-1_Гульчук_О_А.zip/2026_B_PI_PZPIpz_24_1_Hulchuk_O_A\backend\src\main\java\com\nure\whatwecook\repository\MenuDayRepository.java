package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.menu.MenuDay;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface MenuDayRepository extends JpaRepository<MenuDay, UUID> {

    List<MenuDay> findByWeeklyMenuIdOrderByDate(UUID weeklyMenuId);

    Optional<MenuDay> findByWeeklyMenuIdAndDate(UUID weeklyMenuId, LocalDate date);

    Optional<MenuDay> findByWeeklyMenuUserIdAndDate(UUID userId, LocalDate date);

    void deleteByWeeklyMenuId(UUID weeklyMenuId);
}
