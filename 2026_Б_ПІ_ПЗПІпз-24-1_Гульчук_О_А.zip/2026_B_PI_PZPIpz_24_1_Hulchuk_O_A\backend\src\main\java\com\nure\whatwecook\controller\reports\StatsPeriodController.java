package com.nure.whatwecook.controller.reports;

import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.dto.stats.StatPeriodAiMetricsDto;
import com.nure.whatwecook.dto.stats.StatPeriodMenuMetricsDto;
import com.nure.whatwecook.dto.stats.StatPeriodTopCategoriesDto;
import com.nure.whatwecook.dto.stats.StatPeriodTopIngredientsDto;
import com.nure.whatwecook.service.reports.StatsPeriodService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.UUID;

@Tag(name = "Statistics", description = "View aggregated analytics")
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/stats")
public class StatsPeriodController {

    private final CurrentUserProvider currentUserProvider;
    private final StatsPeriodService service;

    @Operation(summary = "Get AI recipe quality stats by menu date range")
    @GetMapping("/ai")
    public StatPeriodAiMetricsDto getAiMetrics(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        return service.getAiMetrics(from, to, userId);
    }

    @Operation(summary = "Get daily menu metrics for approved menus in date range")
    @GetMapping("/menu")
    public StatPeriodMenuMetricsDto getMenuMetrics(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        return service.getMenuMetrics(from, to, userId);
    }

    @Operation(summary = "Get top ingredients by category for menus in date range")
    @GetMapping("/top-categories")
    public StatPeriodTopCategoriesDto getTopCategories(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(required = false, defaultValue = "10") Integer limit,
            @RequestParam(required = false, defaultValue = "false") boolean includeOptional
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        return service.getTopCategories(from, to, limit, includeOptional, userId);
    }

    @Operation(summary = "Get top ingredients for menus in date range")
    @GetMapping("/top-ingredients")
    public StatPeriodTopIngredientsDto getTopIngredients(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(required = false, defaultValue = "10") Integer limit,
            @RequestParam(required = false, defaultValue = "false") boolean includeOptional
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        return service.getTopIngredients(from, to, limit, includeOptional, userId);
    }
}


