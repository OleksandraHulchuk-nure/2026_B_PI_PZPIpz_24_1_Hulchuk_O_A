package com.nure.whatwecook.mapper;

import com.nure.whatwecook.domain.entity.profile.UserProfile;
import com.nure.whatwecook.dto.profile.UserProfileResponseDto;
import com.nure.whatwecook.dto.profile.UserProfileUpdateRequestDto;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface UserProfileMapper {

    UserProfileResponseDto toDto(UserProfile entity);

    UserProfile toEntity(UserProfileUpdateRequestDto dto);

    void updateEntityFromDto(UserProfileUpdateRequestDto dto, @MappingTarget UserProfile entity);
}
