package com.nure.whatwecook.service;

import com.nure.whatwecook.domain.entity.menu.WeeklyMenu;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MenuStatus;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public interface WeeklyMenuService {

    WeeklyMenu generateWeeklyMenu(UUID userId,
                                  LocalDate startDate,
                                  Integer days,
                                  java.util.List<MealType> mealsPerDay);

    WeeklyMenu getWeeklyMenu(UUID userId, UUID weeklyMenuId);

    List<WeeklyMenu> getWeeklyMenus(UUID userId);

    WeeklyMenu updateWeeklyMenuStructure(UUID userId, UUID weeklyMenuId, WeeklyMenu updatedStructure);

    WeeklyMenu updateWeeklyMenuStatus(UUID userId, UUID weeklyMenuId, MenuStatus status);

    WeeklyMenu replaceMenuMeal(UUID userId, UUID weeklyMenuId, UUID menuMealId, UUID recipeId);

    WeeklyMenu approveWeeklyMenu(UUID userId, UUID weeklyMenuId);

    WeeklyMenu getUserMenuByStartDate(UUID userId, LocalDate startDate);

    WeeklyMenu generateAiRecipeForSlot(UUID userId,
                                       UUID weeklyMenuId,
                                       UUID slotId,
                                       Integer maxTimeMinutes,
                                       String extraNotes);

}
