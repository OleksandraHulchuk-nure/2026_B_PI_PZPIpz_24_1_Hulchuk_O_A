package com.nure.whatwecook.repository.statistics;

import com.nure.whatwecook.domain.entity.menu.WeeklyMenu;
import com.nure.whatwecook.domain.projections.*;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public interface StatsPeriodRepository extends Repository<WeeklyMenu, UUID> {

    @Query(value = """
            SELECT AVG(day_total)::numeric
            FROM (
                SELECT menu_day_date, SUM(recipe_total_time_minutes)::numeric AS day_total
                FROM v_stat_menu_slot_fact
                WHERE user_id = :userId
                  AND weekly_menu_status = :approvedStatus
                  AND menu_day_date BETWEEN :from AND :to
                  AND recipe_id IS NOT NULL
                GROUP BY menu_day_date
            ) t
            """, nativeQuery = true)
    BigDecimal getAvgCookingTimePerDay(@Param("userId") UUID userId,
                                       @Param("approvedStatus") String approvedStatus,
                                       @Param("from") LocalDate from,
                                       @Param("to") LocalDate to);

    @Query(value = """
            SELECT
                COUNT(*) FILTER (WHERE pref_max_cooking_time_minutes IS NOT NULL AND recipe_id IS NOT NULL)::int AS time_constraints_cnt,
                COUNT(*) FILTER (
                    WHERE pref_max_cooking_time_minutes IS NOT NULL
                      AND recipe_id IS NOT NULL
                      AND recipe_total_time_minutes <= pref_max_cooking_time_minutes
                )::int AS within_time_cnt
            FROM v_stat_menu_slot_fact
            WHERE user_id = :userId
              AND weekly_menu_status = :approvedStatus
              AND menu_day_date BETWEEN :from AND :to
            """, nativeQuery = true)
    TimeAdherenceCountsProjection getTimeAdherenceCounts(@Param("userId") UUID userId,
                                                         @Param("approvedStatus") String approvedStatus,
                                                         @Param("from") LocalDate from,
                                                         @Param("to") LocalDate to);

    @Query(value = """
            SELECT AVG(recipe_complexity_rating::numeric)
            FROM v_stat_menu_slot_fact
            WHERE user_id = :userId
              AND weekly_menu_status = :approvedStatus
              AND menu_day_date BETWEEN :from AND :to
              AND recipe_id IS NOT NULL
            """, nativeQuery = true)
    BigDecimal getAvgComplexity(@Param("userId") UUID userId,
                                @Param("approvedStatus") String approvedStatus,
                                @Param("from") LocalDate from,
                                @Param("to") LocalDate to);

    @Query(value = """
            SELECT
                COUNT(*) FILTER (WHERE recipe_id IS NOT NULL AND profile_simplicity IS NOT NULL)::int AS complexity_constraints_cnt,
                COUNT(*) FILTER (
                    WHERE recipe_id IS NOT NULL
                      AND profile_simplicity IS NOT NULL
                      AND recipe_complexity_rating <= profile_simplicity
                )::int AS within_complexity_cnt
            FROM v_stat_menu_slot_fact
            WHERE user_id = :userId
              AND weekly_menu_status = :approvedStatus
              AND menu_day_date BETWEEN :from AND :to
            """, nativeQuery = true)
    ComplexityAdherenceCountsProjection getComplexityAdherenceCounts(@Param("userId") UUID userId,
                                                                     @Param("approvedStatus") String approvedStatus,
                                                                     @Param("from") LocalDate from,
                                                                     @Param("to") LocalDate to);

    @Query(value = """
            SELECT AVG(EXTRACT(EPOCH FROM (weekly_menu_updated_at - weekly_menu_created_at)) / 60.0)::numeric
            FROM (
                SELECT DISTINCT weekly_menu_id, weekly_menu_created_at, weekly_menu_updated_at
                FROM v_stat_menu_slot_fact
                WHERE user_id = :userId
                  AND weekly_menu_status = :approvedStatus
                  AND menu_day_date BETWEEN :from AND :to
            ) t
            """, nativeQuery = true)
    BigDecimal getApprovalSpeedMinutesAvg(@Param("userId") UUID userId,
                                          @Param("approvedStatus") String approvedStatus,
                                          @Param("from") LocalDate from,
                                          @Param("to") LocalDate to);


    @Query(value = """
            SELECT
                COUNT(*) FILTER (WHERE recipe_source_type = :aiSourceType AND recipe_id IS NOT NULL)::int AS ai_meals,
                COUNT(*) FILTER (WHERE recipe_id IS NOT NULL)::int AS all_meals,
                COUNT(*) FILTER (WHERE recipe_source_type = :aiSourceType AND recipe_status = :verifiedStatus)::int AS verified_cnt,
                COUNT(*) FILTER (WHERE recipe_source_type = :aiSourceType AND recipe_status = :rejectedStatus)::int AS rejected_cnt,
                COUNT(*) FILTER (WHERE recipe_source_type = :aiSourceType AND recipe_taste_rating IS NOT NULL)::int AS rated_cnt,
                AVG(recipe_taste_rating::numeric) FILTER (WHERE recipe_source_type = :aiSourceType AND recipe_taste_rating IS NOT NULL) AS avg_taste
            FROM v_stat_menu_slot_fact
            WHERE user_id = :userId
              AND weekly_menu_status = :approvedStatus
              AND menu_day_date BETWEEN :from AND :to
              AND recipe_id IS NOT NULL
            """, nativeQuery = true)
    AiAggregateStatProjection getAiAggregate(@Param("userId") UUID userId,
                                             @Param("approvedStatus") String approvedStatus,
                                             @Param("from") LocalDate from,
                                             @Param("to") LocalDate to,
                                             @Param("aiSourceType") String aiSourceType,
                                             @Param("verifiedStatus") String verifiedStatus,
                                             @Param("rejectedStatus") String rejectedStatus);

    @Query(value = """
            SELECT
                ingredient_category AS ingredient_category,
                COUNT(DISTINCT ingredient_id)::int AS items_cnt
            FROM v_stat_recipe_ingredient_fact
            WHERE user_id = :userId
              AND weekly_menu_status = :approvedStatus
              AND menu_day_date BETWEEN :from AND :to
              AND (:includeOptional = true OR ri_is_optional = false)
            GROUP BY ingredient_category
            ORDER BY items_cnt DESC, ingredient_category
            LIMIT :limit
            """, nativeQuery = true)
    List<IngredientCategoryTopProjection> getTopIngredientCategories(
            @Param("userId") UUID userId,
            @Param("approvedStatus") String approvedStatus,
            @Param("from") LocalDate from,
            @Param("to") LocalDate to,
            @Param("limit") int limit,
            @Param("includeOptional") boolean includeOptional
    );


    @Query(value = """
            SELECT
                ingredient_id AS ingredient_id,
                ingredient_name_uk AS ingredient_name_uk,
                ri_unit AS ri_unit,
                SUM(ri_quantity)::numeric AS total_quantity
            FROM v_stat_recipe_ingredient_fact
            WHERE user_id = :userId
              AND weekly_menu_status = :approvedStatus
              AND menu_day_date BETWEEN :from AND :to
              AND (:includeOptional = true OR ri_is_optional = false)
            GROUP BY ingredient_id, ingredient_name_uk, ri_unit
            ORDER BY total_quantity DESC
            LIMIT :limit
            """, nativeQuery = true)
    List<TopIngredientProjection> getTopIngredients(
            @Param("userId") UUID userId,
            @Param("approvedStatus") String approvedStatus,
            @Param("from") LocalDate from,
            @Param("to") LocalDate to,
            @Param("limit") int limit,
            @Param("includeOptional") boolean includeOptional
    );

    @Query(value = """
            WITH RECURSIVE chain AS (
                SELECT s.id, s.start_date
                FROM (
                    SELECT wm.id, wm.start_date
                    FROM weekly_menu wm
                    WHERE wm.user_id = :userId
                      AND wm.status = :approvedStatus
                      AND wm.start_date <= current_date
                      AND current_date <= (wm.start_date + 6)
                    ORDER BY wm.start_date DESC
                    LIMIT 1
                ) s
            
                UNION ALL
            
                SELECT prev.id, prev.start_date
                FROM weekly_menu prev
                JOIN chain c
                  ON prev.start_date = (c.start_date - 7)
                WHERE prev.user_id = :userId
                  AND prev.status = :approvedStatus
            )
            SELECT COUNT(*)::int FROM chain
            """, nativeQuery = true)
    Integer getStreakWeeks(@Param("userId") UUID userId,
                           @Param("approvedStatus") String approvedStatus);

    @Query(value = """
            WITH menus AS (
                SELECT DISTINCT wm.start_date AS start_date
                FROM weekly_menu wm
                JOIN menu_day md
                  ON md.weekly_menu_id = wm.id
                WHERE wm.user_id = :userId
                  AND wm.status = :approvedStatus
                  AND md.date BETWEEN :from AND :to
            ),
            seq AS (
                SELECT
                    start_date,
                    start_date - ((row_number() OVER (ORDER BY start_date))::int * 7) AS grp
                FROM menus
            ),
            grp AS (
                SELECT grp, COUNT(*)::int AS cnt
                FROM seq
                GROUP BY grp
            )
            SELECT COALESCE(MAX(cnt), 0)::int FROM grp
            """, nativeQuery = true)
    Integer getMaxStreakWeeksInPeriod(@Param("userId") UUID userId,
                                      @Param("approvedStatus") String approvedStatus,
                                      @Param("from") LocalDate from,
                                      @Param("to") LocalDate to);


}

