package com.nure.whatwecook.service.reports.pdf;

import com.nure.whatwecook.service.helper.pdf.PdfDocument;

public interface PdfReportGenerator<RQ> {
    PdfReportType type();
    Class<RQ> requestType();
    PdfDocument generate(RQ request);
}
