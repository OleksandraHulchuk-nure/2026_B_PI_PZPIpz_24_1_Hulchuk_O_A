import { NewManualRecipePageClient } from '@/components/recipes/new/NewManualRecipePageClient';

export default function NewRecipePage() {
    return <NewManualRecipePageClient />;
}
