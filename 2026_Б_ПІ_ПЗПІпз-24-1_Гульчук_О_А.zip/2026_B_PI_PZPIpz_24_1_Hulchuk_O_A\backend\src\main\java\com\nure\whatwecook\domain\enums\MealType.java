package com.nure.whatwecook.domain.enums;

import lombok.Getter;

@Getter
public enum MealType {

    BREAKFAST("Сніданок"),
    LUNCH("Обід"),
    DINNER("Вечеря"),
    SNACK("Перекус");

    private final String ukrainianName;

    MealType(String ukrainianName) {
        this.ukrainianName = ukrainianName;
    }

}
