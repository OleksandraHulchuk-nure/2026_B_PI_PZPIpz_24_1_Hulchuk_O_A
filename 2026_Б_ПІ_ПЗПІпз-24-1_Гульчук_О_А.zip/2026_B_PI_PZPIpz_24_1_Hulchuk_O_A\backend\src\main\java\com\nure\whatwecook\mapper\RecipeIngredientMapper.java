package com.nure.whatwecook.mapper;

import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.entity.recipe.RecipeIngredient;
import com.nure.whatwecook.dto.recipe.RecipeIngredientDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.util.List;
import java.util.Map;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface RecipeIngredientMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "recipe", ignore = true)
    @Mapping(target = "ingredient", expression = "java(ingredientMap.get(dto.getIngredientId().toString()))")
    RecipeIngredient toEntity(RecipeIngredientDto dto, Map<String, Ingredient> ingredientMap);

    @Mapping(target = "ingredientId", source = "ingredient.id")
    @Mapping(target = "ingredientNameUk", source = "ingredient.nameUk")
    @Mapping(target = "category", source = "ingredient.category")
    @Mapping(target = "defaultUnit", source = "ingredient.defaultUnit")
    RecipeIngredientDto toDto(RecipeIngredient entity);

    List<RecipeIngredientDto> toDtoList(List<RecipeIngredient> entities);
}
