export function toIsoDate(d: Date): string {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
}

export function addDays(date: Date, days: number): Date {
    const d = new Date(date);
    d.setDate(d.getDate() + days);
    return d;
}

export function startOfWeek(date: Date): Date {
    const d = new Date(date);
    const day = d.getDay(); // 0..6 (Sun..Sat)
    const diffToMonday = (day === 0 ? -6 : 1) - day;
    d.setDate(d.getDate() + diffToMonday);
    d.setHours(0, 0, 0, 0);
    return d;
}

export function formatUkDayShort(isoDate: string): string {
    const d = new Date(`${isoDate}T00:00:00`);
    return new Intl.DateTimeFormat('uk-UA', { weekday: 'short' }).format(d);
}

export function formatUkDateShort(isoDate: string): string {
    const d = new Date(`${isoDate}T00:00:00`);
    return new Intl.DateTimeFormat('uk-UA', { day: '2-digit', month: '2-digit' }).format(d);
}

export function formatWeekRange(startIso: string): string {
    const start = new Date(`${startIso}T00:00:00`);
    const end = addDays(start, 6);
    const startFmt = new Intl.DateTimeFormat('uk-UA', { day: '2-digit', month: 'long' }).format(start);
    const endFmt = new Intl.DateTimeFormat('uk-UA', { day: '2-digit', month: 'long' }).format(end);
    return `${startFmt} — ${endFmt}`;
}

export function toMondayIso(iso: string): string {
    const d = new Date(`${iso}T00:00:00`);
    const monday = startOfWeek(d);
    return toIsoDate(monday);
}
