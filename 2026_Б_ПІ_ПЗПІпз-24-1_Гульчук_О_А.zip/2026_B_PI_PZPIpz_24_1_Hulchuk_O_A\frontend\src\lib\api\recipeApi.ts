import {apiFetch} from '@/lib/api/apiClient';
import {API_ROUTES} from '@/lib/api/endpoints';
import {getAuthToken} from '@/lib/auth/tokenStorage';
import {
    MEAL_TYPE_OPTIONS,
    type MealType,
    type MeasurementUnit,
    MENU_TYPE_OPTIONS,
    type MenuType,
    type ProductCategory,
    type RecipeSourceType,
    type RecipeStatus,
    UNIT_OPTIONS,
} from '@/lib/constants/enums';

export type {MealType, MeasurementUnit, MenuType, ProductCategory, RecipeSourceType, RecipeStatus} from '@/lib/constants/enums';

export type SortDirection = 'ASC' | 'DESC';

export type RecipeSortField =
    | 'CREATED_AT'
    | 'NAME'
    | 'TOTAL_TIME_MINUTES'
    | 'TASTE_RATING'
    | 'COMPLEXITY_RATING';

export interface RecipeSortDto {
    field: RecipeSortField;
    direction: SortDirection;
}

export interface RecipeListItem {
    id: string;
    name: string;
    sourceType: RecipeSourceType;
    status: RecipeStatus;
    menuType?: MenuType;
    mealType?: MealType;
    totalTimeMinutes?: number;
    activeCookingTimeMinutes?: number;
    defaultServings?: number;
    complexityRating?: number;
    tasteRating?: number;
}

export interface RecipeSearchPage {
    totalCount: number;
    page: number; // 0-based
    size: number;
    hasNext: boolean;
    items: RecipeListItem[];
}

export interface RecipeListFilters {
    status?: RecipeStatus;
    sourceType?: RecipeSourceType;
    mealType?: MealType;
    maxTime?: number;
    search?: string;

    page?: number;
    size?: number;

    sort?: RecipeSortDto;
}

type RecipeSearchRequestDto = {
    search?: string;
    status?: RecipeStatus;
    sourceType?: RecipeSourceType;
    mealType?: MealType;
    maxTotalTimeMinutes?: number;
    pagination?: { page: number; size: number };
    sort?: RecipeSortDto;
};

export async function getRecipes(filters: RecipeListFilters = {}): Promise<RecipeSearchPage> {
    const body: RecipeSearchRequestDto = {
        search: filters.search || undefined,
        status: filters.status,
        sourceType: filters.sourceType,
        mealType: filters.mealType,
        maxTotalTimeMinutes: typeof filters.maxTime === 'number' ? filters.maxTime : undefined,
        pagination: {
            page: typeof filters.page === 'number' ? filters.page : 0,
            size: typeof filters.size === 'number' ? filters.size : 20,
        },
        sort: filters.sort,
    };

    return apiFetch<RecipeSearchPage>(API_ROUTES.recipes.root, {
        method: 'POST',
        body: JSON.stringify(body),
    });
}

export {MEAL_TYPE_OPTIONS, MENU_TYPE_OPTIONS, UNIT_OPTIONS};


export type RecipeIngredientDto = {
    ingredientId: string;
    quantity: number;
    unit: MeasurementUnit;
    optional?: boolean;
};

export type AiRecipeGenerateRequestDto = {
    mealType: MealType;
    menuType?: MenuType;
    servings?: number;
    preferredIngredientIds?: string[];
    additionalNotes?: string;
};

export type AiRecipeDraftIngredientDto = {
    ingredientId?: string | null;
    ingredientNameUk: string;
    ingredientNameEn?: string | null;
    category?: ProductCategory | null;
    defaultUnit?: MeasurementUnit | null;
    quantity: number;
    unit?: MeasurementUnit | null;
    optional?: boolean;
};

export type AiRecipeDraftDto = {
    name: string;
    description?: string | null;
    menuType?: MenuType | null;
    mealType: MealType;
    activeCookingTimeMinutes?: number | null;
    totalTimeMinutes: number;
    defaultServings: number;
    complexityRating: number;
    steps: string[];
    ingredients: AiRecipeDraftIngredientDto[];
};

export type RecipeCreateRequestDto = {
    name: string;
    description?: string;
    menuType?: MenuType;
    mealType?: MealType;
    activeCookingTimeMinutes?: number;
    totalTimeMinutes?: number;
    defaultServings?: number;
    ingredients?: RecipeIngredientDto[];
    steps?: string[];
    complexityRating?: number; // 1..5
};

export type RecipeUpdateRequestDto = Partial<Omit<RecipeCreateRequestDto, 'ingredients'>> & {
    ingredients?: RecipeIngredientDto[];
};

export type RecipeRatingUpdateRequestDto = {
    complexityRating?: number; // 1..5
    tasteRating?: number; // 1..5
    ratingComment?: string;
};

export type RecipeStatusUpdateRequestDto = {
    status: RecipeStatus;
};

export type RecipeDetailsDto = {
    id: string;
    name: string;
    description?: string;
    sourceType: RecipeSourceType;
    status: RecipeStatus;
    menuType: MenuType;
    mealType: MealType;
    activeCookingTimeMinutes?: number;
    totalTimeMinutes?: number;
    defaultServings?: number;

    complexityRating?: number;
    tasteRating?: number;
    ratingComment?: string;

    ingredients?: RecipeIngredientDto[];
    steps?: string[];

    createdAt?: string;
    updatedAt?: string;
};

export async function createManualRecipe(body: RecipeCreateRequestDto): Promise<RecipeDetailsDto> {
    return apiFetch<RecipeDetailsDto>(API_ROUTES.recipes.manual, {
        method: 'POST',
        body: JSON.stringify(body),
    });
}

export async function generateAiRecipeDraft(body: AiRecipeGenerateRequestDto): Promise<AiRecipeDraftDto> {
    return apiFetch<AiRecipeDraftDto>(API_ROUTES.recipes.aiGenerate, {
        method: 'POST',
        body: JSON.stringify(body),
    });
}

export async function saveAiRecipeDraft(body: AiRecipeDraftDto): Promise<RecipeDetailsDto> {
    return apiFetch<RecipeDetailsDto>(API_ROUTES.recipes.aiSave, {
        method: 'POST',
        body: JSON.stringify(body),
    });
}

export async function getRecipe(id: string): Promise<RecipeDetailsDto> {
    return apiFetch<RecipeDetailsDto>(`${API_ROUTES.recipes.root}/${id}`);
}

export async function updateRecipe(id: string, body: RecipeUpdateRequestDto): Promise<RecipeDetailsDto> {
    return apiFetch<RecipeDetailsDto>(`${API_ROUTES.recipes.root}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(body),
    });
}

export async function deleteRecipe(id: string): Promise<void> {
    return apiFetch<void>(`${API_ROUTES.recipes.root}/${id}`, {method: 'DELETE'});
}

export async function updateRecipeStatus(id: string, status: RecipeStatus): Promise<RecipeDetailsDto> {
    const body: RecipeStatusUpdateRequestDto = {status};
    return apiFetch<RecipeDetailsDto>(`${API_ROUTES.recipes.root}/${id}/status`, {
        method: 'PUT',
        body: JSON.stringify(body),
    });
}

export async function updateRecipeRating(id: string, body: RecipeRatingUpdateRequestDto): Promise<RecipeDetailsDto> {
    return apiFetch<RecipeDetailsDto>(`${API_ROUTES.recipes.root}/${id}/rating`, {
        method: 'POST',
        body: JSON.stringify(body),
    });
}

export async function uploadRecipeImage(id: string, file: File): Promise<void> {
    const fd = new FormData();
    fd.append('file', file);

    return apiFetch<void>(`${API_ROUTES.recipes.root}/${id}/image`, {
        method: 'POST',
        body: fd,
    });
}

export async function getRecipeImageBlob(id: string): Promise<Blob | null> {
    const base = process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:8080';
    const url = `${base}${API_ROUTES.recipes.root}/${id}/image`;

    const headers = new Headers();
    const {accessToken, tokenType} = getAuthToken();
    if (accessToken) headers.set('Authorization', `${tokenType || 'Bearer'} ${accessToken}`);

    const res = await fetch(url, {headers, credentials: 'include'});
    if (!res.ok) return null;
    return res.blob();
}
