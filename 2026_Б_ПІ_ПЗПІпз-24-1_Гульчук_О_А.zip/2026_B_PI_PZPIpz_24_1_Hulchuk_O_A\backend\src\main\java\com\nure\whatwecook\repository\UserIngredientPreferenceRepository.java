package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.profile.UserIngredientPreference;
import com.nure.whatwecook.domain.enums.IngredientPreferenceType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface UserIngredientPreferenceRepository extends JpaRepository<UserIngredientPreference, UUID> {

    List<UserIngredientPreference> findByUserId(UUID userId);

    List<UserIngredientPreference> findByUserIdAndPreferenceType(UUID userId, IngredientPreferenceType type);

    void deleteByUserId(UUID userId);
}
