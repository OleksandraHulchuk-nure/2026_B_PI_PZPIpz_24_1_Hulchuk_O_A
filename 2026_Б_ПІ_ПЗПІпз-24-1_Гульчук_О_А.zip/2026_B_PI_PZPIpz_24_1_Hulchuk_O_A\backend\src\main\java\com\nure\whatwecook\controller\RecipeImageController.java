package com.nure.whatwecook.controller;


import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.domain.entity.recipe.RecipeImage;
import com.nure.whatwecook.dto.recipe.RecipeImageUploadResponseDto;
import com.nure.whatwecook.service.RecipeImageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

@Tag(name = "Recipe images", description = "Upload and fetch recipe images")
@RestController
@RequestMapping("/api/recipes")
@RequiredArgsConstructor
public class RecipeImageController {

    private final CurrentUserProvider currentUserProvider;
    private final RecipeImageService recipeImageService;

    @Operation(summary = "Upload or replace primary recipe image")
    @PostMapping(path = "/{id}/image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<RecipeImageUploadResponseDto> uploadImage(
            @PathVariable("id") UUID recipeId,
            @RequestPart("file") MultipartFile file
    ) throws IOException {
        UUID userId = currentUserProvider.getCurrentUserId();

        recipeImageService.saveOrUpdatePrimaryImage(
                userId,
                recipeId,
                file.getBytes(),
                file.getContentType(),
                file.getOriginalFilename()
        );

        RecipeImageUploadResponseDto responseDto = new RecipeImageUploadResponseDto();
        responseDto.setImageUrl("/api/recipes/" + recipeId + "/image");

        return ResponseEntity.ok(responseDto);
    }

    @Operation(summary = "Get primary recipe image (jpeg/png)")
    @GetMapping("/{id}/image")
    public ResponseEntity<byte[]> getImage(@PathVariable("id") UUID recipeId) {
        UUID userId = currentUserProvider.getCurrentUserId();

        RecipeImage image = recipeImageService.getPrimaryImage(userId, recipeId);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_TYPE, image.getContentType())
                .body(image.getData());
    }
}
