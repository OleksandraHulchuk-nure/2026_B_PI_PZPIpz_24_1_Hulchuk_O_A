package com.nure.whatwecook.service.helper.pdf;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

@Slf4j
@Component
public class PdfFonts {

    private static final String FAMILY = "Segoe UI";

    private final byte[] regular;
    private final byte[] bold;

    public PdfFonts() {
        this.regular = loadBytes("fonts/segoeui.ttf");
        this.bold = loadBytes("fonts/segoeuib.ttf");
    }

    public void apply(PdfRendererBuilder builder) {
        if (regular != null) {
            builder.useFont(() -> new ByteArrayInputStream(regular), FAMILY, 400,
                    PdfRendererBuilder.FontStyle.NORMAL, true);
        } else {
            log.warn("PDF font not found: fonts/segoeui.ttf. Cyrillic may render as ####");
        }

        if (bold != null) {
            builder.useFont(() -> new ByteArrayInputStream(bold), FAMILY, 700,
                    PdfRendererBuilder.FontStyle.NORMAL, true);
        }
    }

    private byte[] loadBytes(String classpathLocation) {
        try (InputStream is = new ClassPathResource(classpathLocation).getInputStream()) {
            return is.readAllBytes();
        } catch (Exception e) {
            return null;
        }
    }
}

