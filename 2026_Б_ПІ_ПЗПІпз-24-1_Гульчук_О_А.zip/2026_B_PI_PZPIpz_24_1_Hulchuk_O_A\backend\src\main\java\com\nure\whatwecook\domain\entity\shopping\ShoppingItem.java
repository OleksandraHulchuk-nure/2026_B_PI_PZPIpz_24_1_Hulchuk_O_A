package com.nure.whatwecook.domain.entity.shopping;

import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.enums.MeasurementUnit;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(
        name = "shopping_item",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_shopping_item_list_ingredient",
                        columnNames = {"shopping_list_id", "ingredient_id"}
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShoppingItem {

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shopping_list_id", nullable = false)
    private ShoppingList shoppingList;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ingredient_id", nullable = false)
    private Ingredient ingredient;

    @Enumerated(EnumType.STRING)
    @Column(name = "quantity_unit", nullable = false, length = 32)
    private MeasurementUnit quantityUnit;

    @Column(name = "needed_quantity", nullable = false, precision = 10, scale = 2)
    private BigDecimal neededQuantity;

    @Column(name = "have_quantity", nullable = false, precision = 10, scale = 2)
    private BigDecimal haveQuantity;

    @PrePersist
    public void prePersist() {
        if (id == null) {
            id = UUID.randomUUID();
        }
        if (haveQuantity == null) {
            haveQuantity = BigDecimal.ZERO;
        }
    }
}
