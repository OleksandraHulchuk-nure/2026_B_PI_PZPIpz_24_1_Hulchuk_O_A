package com.nure.whatwecook.dto.shopping;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ShoppingItemHaveQuantityUpdateRequestDto {

    private BigDecimal haveQuantity;
}
