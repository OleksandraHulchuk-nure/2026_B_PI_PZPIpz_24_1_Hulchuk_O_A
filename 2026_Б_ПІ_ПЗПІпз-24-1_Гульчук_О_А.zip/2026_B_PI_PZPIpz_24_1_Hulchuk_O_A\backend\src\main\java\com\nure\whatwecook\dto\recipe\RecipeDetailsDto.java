package com.nure.whatwecook.dto.recipe;

import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MenuType;
import com.nure.whatwecook.domain.enums.RecipeSourceType;
import com.nure.whatwecook.domain.enums.RecipeStatus;
import lombok.Data;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Data
public class RecipeDetailsDto {

    private UUID id;
    private String name;
    private String description;
    private RecipeSourceType sourceType;
    private RecipeStatus status;
    private MenuType menuType;
    private MealType mealType;
    private Integer activeCookingTimeMinutes;
    private Integer totalTimeMinutes;
    private Integer defaultServings;
    private Integer complexityRating;
    private Integer tasteRating;
    private String ratingComment;
    private List<String> steps;
    private String imageUrl;
    private Instant createdAt;
    private Instant updatedAt;
    private List<RecipeIngredientDto> ingredients;
}
