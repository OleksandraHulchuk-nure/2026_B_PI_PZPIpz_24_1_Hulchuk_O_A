import Link from 'next/link';
import * as React from 'react';

import {Table} from '@/components/ui/table';
import {Badge} from '@/components/ui/badge';
import {MaterialIcon} from '@/components/ui/materialIcon';

import type {RecipeListItem, RecipeSortDto, RecipeSortField} from '@/lib/api/recipeApi';
import {
    formatMealType,
    formatMinutes,
    formatMinutesTableview,
    formatRecipeSource,
    formatRecipeStatus,
} from '@/lib/formatters/recipeFormatters';
import {statusBadgeVariant} from '@/components/recipes/utils';

const DEFAULT_DIR: Record<RecipeSortField, RecipeSortDto['direction']> = {
    CREATED_AT: 'DESC',
    NAME: 'ASC',
    TOTAL_TIME_MINUTES: 'ASC',
    TASTE_RATING: 'DESC',
    COMPLEXITY_RATING: 'DESC',
};

const tableBadgeClass = 'whitespace-nowrap px-2 py-0.5 text-[10px] tracking-[0.04em]';

function nextSort(current: RecipeSortDto, field: RecipeSortField): RecipeSortDto {
    if (current.field !== field) return {field, direction: DEFAULT_DIR[field]};
    return {field, direction: current.direction === 'ASC' ? 'DESC' : 'ASC'};
}

function SortHeader({
                        label,
                        field,
                        sort,
                        onChange,
                    }: {
    label: string;
    field: RecipeSortField;
    sort: RecipeSortDto;
    onChange: (next: RecipeSortDto) => void;
}) {
    const active = sort.field === field;
    const icon = !active ? 'unfold_more' : sort.direction === 'ASC' ? 'arrow_drop_up' : 'arrow_drop_down';

    return (
        <button
            type="button"
            className="inline-flex cursor-pointer items-center gap-1 whitespace-nowrap hover:text-text-primary"
            onClick={() => onChange(nextSort(sort, field))}
            title={`Сортувати за: ${label}`}
        >
            <span className="bg-primary-soft/60 text-xs uppercase tracking-[0.08em] text-text-muted">{label}</span>
            <MaterialIcon name={icon} className="text-[18px] opacity-80"/>
        </button>
    );
}

export function RecipeTable({
                                recipes,
                                sort,
                                onSortChange,
                            }: {
    recipes: RecipeListItem[];
    sort: RecipeSortDto;
    onSortChange: (next: RecipeSortDto) => void;
}) {
    return (
        <Table
            columns={[
                {key: 'name', header: <SortHeader label="Рецепт" field="NAME" sort={sort} onChange={onSortChange}/>},
                {key: 'mealType', header: 'Прийом їжі'},
                {
                    key: 'time',
                    header: <SortHeader label="Час, хв." field="TOTAL_TIME_MINUTES" sort={sort}
                                        onChange={onSortChange}/>,
                    align: 'right',
                },
                {key: 'status', header: 'Статус'},
                {key: 'source', header: 'Тип'},
                {
                    key: 'complexity',
                    header: <SortHeader label="Складність" field="COMPLEXITY_RATING" sort={sort} onChange={onSortChange}/>,
                    align: 'right',
                },
                {
                    key: 'taste',
                    header: <SortHeader label="Смак" field="TASTE_RATING" sort={sort} onChange={onSortChange}/>,
                    align: 'right',
                },
            ]}
            rows={recipes.map((r) => ({
                name: (
                    <div className="flex flex-col">
                        <Link href={`/recipes/${r.id}`} className="font-semibold hover:underline">
                            {r.name}
                        </Link>
                        <span className="text-[11px] text-text-muted">
                              Порції: {r.defaultServings ?? '—'} · Активний: {formatMinutes(r.activeCookingTimeMinutes)}
                        </span>
                    </div>
                ),
                mealType: <span className="whitespace-nowrap text-text-primary">{formatMealType(r.mealType)}</span>,
                time: <span className="whitespace-nowrap font-semibold">{formatMinutesTableview(r.totalTimeMinutes)}</span>,
                status: <Badge variant={statusBadgeVariant(r.status)} className={tableBadgeClass}>{formatRecipeStatus(r.status)}</Badge>,
                source: <Badge
                    variant={r.sourceType === 'AI' ? 'ai' : 'soft'}
                    className={tableBadgeClass}
                >
                    {formatRecipeSource(r.sourceType)}
                </Badge>,
                complexity: (
                    <span className="text-text-primary">
                        {r.complexityRating ? `${r.complexityRating}/5` : '—'}
                    </span>
                ),
                taste: (
                    <span className="text-text-primary">
                        {r.tasteRating ? `${r.tasteRating}/5` : '—'}
                    </span>
                ),
            }))}
        />
    );
}
