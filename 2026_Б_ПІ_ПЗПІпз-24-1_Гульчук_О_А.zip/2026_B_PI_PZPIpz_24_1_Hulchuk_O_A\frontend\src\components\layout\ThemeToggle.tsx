﻿'use client';

import {useEffect, useState} from 'react';

import {cn} from '@/lib/utils';

type Theme = 'light' | 'dark';
const STORAGE_KEY = 'whatwecook-theme';

export function ThemeToggle() {
    const [theme, setTheme] = useState<Theme>('light');
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        if (typeof window === 'undefined') return;

        let initial: Theme = 'light';
        const stored = window.localStorage.getItem(STORAGE_KEY) as Theme | null;

        if (stored === 'light' || stored === 'dark') {
            initial = stored;
        } else if (window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
            initial = 'dark';
        }

        // eslint-disable-next-line react-hooks/set-state-in-effect
        setTheme(initial);

        const root = document.documentElement;
        if (initial === 'dark') {
            root.classList.add('dark');
        } else {
            root.classList.remove('dark');
        }
        setMounted(true);
    }, []);

    const toggleTheme = () => {
        setTheme((prev) => {
            const next: Theme = prev === 'dark' ? 'light' : 'dark';

            const root = document.documentElement;
            if (next === 'dark') {
                root.classList.add('dark');
            } else {
                root.classList.remove('dark');
            }

            if (typeof window !== 'undefined') {
                window.localStorage.setItem(STORAGE_KEY, next);
            }

            return next;
        });
    };

    const isDark = theme === 'dark';

    if (!mounted) {
        return (
            <button
                type="button"
                aria-label="Перемкнути тему"
                className="h-10 w-10 rounded-2xl border border-border bg-surface/80"
            />
        );
    }

    return (
        <button
            type="button"
            onClick={toggleTheme}
            aria-label={isDark ? 'Увімкнути світлу тему' : 'Увімкнути темну тему'}
            className={cn(
                'flex h-10 w-10 items-center justify-center rounded-2xl border transition',
                isDark
                    ? 'border-primary bg-primary-soft text-text-primary hover:bg-primary hover:text-text-inverted'
                    : 'border-border bg-surface text-text-muted hover:bg-primary-soft hover:text-text-primary',
            )}
        >
            <span className="material-symbols-outlined text-[18px] leading-none">
                {isDark ? 'dark_mode' : 'light_mode'}
            </span>
        </button>
    );
}


