package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.config.ai.AiProperties;
import com.nure.whatwecook.config.exception.AiFeatureDisabledException;
import com.nure.whatwecook.config.exception.AiRecipeValidationException;
import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.entity.profile.UserIngredientPreference;
import com.nure.whatwecook.domain.entity.profile.UserMealPreference;
import com.nure.whatwecook.domain.entity.profile.UserProfile;
import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.entity.recipe.RecipeIngredient;
import com.nure.whatwecook.domain.enums.IngredientPreferenceType;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MeasurementUnit;
import com.nure.whatwecook.domain.enums.MenuType;
import com.nure.whatwecook.domain.enums.ProductCategory;
import com.nure.whatwecook.dto.ai.AiRecipeDraftDto;
import com.nure.whatwecook.dto.ai.AiRecipeDraftIngredientDto;
import com.nure.whatwecook.dto.ai.AiRecipeGenerateRequestDto;
import com.nure.whatwecook.dto.ai.AiRecipeLlmDraftDto;
import com.nure.whatwecook.dto.ai.AiRecipeLlmDraftIngredientDto;
import com.nure.whatwecook.repository.IngredientRepository;
import com.nure.whatwecook.repository.UserIngredientPreferenceRepository;
import com.nure.whatwecook.repository.UserMealPreferenceRepository;
import com.nure.whatwecook.repository.UserProfileRepository;
import com.nure.whatwecook.repository.projection.IngredientMatchProjection;
import com.nure.whatwecook.service.AiRecipeService;
import com.nure.whatwecook.service.RecipeService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.ai.converter.StructuredOutputConverter;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AiRecipeServiceImpl implements AiRecipeService {

    private static final String SYSTEM_PROMPT = "Return ONLY valid JSON matching schema. No markdown.";
    private static final int MAX_VALIDATION_RETRIES = 2;
    private static final int FAVORITE_SUGGESTION_LIMIT = 10;
    private static final int COMMON_SUGGESTION_LIMIT = 12;
    private static final double SEARCH_MATCH_THRESHOLD = 0.35d;
    private static final double ACCEPT_MATCH_THRESHOLD = 0.78d;
    private static final double ACCEPT_MATCH_THRESHOLD_WITH_CATEGORY = 0.70d;
    private static final StructuredOutputConverter<AiRecipeLlmDraftDto> DRAFT_OUTPUT_CONVERTER =
            new BeanOutputConverter<>(AiRecipeLlmDraftDto.class);

    private final AiProperties aiProperties;
    private final ObjectProvider<ChatModel> chatModelProvider;
    private final IngredientRepository ingredientRepository;
    private final UserProfileRepository userProfileRepository;
    private final UserMealPreferenceRepository userMealPreferenceRepository;
    private final UserIngredientPreferenceRepository userIngredientPreferenceRepository;
    private final RecipeService recipeService;

    @Override
    public AiRecipeDraftDto generateRecipeDraft(UUID userId, AiRecipeGenerateRequestDto request) {
        ensureAiEnabled();
        GenerationContext context = buildGenerationContext(userId, request, null);
        return generateRecipeDraft(context);
    }

    @Override
    @Transactional
    public Recipe saveGeneratedRecipe(UUID userId, AiRecipeDraftDto draft) {
        PersistableRecipe persistableRecipe = buildPersistableRecipe(userId, draft);
        return recipeService.createAiRecipe(userId, persistableRecipe.recipe(), persistableRecipe.ingredients());
    }

    @Override
    @Transactional
    public Recipe generateRecipeForMenuSlot(UUID userId,
                                            MealType mealType,
                                            Integer maxTimeMinutes,
                                            String extraNotes) {
        AiRecipeGenerateRequestDto request = new AiRecipeGenerateRequestDto();
        request.setMealType(mealType);
        request.setAdditionalNotes(extraNotes);

        GenerationContext context = buildGenerationContext(userId, request, maxTimeMinutes);
        AiRecipeDraftDto draft = generateRecipeDraft(context);
        return saveGeneratedRecipe(userId, draft);
    }

    private AiRecipeDraftDto generateRecipeDraft(GenerationContext context) {
        ChatModel chatModel = chatModelProvider.getIfAvailable();
        if (chatModel == null) {
            throw new AiFeatureDisabledException("AI recipe generation is not configured");
        }

        ChatClient chatClient = ChatClient.create(chatModel);
        log.info(
                "Starting AI recipe generation. provider={}, model={}, userId={}, mealType={}, menuType={}, servings={}, maxTotalTimeMinutes={}, preferredIngredientCount={}, suggestedIngredientCount={}",
                aiProperties.getProvider(),
                aiProperties.getModel(),
                context.userId(),
                context.request().getMealType(),
                context.effectiveMenuType(),
                context.effectiveServings(),
                context.maxTotalTimeMinutes(),
                context.preferredIngredients().size(),
                context.suggestedIngredients().size()
        );

        Map<String, String> validationErrors = Map.of();
        int attempts = 0;
        int maxAttempts = MAX_VALIDATION_RETRIES + 1;

        while (attempts < maxAttempts) {
            attempts++;
            String rawResponse = null;
            String finishReason = null;
            try {
                ChatClient.CallResponseSpec responseSpec = chatClient.prompt()
                        .system(SYSTEM_PROMPT)
                        .user(buildUserPrompt(context, validationErrors))
                        .call();

                ChatResponse chatResponse = responseSpec.chatResponse();
                rawResponse = extractResponseText(chatResponse);
                finishReason = extractFinishReason(chatResponse);

                AiRecipeLlmDraftDto llmDraft = DRAFT_OUTPUT_CONVERTER.convert(rawResponse);
                ValidationResult validationResult = validateGeneratedDraft(llmDraft, context);
                if (validationResult.isValid()) {
                    log.info(
                            "AI recipe generation succeeded. provider={}, model={}, userId={}, attempt={}, finishReason={}, recipeName={}, totalTimeMinutes={}, ingredientCount={}",
                            aiProperties.getProvider(),
                            aiProperties.getModel(),
                            context.userId(),
                            attempts,
                            finishReason,
                            validationResult.draft().getName(),
                            validationResult.draft().getTotalTimeMinutes(),
                            validationResult.draft().getIngredients().size()
                    );
                    return validationResult.draft();
                }

                validationErrors = validationResult.validationErrors();
                log.warn(
                        "AI recipe validation failed. provider={}, model={}, userId={}, attempt={}, finishReason={}, errors={}, preferredIngredientIds={}, rawResponse={}",
                        aiProperties.getProvider(),
                        aiProperties.getModel(),
                        context.userId(),
                        attempts,
                        finishReason,
                        validationErrors,
                        context.preferredIngredientIds(),
                        truncateForLog(rawResponse)
                );

                if (attempts >= maxAttempts) {
                    throw new AiRecipeValidationException("AI recipe draft validation failed", validationErrors);
                }
            }
            catch (AiRecipeValidationException ex) {
                throw ex;
            }
            catch (Exception ex) {
                log.warn(
                        "AI recipe generation failed to parse structured output. provider={}, model={}, userId={}, attempt={}, finishReason={}, error={}, rawResponse={}",
                        aiProperties.getProvider(),
                        aiProperties.getModel(),
                        context.userId(),
                        attempts,
                        finishReason,
                        ex.getMessage(),
                        truncateForLog(rawResponse)
                );
                validationErrors = Map.of(
                        "response",
                        "Model response could not be parsed into the recipe draft schema"
                );
                if (attempts >= maxAttempts) {
                    throw new AiRecipeValidationException("AI recipe draft validation failed", validationErrors);
                }
            }
        }

        throw new AiRecipeValidationException("AI recipe draft validation failed", validationErrors);
    }

    private GenerationContext buildGenerationContext(UUID userId,
                                                     AiRecipeGenerateRequestDto request,
                                                     Integer requestedMaxTimeOverride) {
        UserProfile userProfile = userProfileRepository.findById(userId).orElse(null);
        UserMealPreference mealPreference = userMealPreferenceRepository
                .findByUserIdAndMealType(userId, request.getMealType())
                .orElse(null);

        List<UserIngredientPreference> ingredientPreferences = userIngredientPreferenceRepository.findByUserId(userId);
        Map<IngredientPreferenceType, List<Ingredient>> ingredientsByPreference = ingredientPreferences.stream()
                .filter(preference -> preference.getIngredient() != null)
                .collect(Collectors.groupingBy(
                        UserIngredientPreference::getPreferenceType,
                        () -> new EnumMap<>(IngredientPreferenceType.class),
                        Collectors.mapping(UserIngredientPreference::getIngredient, Collectors.toList())
                ));

        List<Ingredient> favorites = uniqueIngredients(
                ingredientsByPreference.getOrDefault(IngredientPreferenceType.FAVORITE, List.of())
        );
        List<Ingredient> disliked = uniqueIngredients(
                ingredientsByPreference.getOrDefault(IngredientPreferenceType.DISLIKED, List.of())
        );
        List<Ingredient> allergies = uniqueIngredients(
                ingredientsByPreference.getOrDefault(IngredientPreferenceType.ALLERGY, List.of())
        );
        List<Ingredient> exclusions = uniqueIngredients(
                ingredientsByPreference.getOrDefault(IngredientPreferenceType.EXCLUSION, List.of())
        );

        Set<UUID> hardExcludedIds = new LinkedHashSet<>();
        allergies.forEach(ingredient -> hardExcludedIds.add(ingredient.getId()));
        exclusions.forEach(ingredient -> hardExcludedIds.add(ingredient.getId()));

        Set<String> hardExcludedNames = new LinkedHashSet<>();
        allergies.forEach(ingredient -> hardExcludedNames.add(normalizeIngredientName(ingredient.getNameUk())));
        exclusions.forEach(ingredient -> hardExcludedNames.add(normalizeIngredientName(ingredient.getNameUk())));

        List<Ingredient> preferredIngredients = resolvePreferredIngredients(request, hardExcludedIds);
        List<Ingredient> suggestedIngredients = resolveSuggestedIngredients(preferredIngredients, favorites, hardExcludedIds);
        if (preferredIngredients.isEmpty() && suggestedIngredients.isEmpty()) {
            throw new IllegalArgumentException("No eligible ingredients available for AI recipe generation");
        }

        Integer maxTotalTime = mealPreference != null ? mealPreference.getMaxCookingTimeMinutes() : null;
        if (requestedMaxTimeOverride != null && requestedMaxTimeOverride > 0) {
            maxTotalTime = maxTotalTime == null
                    ? requestedMaxTimeOverride
                    : Math.min(maxTotalTime, requestedMaxTimeOverride);
        }

        MenuType effectiveMenuType = request.getMenuType() != null
                ? request.getMenuType()
                : userProfile != null ? userProfile.getMenuType() : null;
        int effectiveServings = request.getServings() != null
                ? request.getServings()
                : userProfile != null && userProfile.getFamilySize() != null
                ? userProfile.getFamilySize()
                : 2;

        Set<UUID> preferredIngredientIds = preferredIngredients.stream()
                .map(Ingredient::getId)
                .collect(Collectors.toCollection(LinkedHashSet::new));

        return new GenerationContext(
                userId,
                request,
                effectiveMenuType,
                effectiveServings,
                maxTotalTime,
                userProfile != null ? userProfile.getSimplicity() : null,
                preferredIngredients,
                suggestedIngredients,
                preferredIngredientIds,
                favorites,
                disliked,
                allergies,
                exclusions,
                hardExcludedIds,
                hardExcludedNames.stream()
                        .filter(Objects::nonNull)
                        .collect(Collectors.toCollection(LinkedHashSet::new))
        );
    }

    private List<Ingredient> resolvePreferredIngredients(AiRecipeGenerateRequestDto request,
                                                         Set<UUID> hardExcludedIds) {
        if (request.getPreferredIngredientIds() == null || request.getPreferredIngredientIds().isEmpty()) {
            return List.of();
        }

        List<UUID> uniquePreferredIds = request.getPreferredIngredientIds().stream()
                .filter(Objects::nonNull)
                .distinct()
                .toList();
        List<Ingredient> preferredIngredients = ingredientRepository.findByIdIn(uniquePreferredIds);
        if (preferredIngredients.size() != uniquePreferredIds.size()) {
            throw new EntityNotFoundException("Some preferred ingredient IDs were not found");
        }

        List<Ingredient> filteredPreferredIngredients = preferredIngredients.stream()
                .filter(ingredient -> !hardExcludedIds.contains(ingredient.getId()))
                .sorted(Comparator.comparing(Ingredient::getNameUk, String.CASE_INSENSITIVE_ORDER))
                .toList();

        if (filteredPreferredIngredients.size() != preferredIngredients.size()) {
            throw new IllegalArgumentException("Preferred ingredients conflict with allergy/exclusion rules");
        }

        return filteredPreferredIngredients;
    }

    private List<Ingredient> resolveSuggestedIngredients(List<Ingredient> preferredIngredients,
                                                         List<Ingredient> favorites,
                                                         Set<UUID> hardExcludedIds) {
        LinkedHashMap<UUID, Ingredient> suggestions = new LinkedHashMap<>();

        preferredIngredients.forEach(ingredient -> suggestions.putIfAbsent(ingredient.getId(), ingredient));
        favorites.stream()
                .filter(ingredient -> !hardExcludedIds.contains(ingredient.getId()))
                .limit(FAVORITE_SUGGESTION_LIMIT)
                .forEach(ingredient -> suggestions.putIfAbsent(ingredient.getId(), ingredient));

        ingredientRepository.findAll(PageRequest.of(0, COMMON_SUGGESTION_LIMIT, Sort.by(Sort.Direction.ASC, "nameUk")))
                .getContent()
                .stream()
                .filter(ingredient -> !hardExcludedIds.contains(ingredient.getId()))
                .forEach(ingredient -> suggestions.putIfAbsent(ingredient.getId(), ingredient));

        return new ArrayList<>(suggestions.values());
    }

    private ValidationResult validateGeneratedDraft(AiRecipeLlmDraftDto llmDraft, GenerationContext context) {
        Map<String, String> errors = new LinkedHashMap<>();
        if (llmDraft == null) {
            errors.put("draft", "Draft payload is missing");
            return ValidationResult.invalid(errors);
        }

        AiRecipeDraftDto normalized = new AiRecipeDraftDto();
        normalized.setName(trimToNull(llmDraft.getName()));
        normalized.setDescription(trimToNull(llmDraft.getDescription()));
        normalized.setMealType(context.request().getMealType());
        normalized.setMenuType(resolveMenuType(llmDraft.getMenuType(), context.effectiveMenuType(), errors));
        normalized.setActiveCookingTimeMinutes(llmDraft.getActiveCookingTimeMinutes());
        normalized.setTotalTimeMinutes(llmDraft.getTotalTimeMinutes());
        normalized.setDefaultServings(
                llmDraft.getDefaultServings() != null ? llmDraft.getDefaultServings() : context.effectiveServings()
        );
        normalized.setComplexityRating(resolveComplexity(llmDraft.getComplexityRating()));
        normalized.setSteps(cleanSteps(llmDraft.getSteps()));

        validateScalarFields(normalized, context, errors);

        Set<String> duplicateIngredientKeys = new LinkedHashSet<>();
        Set<UUID> includedPreferredIngredientIds = new LinkedHashSet<>();
        List<AiRecipeDraftIngredientDto> normalizedIngredients = new ArrayList<>();
        List<AiRecipeLlmDraftIngredientDto> llmIngredients = llmDraft.getIngredients();
        if (llmIngredients == null || llmIngredients.isEmpty()) {
            errors.put("ingredients", "At least one ingredient is required");
        }
        else {
            for (int index = 0; index < llmIngredients.size(); index++) {
                AiRecipeLlmDraftIngredientDto rawIngredient = llmIngredients.get(index);
                if (rawIngredient == null) {
                    errors.put("ingredients[" + index + "]", "Ingredient item is missing");
                    continue;
                }

                String fieldPrefix = "ingredients[" + index + "]";
                String ingredientNameUk = trimToNull(rawIngredient.getIngredientNameUk());
                String ingredientNameEn = trimToNull(rawIngredient.getIngredientNameEn());
                if (ingredientNameUk == null) {
                    errors.put(fieldPrefix + ".ingredientNameUk", "Ingredient name in Ukrainian is required");
                    continue;
                }
                if (rawIngredient.getQuantity() == null || rawIngredient.getQuantity().compareTo(BigDecimal.ZERO) <= 0) {
                    errors.put(fieldPrefix + ".quantity", "Quantity must be greater than zero");
                    continue;
                }

                ProductCategory requestedCategory = resolveProductCategory(rawIngredient.getCategory());
                Ingredient matchedIngredient = findBestIngredientMatch(ingredientNameUk, ingredientNameEn, requestedCategory);

                if (matchedIngredient != null && context.hardExcludedIngredientIds().contains(matchedIngredient.getId())) {
                    errors.put(fieldPrefix + ".ingredientNameUk", "Ingredient violates allergy/exclusion rules");
                    continue;
                }
                if (matchedIngredient == null && isHardExcludedByName(ingredientNameUk, ingredientNameEn, context)) {
                    errors.put(fieldPrefix + ".ingredientNameUk", "Ingredient violates allergy/exclusion rules");
                    continue;
                }

                ProductCategory category = matchedIngredient != null
                        ? matchedIngredient.getCategory()
                        : defaultProductCategory(rawIngredient.getCategory());
                MeasurementUnit defaultUnit = matchedIngredient != null
                        ? matchedIngredient.getDefaultUnit()
                        : resolveDefaultUnitForNewIngredient(rawIngredient.getDefaultUnit(), rawIngredient.getUnit());
                MeasurementUnit recipeUnit = resolveMeasurementUnit(
                        rawIngredient.getUnit(),
                        matchedIngredient != null ? matchedIngredient.getDefaultUnit() : defaultUnit
                );

                String duplicateKey = matchedIngredient != null
                        ? "id:" + matchedIngredient.getId()
                        : "name:" + normalizeIngredientName(ingredientNameUk);
                if (!duplicateIngredientKeys.add(duplicateKey)) {
                    errors.put(fieldPrefix + ".ingredientNameUk", "Duplicate ingredients are not allowed");
                    continue;
                }

                AiRecipeDraftIngredientDto normalizedIngredient = new AiRecipeDraftIngredientDto();
                normalizedIngredient.setIngredientId(matchedIngredient != null ? matchedIngredient.getId() : null);
                normalizedIngredient.setIngredientNameUk(matchedIngredient != null ? matchedIngredient.getNameUk() : ingredientNameUk);
                normalizedIngredient.setIngredientNameEn(matchedIngredient != null
                        ? coalesce(trimToNull(matchedIngredient.getNameEn()), ingredientNameEn)
                        : ingredientNameEn);
                normalizedIngredient.setCategory(category);
                normalizedIngredient.setDefaultUnit(defaultUnit);
                normalizedIngredient.setQuantity(rawIngredient.getQuantity());
                normalizedIngredient.setUnit(recipeUnit);
                normalizedIngredient.setOptional(Boolean.TRUE.equals(rawIngredient.getOptional()));
                normalizedIngredients.add(normalizedIngredient);

                if (matchedIngredient != null && context.preferredIngredientIds().contains(matchedIngredient.getId())) {
                    includedPreferredIngredientIds.add(matchedIngredient.getId());
                }
            }
        }

        normalized.setIngredients(normalizedIngredients);

        List<Ingredient> missingPreferredIngredients = context.preferredIngredients().stream()
                .filter(ingredient -> !includedPreferredIngredientIds.contains(ingredient.getId()))
                .toList();
        if (!missingPreferredIngredients.isEmpty()) {
            errors.put(
                    "ingredients",
                    "Recipe must include all preferred ingredients: " + missingPreferredIngredients.stream()
                            .map(Ingredient::getNameUk)
                            .collect(Collectors.joining(", "))
            );
        }

        if (!errors.isEmpty()) {
            return ValidationResult.invalid(errors);
        }
        return ValidationResult.valid(normalized);
    }

    private void validateScalarFields(AiRecipeDraftDto draft,
                                      GenerationContext context,
                                      Map<String, String> errors) {
        if (draft.getName() == null) {
            errors.put("name", "Recipe name is required");
        }
        if (draft.getTotalTimeMinutes() == null || draft.getTotalTimeMinutes() <= 0) {
            errors.put("totalTimeMinutes", "Total time must be present and greater than zero");
        }
        if (draft.getDefaultServings() == null || draft.getDefaultServings() <= 0) {
            errors.put("defaultServings", "Default servings must be present and greater than zero");
        }
        if (draft.getActiveCookingTimeMinutes() != null && draft.getActiveCookingTimeMinutes() <= 0) {
            errors.put("activeCookingTimeMinutes", "Active cooking time must be greater than zero");
        }
        if (draft.getActiveCookingTimeMinutes() != null
                && draft.getTotalTimeMinutes() != null
                && draft.getActiveCookingTimeMinutes() > draft.getTotalTimeMinutes()) {
            errors.put("activeCookingTimeMinutes", "Active cooking time cannot exceed total time");
        }
        if (draft.getTotalTimeMinutes() != null
                && context.maxTotalTimeMinutes() != null
                && draft.getTotalTimeMinutes() > context.maxTotalTimeMinutes()) {
            errors.put(
                    "totalTimeMinutes",
                    "Total time must be less than or equal to " + context.maxTotalTimeMinutes() + " minutes"
            );
        }
        if (draft.getSteps() == null || draft.getSteps().isEmpty()) {
            errors.put("steps", "At least one non-empty step is required");
        }
    }

    private PersistableRecipe buildPersistableRecipe(UUID userId, AiRecipeDraftDto draft) {
        Map<String, String> errors = new LinkedHashMap<>();

        Map<UUID, Ingredient> ingredientsById = new LinkedHashMap<>(loadIngredients(
                draft.getIngredients() == null
                        ? List.of()
                        : draft.getIngredients().stream()
                        .map(AiRecipeDraftIngredientDto::getIngredientId)
                        .filter(Objects::nonNull)
                        .distinct()
                        .toList()
        ));
        Map<String, Ingredient> createdIngredientsByName = new LinkedHashMap<>();

        Recipe recipe = new Recipe();
        recipe.setName(trimToNull(draft.getName()));
        recipe.setDescription(trimToNull(draft.getDescription()));
        recipe.setMenuType(draft.getMenuType());
        recipe.setMealType(draft.getMealType());
        recipe.setActiveCookingTimeMinutes(draft.getActiveCookingTimeMinutes());
        recipe.setTotalTimeMinutes(draft.getTotalTimeMinutes());
        recipe.setDefaultServings(draft.getDefaultServings());
        recipe.setComplexityRating(
                draft.getComplexityRating() != null && draft.getComplexityRating() > 0 ? draft.getComplexityRating() : 1
        );
        recipe.setSteps(cleanSteps(draft.getSteps()));

        validatePersistableRecipe(recipe, errors);

        List<RecipeIngredient> recipeIngredients = new ArrayList<>();
        Set<UUID> seenIngredientIds = new LinkedHashSet<>();
        if (draft.getIngredients() == null || draft.getIngredients().isEmpty()) {
            errors.put("ingredients", "At least one ingredient is required");
        }
        else {
            for (int index = 0; index < draft.getIngredients().size(); index++) {
                AiRecipeDraftIngredientDto draftIngredient = draft.getIngredients().get(index);
                if (draftIngredient == null) {
                    errors.put("ingredients[" + index + "]", "Ingredient item is missing");
                    continue;
                }

                String fieldPrefix = "ingredients[" + index + "]";
                String ingredientNameUk = trimToNull(draftIngredient.getIngredientNameUk());
                if (ingredientNameUk == null) {
                    errors.put(fieldPrefix + ".ingredientNameUk", "Ingredient name in Ukrainian is required");
                    continue;
                }
                if (draftIngredient.getQuantity() == null || draftIngredient.getQuantity().compareTo(BigDecimal.ZERO) <= 0) {
                    errors.put(fieldPrefix + ".quantity", "Quantity must be greater than zero");
                    continue;
                }

                Ingredient ingredient = resolveOrCreateIngredientForPersistence(
                        userId,
                        draftIngredient,
                        ingredientsById,
                        createdIngredientsByName
                );
                if (ingredient == null) {
                    errors.put(fieldPrefix + ".ingredientNameUk", "Ingredient could not be resolved");
                    continue;
                }
                if (!seenIngredientIds.add(ingredient.getId())) {
                    errors.put(fieldPrefix + ".ingredientNameUk", "Duplicate ingredients are not allowed");
                    continue;
                }

                RecipeIngredient recipeIngredient = RecipeIngredient.builder()
                        .ingredient(ingredient)
                        .quantity(draftIngredient.getQuantity())
                        .unit(draftIngredient.getUnit() != null ? draftIngredient.getUnit() : ingredient.getDefaultUnit())
                        .optional(draftIngredient.isOptional())
                        .build();
                recipeIngredients.add(recipeIngredient);
            }
        }

        if (!errors.isEmpty()) {
            throw new AiRecipeValidationException("AI recipe draft validation failed", errors);
        }

        return new PersistableRecipe(recipe, recipeIngredients);
    }

    private Ingredient resolveOrCreateIngredientForPersistence(UUID userId,
                                                               AiRecipeDraftIngredientDto draftIngredient,
                                                               Map<UUID, Ingredient> ingredientsById,
                                                               Map<String, Ingredient> createdIngredientsByName) {
        if (draftIngredient.getIngredientId() != null) {
            Ingredient ingredient = ingredientsById.get(draftIngredient.getIngredientId());
            if (ingredient != null) {
                return ingredient;
            }
        }

        String ingredientNameUk = trimToNull(draftIngredient.getIngredientNameUk());
        String ingredientNameEn = trimToNull(draftIngredient.getIngredientNameEn());
        Ingredient matchedIngredient = findBestIngredientMatch(ingredientNameUk, ingredientNameEn, draftIngredient.getCategory());
        if (matchedIngredient != null) {
            ingredientsById.put(matchedIngredient.getId(), matchedIngredient);
            return matchedIngredient;
        }

        String normalizedName = normalizeIngredientName(ingredientNameUk);
        if (normalizedName != null) {
            Ingredient createdIngredient = createdIngredientsByName.get(normalizedName);
            if (createdIngredient != null) {
                return createdIngredient;
            }
        }

        Ingredient createdIngredient = ingredientRepository.save(Ingredient.builder()
                .nameUk(ingredientNameUk)
                .nameEn(ingredientNameEn)
                .category(draftIngredient.getCategory() != null ? draftIngredient.getCategory() : ProductCategory.OTHER)
                .defaultUnit(draftIngredient.getDefaultUnit() != null
                        ? draftIngredient.getDefaultUnit()
                        : draftIngredient.getUnit() != null ? draftIngredient.getUnit() : MeasurementUnit.PIECE)
                .build());

        log.info(
                "Created new ingredient from AI draft. provider={}, model={}, userId={}, ingredientId={}, nameUk={}, category={}, defaultUnit={}",
                aiProperties.getProvider(),
                aiProperties.getModel(),
                userId,
                createdIngredient.getId(),
                createdIngredient.getNameUk(),
                createdIngredient.getCategory(),
                createdIngredient.getDefaultUnit()
        );

        ingredientsById.put(createdIngredient.getId(), createdIngredient);
        if (normalizedName != null) {
            createdIngredientsByName.put(normalizedName, createdIngredient);
        }
        return createdIngredient;
    }

    private Ingredient findBestIngredientMatch(String ingredientNameUk,
                                               String ingredientNameEn,
                                               ProductCategory category) {
        Ingredient exactMatch = findExactIngredientMatch(ingredientNameUk, ingredientNameEn);
        if (exactMatch != null) {
            return exactMatch;
        }

        Ingredient categoryMatch = findBestProjectedIngredientMatch(ingredientNameUk, ingredientNameEn, category);
        if (categoryMatch != null) {
            return categoryMatch;
        }

        if (category != null) {
            return findBestProjectedIngredientMatch(ingredientNameUk, ingredientNameEn, null);
        }
        return null;
    }

    private Ingredient findExactIngredientMatch(String ingredientNameUk, String ingredientNameEn) {
        Optional<Ingredient> byUkrainianName = Optional.ofNullable(ingredientNameUk)
                .flatMap(ingredientRepository::findFirstByNameUkIgnoreCase);
        if (byUkrainianName.isPresent()) {
            return byUkrainianName.get();
        }

        return Optional.ofNullable(ingredientNameEn)
                .flatMap(ingredientRepository::findFirstByNameEnIgnoreCase)
                .orElse(null);
    }

    private Ingredient findBestProjectedIngredientMatch(String ingredientNameUk,
                                                        String ingredientNameEn,
                                                        ProductCategory category) {
        Map<UUID, Double> rankedCandidateIds = new LinkedHashMap<>();
        collectProjectedMatches(rankedCandidateIds, ingredientNameUk, category);
        collectProjectedMatches(rankedCandidateIds, ingredientNameEn, category);

        if (rankedCandidateIds.isEmpty()) {
            return null;
        }

        double threshold = category != null ? ACCEPT_MATCH_THRESHOLD_WITH_CATEGORY : ACCEPT_MATCH_THRESHOLD;
        UUID bestIngredientId = rankedCandidateIds.entrySet().stream()
                .filter(entry -> entry.getValue() >= threshold)
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);

        if (bestIngredientId == null) {
            return null;
        }
        return ingredientRepository.findById(bestIngredientId).orElse(null);
    }

    private void collectProjectedMatches(Map<UUID, Double> rankedCandidateIds,
                                         String search,
                                         ProductCategory category) {
        String normalizedSearch = normalizeIngredientName(search);
        if (normalizedSearch == null) {
            return;
        }

        String categoryName = category != null ? category.name() : null;
        List<IngredientMatchProjection> matches = ingredientRepository.searchIngredientMatches(
                search,
                categoryName,
                SEARCH_MATCH_THRESHOLD
        );
        for (IngredientMatchProjection match : matches) {
            double score = calculateIngredientMatchScore(match, search, category);
            rankedCandidateIds.merge(match.getId(), score, Math::max);
        }
    }

    private double calculateIngredientMatchScore(IngredientMatchProjection match,
                                                 String search,
                                                 ProductCategory requestedCategory) {
        double score = match.getMatchScore() != null ? match.getMatchScore() : 0d;
        score = Math.max(score, lexicalMatchScore(search, match.getNameUk()));
        score = Math.max(score, lexicalMatchScore(search, match.getNameEn()));
        if (requestedCategory != null && requestedCategory.name().equalsIgnoreCase(match.getCategory())) {
            score = Math.min(1d, score + 0.05d);
        }
        return score;
    }

    private double lexicalMatchScore(String left, String right) {
        String normalizedLeft = normalizeIngredientName(left);
        String normalizedRight = normalizeIngredientName(right);
        if (normalizedLeft == null || normalizedRight == null) {
            return 0d;
        }
        if (normalizedLeft.equals(normalizedRight)) {
            return 1d;
        }

        Set<String> leftTokens = tokenizeIngredientName(normalizedLeft);
        Set<String> rightTokens = tokenizeIngredientName(normalizedRight);
        if (!leftTokens.isEmpty() && leftTokens.equals(rightTokens)) {
            return 0.92d;
        }
        if (normalizedLeft.contains(normalizedRight) || normalizedRight.contains(normalizedLeft)) {
            return 0.86d;
        }
        if (!leftTokens.isEmpty() && !rightTokens.isEmpty()) {
            Set<String> intersection = new LinkedHashSet<>(leftTokens);
            intersection.retainAll(rightTokens);
            double overlap = (double) intersection.size() / Math.max(leftTokens.size(), rightTokens.size());
            if (overlap >= 0.75d) {
                return 0.82d;
            }
            if (overlap >= 0.50d) {
                return 0.72d;
            }
        }
        return 0d;
    }

    private Set<String> tokenizeIngredientName(String normalizedName) {
        return Arrays.stream(normalizedName.split(" "))
                .map(this::trimToNull)
                .filter(token -> token != null && token.length() > 1)
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    private boolean isHardExcludedByName(String ingredientNameUk,
                                         String ingredientNameEn,
                                         GenerationContext context) {
        String normalizedUkrainianName = normalizeIngredientName(ingredientNameUk);
        String normalizedEnglishName = normalizeIngredientName(ingredientNameEn);
        return (normalizedUkrainianName != null && context.hardExcludedIngredientNames().contains(normalizedUkrainianName))
                || (normalizedEnglishName != null && context.hardExcludedIngredientNames().contains(normalizedEnglishName));
    }

    private void validatePersistableRecipe(Recipe recipe, Map<String, String> errors) {
        if (recipe.getName() == null) {
            errors.put("name", "Recipe name is required");
        }
        if (recipe.getMealType() == null) {
            errors.put("mealType", "Meal type is required");
        }
        if (recipe.getTotalTimeMinutes() == null || recipe.getTotalTimeMinutes() <= 0) {
            errors.put("totalTimeMinutes", "Total time must be greater than zero");
        }
        if (recipe.getDefaultServings() == null || recipe.getDefaultServings() <= 0) {
            errors.put("defaultServings", "Default servings must be greater than zero");
        }
        if (recipe.getComplexityRating() == null || recipe.getComplexityRating() <= 0) {
            errors.put("complexityRating", "Complexity rating must be greater than zero");
        }
        if (recipe.getActiveCookingTimeMinutes() != null && recipe.getActiveCookingTimeMinutes() <= 0) {
            errors.put("activeCookingTimeMinutes", "Active cooking time must be greater than zero");
        }
        if (recipe.getActiveCookingTimeMinutes() != null
                && recipe.getTotalTimeMinutes() != null
                && recipe.getActiveCookingTimeMinutes() > recipe.getTotalTimeMinutes()) {
            errors.put("activeCookingTimeMinutes", "Active cooking time cannot exceed total time");
        }
        if (recipe.getSteps() == null || recipe.getSteps().isEmpty()) {
            errors.put("steps", "At least one non-empty step is required");
        }
    }

    private Map<UUID, Ingredient> loadIngredients(Collection<UUID> ingredientIds) {
        if (ingredientIds == null || ingredientIds.isEmpty()) {
            return Map.of();
        }
        return ingredientRepository.findByIdIn(ingredientIds).stream()
                .collect(Collectors.toMap(Ingredient::getId, ingredient -> ingredient));
    }

    private String buildUserPrompt(GenerationContext context, Map<String, String> validationErrors) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("Generate one recipe draft.\n");
        prompt.append("Use the provided schema exactly.\n");
        prompt.append("Output format instructions:\n").append(DRAFT_OUTPUT_CONVERTER.getFormat()).append('\n');
        prompt.append("Language rules:\n");
        prompt.append("- All text fields must be in Ukrainian.\n");
        prompt.append("- name, description, steps, ingredientNameUk must be written in Ukrainian.\n");
        prompt.append("- ingredientNameEn may be null, but if present it must be concise.\n");
        prompt.append("JSON completeness rules:\n");
        prompt.append("- Return exactly one complete JSON object.\n");
        prompt.append("- Do not stop before the final closing brace.\n");
        prompt.append("- Do not add markdown, comments, explanations, or trailing text.\n");
        prompt.append("MealType values: ").append(enumValues(MealType.values())).append(".\n");
        prompt.append("MenuType values: ").append(enumValues(MenuType.values())).append(".\n");
        prompt.append("MeasurementUnit values: ").append(enumValues(MeasurementUnit.values())).append(".\n");
        prompt.append("ProductCategory values: ").append(enumValues(ProductCategory.values())).append(".\n");
        prompt.append("Recipe rules:\n");
        prompt.append("- mealType must be ").append(context.request().getMealType()).append(".\n");
        if (context.effectiveMenuType() != null) {
            prompt.append("- menuType must be ").append(context.effectiveMenuType()).append(".\n");
        }
        prompt.append("- defaultServings must be ").append(context.effectiveServings()).append(".\n");
        prompt.append("- complexityRating must be a positive integer.\n");

        prompt.append("Ingredient selection rules:\n");
        prompt.append("- Each ingredient must include ingredientNameUk, category, defaultUnit, quantity, unit, optional.\n");
        prompt.append("- You must include every preferred ingredient listed below.\n");
        prompt.append("- You may and should add complementary ingredients needed for a realistic recipe.\n");
        prompt.append("- Prefer exact Ukrainian ingredient names from the known dictionary list when suitable.\n");
        prompt.append("- Do not use ingredients from allergies or exclusions.\n");
        prompt.append("- Try to avoid disliked ingredients.\n");
        prompt.append("- Ingredient quantities must be greater than zero.\n");
        prompt.append("- Avoid duplicate ingredients.\n");
        prompt.append("- Prefer the most common everyday ingredients.\n");
        prompt.append("- Cooking oil: prefer 'олія соняшникова' or 'оливкова олія'.\n");
        prompt.append("- Eggs: if any egg is needed, prefer 'яйце куряче'. \n");
        prompt.append("- Any cooking oil MUST have category=SAUCES_AND_SPICES and defaultUnit/unit=MILLILITER.\n");
        prompt.append("- Ingredients: 6-10 items max.\n");

        prompt.append("- Steps must contain 5-7 short, practical cooking instructions..\n");
        prompt.append("- totalTimeMinutes must be present and greater than zero.\n");
        if (context.maxTotalTimeMinutes() != null) {
            prompt.append("- totalTimeMinutes must be <= ").append(context.maxTotalTimeMinutes()).append(".\n");
        }
        prompt.append("- activeCookingTimeMinutes must be null or <= totalTimeMinutes.\n");
        if (context.profileSimplicity() != null) {
            prompt.append("User profile:\n");
            prompt.append("- simplicity preference: ").append(context.profileSimplicity()).append(" (keep the recipe practical and aligned).\n");
            prompt.append("- family size: ").append(context.effectiveServings()).append(".\n");
        }

        if (context.request().getAdditionalNotes() != null && !context.request().getAdditionalNotes().isBlank()) {
            prompt.append("Additional notes: ").append(context.request().getAdditionalNotes().trim()).append(".\n");
        }

        appendIngredientsSection(prompt, "Preferred ingredients (must appear in the recipe)", context.preferredIngredients());
        appendIngredientsSection(prompt, "Known dictionary ingredients to reuse when relevant", context.suggestedIngredients());
        appendIngredientsSection(prompt, "Favorite ingredients", context.favoriteIngredients());
        appendIngredientsSection(prompt, "Disliked ingredients to avoid", context.dislikedIngredients());
        appendIngredientsSection(prompt, "Allergies (must never appear)", context.allergyIngredients());
        appendIngredientsSection(prompt, "Exclusions (must never appear)", context.exclusionIngredients());

        if (!validationErrors.isEmpty()) {
            prompt.append("Previous response validation errors:\n");
            validationErrors.forEach((field, message) ->
                    prompt.append("- ").append(field).append(": ").append(message).append('\n'));
            prompt.append("Correct every error and return only the corrected JSON.\n");
        }

        return prompt.toString();
    }

    private void appendIngredientsSection(StringBuilder prompt, String title, List<Ingredient> ingredients) {
        prompt.append(title).append(":\n");
        if (ingredients == null || ingredients.isEmpty()) {
            prompt.append("- none\n");
            return;
        }
        ingredients.forEach(ingredient -> prompt.append("- ")
                .append(ingredient.getNameUk())
                .append(" | category=")
                .append(ingredient.getCategory())
                .append(" | defaultUnit=")
                .append(ingredient.getDefaultUnit())
                .append('\n'));
    }

    private MenuType resolveMenuType(String rawMenuType, MenuType fallback, Map<String, String> errors) {
        String normalized = trimToNull(rawMenuType);
        if (normalized == null) {
            return fallback;
        }
        try {
            return MenuType.valueOf(normalized.toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException ex) {
            errors.put("menuType", "MenuType must be one of: " + enumValues(MenuType.values()));
            return fallback;
        }
    }

    private ProductCategory resolveProductCategory(String rawCategory) {
        String normalized = trimToNull(rawCategory);
        if (normalized == null) {
            return null;
        }
        try {
            return ProductCategory.valueOf(normalized.toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException ex) {
            return null;
        }
    }

    private ProductCategory defaultProductCategory(String rawCategory) {
        ProductCategory parsedCategory = resolveProductCategory(rawCategory);
        return parsedCategory != null ? parsedCategory : ProductCategory.OTHER;
    }

    private MeasurementUnit resolveMeasurementUnit(String rawUnit, MeasurementUnit fallbackUnit) {
        String normalized = trimToNull(rawUnit);
        if (normalized == null) {
            return fallbackUnit;
        }
        try {
            return MeasurementUnit.valueOf(normalized.toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException ex) {
            return fallbackUnit;
        }
    }

    private MeasurementUnit resolveDefaultUnitForNewIngredient(String rawDefaultUnit, String rawRecipeUnit) {
        MeasurementUnit parsedDefaultUnit = resolveMeasurementUnit(rawDefaultUnit, null);
        if (parsedDefaultUnit != null) {
            return parsedDefaultUnit;
        }
        MeasurementUnit parsedRecipeUnit = resolveMeasurementUnit(rawRecipeUnit, null);
        return parsedRecipeUnit != null ? parsedRecipeUnit : MeasurementUnit.PIECE;
    }

    private Integer resolveComplexity(Integer rawComplexity) {
        return rawComplexity != null && rawComplexity > 0 ? rawComplexity : 1;
    }

    private List<String> cleanSteps(List<String> steps) {
        if (steps == null) {
            return List.of();
        }
        return steps.stream()
                .map(this::trimToNull)
                .filter(Objects::nonNull)
                .toList();
    }

    private List<Ingredient> uniqueIngredients(List<Ingredient> ingredients) {
        if (ingredients == null || ingredients.isEmpty()) {
            return List.of();
        }
        LinkedHashMap<UUID, Ingredient> unique = new LinkedHashMap<>();
        ingredients.stream()
                .filter(Objects::nonNull)
                .forEach(ingredient -> unique.putIfAbsent(ingredient.getId(), ingredient));
        return new ArrayList<>(unique.values());
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private String normalizeIngredientName(String value) {
        String trimmed = trimToNull(value);
        if (trimmed == null) {
            return null;
        }
        String normalized = trimmed.toLowerCase(Locale.ROOT)
                .replace('’', '\'')
                .replace('`', '\'')
                .replaceAll("[^\\p{L}\\p{Nd}\\s]", " ")
                .replaceAll("\\s+", " ")
                .trim();
        return normalized.isEmpty() ? null : normalized;
    }

    private String enumValues(Enum<?>[] values) {
        return Arrays.stream(values)
                .map(Enum::name)
                .collect(Collectors.joining(", "));
    }

    private String coalesce(String primary, String secondary) {
        return primary != null ? primary : secondary;
    }

    private String extractResponseText(ChatResponse chatResponse) {
        if (chatResponse == null || chatResponse.getResult() == null || chatResponse.getResult().getOutput() == null) {
            return null;
        }
        return chatResponse.getResult().getOutput().getText();
    }

    private String extractFinishReason(ChatResponse chatResponse) {
        if (chatResponse == null || chatResponse.getResult() == null || chatResponse.getResult().getMetadata() == null) {
            return null;
        }
        return chatResponse.getResult().getMetadata().getFinishReason();
    }

    private String truncateForLog(String value) {
        if (value == null) {
            return null;
        }
        String normalized = value.replaceAll("\\s+", " ").trim();
        int maxLength = 1200;
        if (normalized.length() <= maxLength) {
            return normalized;
        }
        return normalized.substring(0, maxLength) + "...";
    }

    private void ensureAiEnabled() {
        if (!aiProperties.isEnabled()) {
            throw new AiFeatureDisabledException("AI recipe generation is disabled");
        }
    }

    private record GenerationContext(
            UUID userId,
            AiRecipeGenerateRequestDto request,
            MenuType effectiveMenuType,
            int effectiveServings,
            Integer maxTotalTimeMinutes,
            Integer profileSimplicity,
            List<Ingredient> preferredIngredients,
            List<Ingredient> suggestedIngredients,
            Set<UUID> preferredIngredientIds,
            List<Ingredient> favoriteIngredients,
            List<Ingredient> dislikedIngredients,
            List<Ingredient> allergyIngredients,
            List<Ingredient> exclusionIngredients,
            Set<UUID> hardExcludedIngredientIds,
            Set<String> hardExcludedIngredientNames
    ) {
    }

    private record ValidationResult(AiRecipeDraftDto draft, Map<String, String> validationErrors) {
        static ValidationResult valid(AiRecipeDraftDto draft) {
            return new ValidationResult(draft, Map.of());
        }

        static ValidationResult invalid(Map<String, String> validationErrors) {
            return new ValidationResult(null, validationErrors);
        }

        boolean isValid() {
            return draft != null && validationErrors.isEmpty();
        }
    }

    private record PersistableRecipe(Recipe recipe, List<RecipeIngredient> ingredients) {
    }
}
