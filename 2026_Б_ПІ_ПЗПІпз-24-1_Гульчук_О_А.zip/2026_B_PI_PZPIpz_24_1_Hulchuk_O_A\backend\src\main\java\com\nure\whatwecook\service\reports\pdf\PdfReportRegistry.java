package com.nure.whatwecook.service.reports.pdf;

import com.nure.whatwecook.service.helper.pdf.PdfDocument;
import org.springframework.stereotype.Service;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

@Service
public class PdfReportRegistry {

    private final Map<PdfReportType, PdfReportGenerator<?>> generators = new EnumMap<>(PdfReportType.class);

    public PdfReportRegistry(List<PdfReportGenerator<?>> gens) {
        for (var g : gens) {
            generators.put(g.type(), g);
        }
    }

    @SuppressWarnings("unchecked")
    public <RQ> PdfDocument generate(PdfReportType type, RQ request) {
        PdfReportGenerator<?> gen = generators.get(type);
        if (gen == null) {
            throw new IllegalArgumentException("No PDF generator registered for type: " + type);
        }
        if (!gen.requestType().isInstance(request)) {
            throw new IllegalArgumentException("Wrong request type for " + type +
                    ". Expected: " + gen.requestType().getSimpleName() +
                    ", got: " + (request == null ? "null" : request.getClass().getSimpleName()));
        }
        return ((PdfReportGenerator<RQ>) gen).generate(request);
    }
}
