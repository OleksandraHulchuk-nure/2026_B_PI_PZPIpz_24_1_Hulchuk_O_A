package com.nure.whatwecook.dto.ai;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class AiRecipeLlmDraftIngredientDto {

    private String ingredientNameUk;

    private String ingredientNameEn;

    private String category;

    private String defaultUnit;

    private BigDecimal quantity;

    private String unit;

    private Boolean optional;
}
