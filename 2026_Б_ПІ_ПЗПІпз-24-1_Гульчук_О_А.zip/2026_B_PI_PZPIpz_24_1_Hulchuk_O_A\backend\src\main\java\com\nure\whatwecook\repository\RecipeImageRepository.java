package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.recipe.RecipeImage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RecipeImageRepository extends JpaRepository<RecipeImage, UUID> {

    Optional<RecipeImage> findFirstByRecipeIdAndPrimaryIsTrue(UUID recipeId);

    List<RecipeImage> findByRecipeId(UUID recipeId);
}
