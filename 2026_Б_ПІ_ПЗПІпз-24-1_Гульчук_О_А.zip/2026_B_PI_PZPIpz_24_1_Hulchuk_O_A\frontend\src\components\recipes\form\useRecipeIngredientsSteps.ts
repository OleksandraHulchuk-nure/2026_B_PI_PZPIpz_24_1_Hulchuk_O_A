'use client';

import * as React from 'react';
import {createRowId, DEFAULT_STEPS, MAX_STEPS, MIN_STEPS} from '@/lib/recipes/formDefaults';
import {RecipeIngredientLine} from "@/components/recipes/types";


function emptyIngredient(): RecipeIngredientLine {
    return {
        id: createRowId(),
        ingredientId: null,
        ingredientName: '',
        quantity: '',
        unit: '',
        optional: false,
    };
}

function ensureMinSteps(steps: string[], minSteps = DEFAULT_STEPS): string[] {
    const trimmed = steps.map((s) => s ?? '');
    if (trimmed.length >= minSteps) return trimmed;
    return [...trimmed, ...Array.from({length: minSteps - trimmed.length}, () => '')];
}

export function useRecipeIngredientsSteps(opts?: {
    initialIngredients?: RecipeIngredientLine[];
    initialSteps?: string[];
    minSteps?: number;
}) {
    const minSteps = opts?.minSteps ?? MIN_STEPS;

    const [ingredients, setIngredients] = React.useState<RecipeIngredientLine[]>(
        opts?.initialIngredients?.length ? opts.initialIngredients : [emptyIngredient()],
    );

    const [steps, setSteps] = React.useState<string[]>(
        ensureMinSteps(opts?.initialSteps?.length ? opts.initialSteps : [], minSteps),
    );

    const addIngredient = React.useCallback(() => {
        setIngredients((prev) => [...prev, emptyIngredient()]);
    }, []);

    const removeIngredient = React.useCallback((id: string) => {
        setIngredients((prev) => (prev.length <= 1 ? prev : prev.filter((x) => x.id !== id)));
    }, []);

    const updateIngredient = React.useCallback((id: string, patch: Partial<RecipeIngredientLine>) => {
        setIngredients((prev) => prev.map((x) => (x.id === id ? {...x, ...patch} : x)));
    }, []);

    const addStep = React.useCallback(() => {
        setSteps((prev) => (prev.length >= MAX_STEPS ? prev : [...prev, '']));
    }, []);

    const updateStep = React.useCallback((index: number, value: string) => {
        setSteps((prev) => prev.map((s, i) => (i === index ? value : s)));
    }, []);

    const clearOrRemoveStep = React.useCallback(
        (index: number) => {
            setSteps((prev) => {
                if (prev.length > minSteps) {
                    return prev.filter((_, i) => i !== index);
                }
                return prev.map((s, i) => (i === index ? '' : s));
            });
        },
        [minSteps],
    );

    const reset = React.useCallback(
        (next: { ingredients?: RecipeIngredientLine[]; steps?: string[] }) => {
            setIngredients(next.ingredients?.length ? next.ingredients : [emptyIngredient()]);
            setSteps(ensureMinSteps(next.steps?.length ? next.steps : [], minSteps));
        },
        [minSteps],
    );

    return {
        ingredients,
        steps,
        addIngredient,
        removeIngredient,
        updateIngredient,
        addStep,
        updateStep,
        clearOrRemoveStep,
        reset,
        setIngredients,
        setSteps,
        minSteps,
    };
}
