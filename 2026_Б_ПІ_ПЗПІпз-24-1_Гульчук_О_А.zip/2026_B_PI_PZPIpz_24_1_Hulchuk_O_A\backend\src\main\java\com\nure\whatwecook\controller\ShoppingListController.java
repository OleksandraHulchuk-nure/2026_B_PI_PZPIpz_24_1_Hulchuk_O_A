package com.nure.whatwecook.controller;


import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.domain.entity.shopping.ShoppingList;
import com.nure.whatwecook.dto.shopping.*;
import com.nure.whatwecook.mapper.ShoppingListMapper;
import com.nure.whatwecook.service.ShoppingListService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Tag(name = "Shopping lists", description = "Generate and manage shopping lists")
@RestController
@RequestMapping("/api/shopping-lists")
@RequiredArgsConstructor
public class ShoppingListController {

    private final CurrentUserProvider currentUserProvider;
    private final ShoppingListService shoppingListService;
    private final ShoppingListMapper shoppingListMapper;

    @Operation(summary = "Generate shopping list from weekly menu")
    @PostMapping("/from-weekly-menu")
    public ResponseEntity<ShoppingListResponseDto> generateFromWeeklyMenu(
            @RequestBody ShoppingListFromWeeklyMenuRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        ShoppingList list = shoppingListService.generateFromWeeklyMenu(userId, requestDto.getWeeklyMenuId());
        return ResponseEntity.ok(shoppingListMapper.toDto(list));
    }

    @Operation(summary = "Get shopping list by id")
    @GetMapping("/{id}")
    public ResponseEntity<ShoppingListResponseDto> getShoppingList(
            @PathVariable("id") UUID id
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        ShoppingList list = shoppingListService.getShoppingList(userId, id);
        return ResponseEntity.ok(shoppingListMapper.toDto(list));
    }

    @Operation(summary = "Get shopping list by weekly menu start date")
    @GetMapping("/by-start-date")
    public ResponseEntity<ShoppingListResponseDto> getShoppingListByStartDate(
            @RequestParam("startDate")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        ShoppingList list = shoppingListService.getShoppingListByStartDate(userId, startDate);
        return ResponseEntity.ok(shoppingListMapper.toDto(list));
    }

    @Operation(summary = "Update 'haveQuantity' for shopping list items")
    @PutMapping("/{id}/items")
    public ResponseEntity<ShoppingListResponseDto> updateHaveQuantities(
            @PathVariable("id") UUID id,
            @RequestBody ShoppingListItemsUpdateRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();

        Map<UUID, BigDecimal> haveById = new HashMap<>();
        if (requestDto.getItems() != null) {
            for (ShoppingItemUpdateDto itemDto : requestDto.getItems()) {
                haveById.put(itemDto.getItemId(), itemDto.getHaveQuantity());
            }
        }

        ShoppingList updated = shoppingListService.updateItemsHaveQuantity(userId, id, haveById);
        return ResponseEntity.ok(shoppingListMapper.toDto(updated));
    }

    @Operation(summary = "Update 'haveQuantity' for specific shopping list item")
    @PutMapping("/{id}/items/{itemId}")
    public ResponseEntity<ShoppingListResponseDto> updateHaveQuantity(
            @PathVariable("id") UUID id,
            @PathVariable("itemId") UUID itemId,
            @RequestBody ShoppingItemHaveQuantityUpdateRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        ShoppingList updated = shoppingListService.updateItemHaveQuantity(
                userId,
                id,
                itemId,
                requestDto.getHaveQuantity()
        );
        return ResponseEntity.ok(shoppingListMapper.toDto(updated));
    }

    @Operation(summary = "Delete shopping list item")
    @DeleteMapping("/{id}/items/{itemId}")
    public ResponseEntity<ShoppingListResponseDto> deleteItem(
            @PathVariable("id") UUID id,
            @PathVariable("itemId") UUID itemId
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        ShoppingList updated = shoppingListService.deleteItem(userId, id, itemId);
        return ResponseEntity.ok(shoppingListMapper.toDto(updated));
    }

    @Operation(summary = "Export shopping list as text")
    @GetMapping(value = "/{id}/export", produces = "text/plain")
    public ResponseEntity<String> exportShoppingList(@PathVariable("id") UUID id) {
        UUID userId = currentUserProvider.getCurrentUserId();
        String content = shoppingListService.exportShoppingList(userId, id);
        return ResponseEntity.ok(content);
    }
}
