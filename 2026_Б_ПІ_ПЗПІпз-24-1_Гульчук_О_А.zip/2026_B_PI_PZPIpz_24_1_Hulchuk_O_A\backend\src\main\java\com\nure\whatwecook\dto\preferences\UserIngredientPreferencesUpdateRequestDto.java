package com.nure.whatwecook.dto.preferences;

import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
public class UserIngredientPreferencesUpdateRequestDto {

    private List<UUID> favoriteIngredientIds;
    private List<UUID> dislikedIngredientIds;
    private List<UUID> allergyIngredientIds;
    private List<UUID> exclusionIngredientIds;
}
