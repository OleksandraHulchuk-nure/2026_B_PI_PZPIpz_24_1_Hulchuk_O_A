package com.nure.whatwecook.dto.stats;

import java.math.BigDecimal;
import java.time.LocalDate;

public record StatPeriodAiMetricsDto(
        LocalDate from,
        LocalDate to,
        AiPeriodStatsDto ai
) {
    public record AiPeriodStatsDto(
            Integer allMeals,
            Integer aiMeals,
            BigDecimal aiSharePct, // 0..1, nullable

            Integer verifiedCnt,
            Integer rejectedCnt,
            BigDecimal successPct, // verified / (verified+rejected), nullable

            Integer ratedCnt,
            BigDecimal ratedPct,   // rated / aiMeals, nullable
            BigDecimal avgTaste    // nullable
    ) {}
}
