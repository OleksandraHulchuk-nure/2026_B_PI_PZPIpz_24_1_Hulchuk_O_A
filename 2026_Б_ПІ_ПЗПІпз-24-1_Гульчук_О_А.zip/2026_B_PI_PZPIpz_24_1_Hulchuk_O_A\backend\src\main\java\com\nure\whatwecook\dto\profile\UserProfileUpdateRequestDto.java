package com.nure.whatwecook.dto.profile;

import com.nure.whatwecook.domain.enums.MenuType;
import lombok.Data;

@Data
public class UserProfileUpdateRequestDto {

    private String name;
    private Integer familySize;
    private Integer simplicity;
    private MenuType menuType;
    private Integer existingRecipeRatio;
}
