import type { MealType, MenuType, RecipeSourceType, RecipeStatus } from '@/lib/api/recipeApi';
import {
    MEAL_TYPE_LABELS,
    MENU_TYPE_LABELS,
    RECIPE_SOURCE_LABELS,
    RECIPE_STATUS_LABELS,
} from '@/lib/constants/enums';

export function formatRecipeStatus(status: RecipeStatus) {
    return RECIPE_STATUS_LABELS[status];
}

export function formatRecipeSource(source: RecipeSourceType) {
    return RECIPE_SOURCE_LABELS[source];
}

export function formatMenuType(menuType?: MenuType) {
    if (!menuType) return '—';
    return MENU_TYPE_LABELS[menuType];
}

export function formatMealType(mealType?: MealType) {
    if (!mealType) return '—';
    return MEAL_TYPE_LABELS[mealType];
}

export function formatMinutes(value?: number) {
    if (value === undefined || value === null) return '—';
    return `${value} хв`;
}

export function formatMinutesTableview(value?: number) {
    if (value === undefined || value === null) return '—';
    return value;
}
