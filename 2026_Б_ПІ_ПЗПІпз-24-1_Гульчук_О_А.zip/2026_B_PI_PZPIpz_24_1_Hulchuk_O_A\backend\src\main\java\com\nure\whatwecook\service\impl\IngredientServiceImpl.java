package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.entity.menu.MenuDay;
import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.enums.ProductCategory;
import com.nure.whatwecook.dto.ingredient.AggregatedIngredientDto;
import com.nure.whatwecook.mapper.AggregatedIngredientMapper;
import com.nure.whatwecook.repository.IngredientRepository;
import com.nure.whatwecook.repository.MenuDayRepository;
import com.nure.whatwecook.service.IngredientService;
import com.nure.whatwecook.service.aggregation.AggregatedIngredient;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class IngredientServiceImpl implements IngredientService {

    private static final double SEARCH_MATCH_THRESHOLD = 0.35d;

    private final IngredientRepository ingredientRepository;
    private final MenuDayRepository menuDayRepository;
    private final AggregatedIngredientMapper aggregatedIngredientMapper;

    @Override
    public List<Ingredient> searchIngredients(String search, ProductCategory category) {
        boolean hasSearch = search != null && !search.isBlank();

        if (category != null && !hasSearch) {
            return ingredientRepository.findByCategory(category);
        }
        if (!hasSearch) {
            return ingredientRepository.findAll();
        }

        LinkedHashMap<UUID, Ingredient> result = new LinkedHashMap<>();
        if (category != null) {
            ingredientRepository.findByCategoryAndNameUkContainingIgnoreCase(category, search)
                    .forEach(ingredient -> result.putIfAbsent(ingredient.getId(), ingredient));
        }
        else {
            ingredientRepository.findByNameUkContainingIgnoreCase(search)
                    .forEach(ingredient -> result.putIfAbsent(ingredient.getId(), ingredient));
        }

        List<UUID> fuzzyMatchIds = ingredientRepository.searchIngredientMatches(
                        search.trim(),
                        category != null ? category.name() : null,
                        SEARCH_MATCH_THRESHOLD
                )
                .stream()
                .map(match -> match.getId())
                .filter(Objects::nonNull)
                .distinct()
                .toList();

        if (!fuzzyMatchIds.isEmpty()) {
            Map<UUID, Ingredient> fuzzyMatchesById = ingredientRepository.findByIdIn(fuzzyMatchIds).stream()
                    .collect(LinkedHashMap::new, (map, ingredient) -> map.put(ingredient.getId(), ingredient), Map::putAll);
            fuzzyMatchIds.forEach(id -> {
                Ingredient ingredient = fuzzyMatchesById.get(id);
                if (ingredient != null) {
                    result.putIfAbsent(id, ingredient);
                }
            });
        }

        return new ArrayList<>(result.values());
    }

    @Override
    public Ingredient getIngredientById(UUID id) {
        return ingredientRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Ingredient not found"));
    }

    @Override
    public List<AggregatedIngredientDto> getAggregatedIngredientsByDate(UUID userId, LocalDate date) {
        MenuDay menuDay = menuDayRepository.findByWeeklyMenuUserIdAndDate(userId, date)
                .orElseThrow(() -> new EntityNotFoundException(
                        "Menu day not found for user " + userId + " and date " + date
                ));

        Map<Ingredient, AggregatedIngredient> aggregated = new LinkedHashMap<>();

        menuDay.getMeals().forEach(meal -> {
            Recipe recipe = meal.getRecipe();
            if (recipe == null || recipe.getIngredients() == null) {
                return;
            }

            recipe.getIngredients().forEach(ri -> {
                Ingredient ingredient = ri.getIngredient();
                if (ingredient == null) {
                    return;
                }

                AggregatedIngredient aq = aggregated.computeIfAbsent(
                        ingredient,
                        ing -> new AggregatedIngredient(ing, ri.getUnit())
                );

                aq.addQuantity(ri.getQuantity());
            });
        });

        return aggregatedIngredientMapper.toDtoList(aggregated.values());
    }
}
