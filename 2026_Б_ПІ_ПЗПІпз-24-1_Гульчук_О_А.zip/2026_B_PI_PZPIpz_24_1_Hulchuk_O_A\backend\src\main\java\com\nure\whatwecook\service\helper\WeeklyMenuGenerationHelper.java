package com.nure.whatwecook.service.helper;

import com.nure.whatwecook.domain.entity.profile.User;
import com.nure.whatwecook.domain.entity.profile.UserIngredientPreference;
import com.nure.whatwecook.domain.entity.profile.UserMealPreference;
import com.nure.whatwecook.domain.entity.profile.UserProfile;
import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.entity.recipe.RecipeIngredient;
import com.nure.whatwecook.domain.enums.*;
import com.nure.whatwecook.repository.RecipeRepository;
import com.nure.whatwecook.repository.UserIngredientPreferenceRepository;
import com.nure.whatwecook.repository.UserMealPreferenceRepository;
import com.nure.whatwecook.repository.WeeklyMenuRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class WeeklyMenuGenerationHelper {

    private static final int COOLDOWN_WEEKS = 4;
    private static final int TOP_K = 5;
    private static final double RELAX_TIME_PCT = 0.15;

    private final RecipeRepository recipeRepository;
    private final UserMealPreferenceRepository userMealPreferenceRepository;
    private final UserIngredientPreferenceRepository userIngredientPreferenceRepository;
    private final WeeklyMenuRepository weeklyMenuRepository;

    public List<Recipe> selectRecipesForMealType(User user,
                                                 MealType mealType,
                                                 LocalDate weekStart,
                                                 int generationVersion,
                                                 Set<UUID> avoidRecipeIds,
                                                 int requiredCount) {

        if (requiredCount <= 0) return List.of();

        UUID userId = user.getId();
        UserProfile profile = user.getProfile();

        Map<MealType, Integer> maxCookingTimeByMealType = loadMaxCookingTimeByMealType(userId);
        IngredientPrefs ingredientPrefs = loadIngredientPrefs(userId);

        Set<UUID> recentRecipeIds = loadRecentRecipeIds(userId, weekStart, COOLDOWN_WEEKS);

        long seed = Objects.hash(userId, weekStart.toEpochDay(), mealType.name(), generationVersion);
        SplittableRandom rnd = new SplittableRandom(seed);

        List<Recipe> all = fetchRecipesForGeneration(userId, mealType);

        all.sort(Comparator.comparing(Recipe::getId));

        // HARD RULES:
        List<Recipe> hard = all.stream()
                .filter(r -> r.getStatus() != RecipeStatus.REJECTED)
                .filter(r -> isRecipeAllowedByHardExclusions(r, ingredientPrefs.excludedIngredientIds))
                .toList();

        if (hard.isEmpty()) return List.of();

        Integer maxTime = maxCookingTimeByMealType.get(mealType);
        int relaxedMaxTime = relaxMaxTime(maxTime);

        List<Recipe> stage1 = hard.stream()
                .filter(r -> matchesSimplicity(profile, r))
                .filter(r -> matchesCookingTime(maxTime, r))
                .filter(r -> matchesMenuType(profile.getMenuType(), safeMenuType(r)))
                .filter(r -> !recentRecipeIds.contains(r.getId()))
                .filter(r -> !avoidRecipeIds.contains(r.getId()))
                .toList();

        List<Recipe> stage2 = hard.stream()
                .filter(r -> matchesSimplicity(profile, r))
                .filter(r -> matchesCookingTime(maxTime, r))
                .filter(r -> matchesMenuType(profile.getMenuType(), safeMenuType(r)))
                .filter(r -> !avoidRecipeIds.contains(r.getId()))
                .toList();

        List<Recipe> stage3 = hard.stream()
                .filter(r -> matchesSimplicity(profile, r))
                .filter(r -> matchesCookingTime(relaxedMaxTime, r))
                .filter(r -> !recentRecipeIds.contains(r.getId()))
                .filter(r -> !avoidRecipeIds.contains(r.getId()))
                .toList();

        List<Recipe> stage4 = hard.stream()
                .filter(r -> matchesSimplicity(profile, r))
                .filter(r -> matchesCookingTime(relaxedMaxTime, r))
                .filter(r -> !avoidRecipeIds.contains(r.getId()))
                .toList();

        List<Recipe> stage5 = hard.stream()
                .filter(r -> !recentRecipeIds.contains(r.getId()))
                .filter(r -> !avoidRecipeIds.contains(r.getId()))
                .toList();

        List<Recipe> stage6 = hard;

        List<Recipe> result = new ArrayList<>();
        Set<UUID> usedThisMealType = new HashSet<>();

        pickFromStage(result, usedThisMealType, stage1, requiredCount, rnd.split(), profile, ingredientPrefs, maxTime, recentRecipeIds, avoidRecipeIds, 1);
        pickFromStage(result, usedThisMealType, stage2, requiredCount, rnd.split(), profile, ingredientPrefs, maxTime, recentRecipeIds, avoidRecipeIds, 2);

        if (result.size() < requiredCount) {
            pickFromStage(result, usedThisMealType, stage3, requiredCount, rnd.split(), profile, ingredientPrefs, relaxedMaxTime, recentRecipeIds, avoidRecipeIds, 3);
            pickFromStage(result, usedThisMealType, stage4, requiredCount, rnd.split(), profile, ingredientPrefs, relaxedMaxTime, recentRecipeIds, avoidRecipeIds, 4);
        }
        if (result.size() < requiredCount) {
            pickFromStage(result, usedThisMealType, stage5, requiredCount, rnd.split(), profile, ingredientPrefs, maxTime, recentRecipeIds, avoidRecipeIds, 5);
        }
        if (result.size() < requiredCount) {
            pickFromStage(result, usedThisMealType, stage6, requiredCount, rnd.split(), profile, ingredientPrefs, maxTime, recentRecipeIds, avoidRecipeIds, 6);
        }

        if (result.size() < requiredCount && !hard.isEmpty()) {
            int i = 0;
            while (result.size() < requiredCount) {
                result.add(hard.get(i % hard.size()));
                i++;
            }
        }

        return result;
    }

    private void pickFromStage(List<Recipe> result,
                               Set<UUID> used,
                               List<Recipe> stage,
                               int requiredCount,
                               SplittableRandom rnd,
                               UserProfile profile,
                               IngredientPrefs prefs,
                               Integer maxTime,
                               Set<UUID> recent,
                               Set<UUID> avoid,
                               int stageIndex) {

        if (result.size() >= requiredCount || stage.isEmpty()) return;

        List<Scored> scored = stage.stream()
                .filter(r -> !used.contains(r.getId()))
                .map(r -> new Scored(r, score(r, rnd.split(), profile, prefs, maxTime, recent, avoid, stageIndex)))
                .sorted(Comparator.<Scored>comparingDouble(s -> s.score).reversed()
                        .thenComparing(s -> s.recipe.getId()))
                .collect(Collectors.toCollection(ArrayList::new));

        while (result.size() < requiredCount && !scored.isEmpty()) {
            int k = Math.min(TOP_K, scored.size());
            int pickIdx = rnd.nextInt(k);
            Scored picked = scored.remove(pickIdx);
            result.add(picked.recipe);
            used.add(picked.recipe.getId());
        }
    }

    private double score(Recipe r,
                         SplittableRandom rnd,
                         UserProfile profile,
                         IngredientPrefs prefs,
                         Integer maxTime,
                         Set<UUID> recent,
                         Set<UUID> avoid,
                         int stageIndex) {

        double s = 0.0;

        s += (r.getTasteRating() != null ? r.getTasteRating() : 3.0);
        if (r.getStatus() == RecipeStatus.VERIFIED) s += 1.0;

        MenuType userType = profile.getMenuType();
        MenuType recipeType = safeMenuType(r);
        if (recipeType == userType) s += 0.6;
        if (recipeType == MenuType.BALANCED) s += 0.2;

        s += Math.max(0, profile.getSimplicity() - safeInt(r.getComplexityRating(), 1)) * 0.10;

        if (maxTime != null && maxTime < Integer.MAX_VALUE) {
            int diff = maxTime - safeInt(r.getTotalTimeMinutes(), maxTime);
            if (diff >= 0) {
                s += Math.min(0.4, (diff / (double) maxTime) * 0.4);
            } else {
                s -= Math.min(1.2, (Math.abs(diff) / (double) maxTime) * 1.2);
            }
        }

        IngredientHits hits = ingredientHits(r, prefs.favoriteIngredientIds, prefs.dislikedIngredientIds);
        s += Math.min(1.0, hits.favoriteHits * 0.20);
        s -= Math.min(1.2, hits.dislikedHits * 0.30);

        if ((stageIndex == 2 || stageIndex == 4 || stageIndex == 6) && recent.contains(r.getId())) {
            s -= 2.5;
        }
        if (stageIndex >= 3 && avoid.contains(r.getId())) {
            s -= 5.0;
        }

        s += rnd.nextDouble(0.0, 0.6);

        return s;
    }

    private boolean isRecipeAllowedByHardExclusions(Recipe recipe, Set<UUID> excludedIngredientIds) {
        List<RecipeIngredient> ingredients = recipe.getIngredients();
        if (ingredients == null || ingredients.isEmpty()) return true;

        for (RecipeIngredient ri : ingredients) {
            if (ri.getIngredient() != null && excludedIngredientIds.contains(ri.getIngredient().getId())) {
                return false;
            }
        }
        return true;
    }

    private IngredientHits ingredientHits(Recipe recipe, Set<UUID> favorite, Set<UUID> disliked) {
        int fav = 0, dis = 0;
        if (recipe.getIngredients() == null) return new IngredientHits(0, 0);

        for (RecipeIngredient ri : recipe.getIngredients()) {
            if (ri.getIngredient() == null) continue;
            UUID ingId = ri.getIngredient().getId();
            if (favorite.contains(ingId)) fav++;
            if (disliked.contains(ingId)) dis++;
        }
        return new IngredientHits(fav, dis);
    }

    private Map<MealType, Integer> loadMaxCookingTimeByMealType(UUID userId) {
        List<UserMealPreference> preferences = userMealPreferenceRepository.findByUserId(userId);
        Map<MealType, Integer> result = new EnumMap<>(MealType.class);
        for (UserMealPreference preference : preferences) {
            if (preference.getMealType() != null) {
                result.put(preference.getMealType(), preference.getMaxCookingTimeMinutes());
            }
        }
        return result;
    }

    private IngredientPrefs loadIngredientPrefs(UUID userId) {
        Set<UUID> excluded = new HashSet<>();
        excluded.addAll(userIngredientPreferenceRepository.findByUserIdAndPreferenceType(userId, IngredientPreferenceType.ALLERGY)
                .stream().map(p -> p.getIngredient().getId()).collect(Collectors.toSet()));
        excluded.addAll(userIngredientPreferenceRepository.findByUserIdAndPreferenceType(userId, IngredientPreferenceType.EXCLUSION)
                .stream().map(p -> p.getIngredient().getId()).collect(Collectors.toSet()));

        Set<UUID> favorite = userIngredientPreferenceRepository.findByUserIdAndPreferenceType(userId, IngredientPreferenceType.FAVORITE)
                .stream().map(p -> p.getIngredient().getId()).collect(Collectors.toSet());

        Set<UUID> disliked = userIngredientPreferenceRepository.findByUserIdAndPreferenceType(userId, IngredientPreferenceType.DISLIKED)
                .stream().map(p -> p.getIngredient().getId()).collect(Collectors.toSet());

        return new IngredientPrefs(excluded, favorite, disliked);
    }

    private Set<UUID> loadRecentRecipeIds(UUID userId, LocalDate weekStart, int cooldownWeeks) {
        LocalDate from = weekStart.minusWeeks(cooldownWeeks);
        LocalDate to = weekStart;
        return new HashSet<>(weeklyMenuRepository.findUsedRecipeIds(userId, from, to, MenuStatus.APPROVED));
    }

    private boolean matchesSimplicity(UserProfile profile, Recipe recipe) {
        return safeInt(recipe.getComplexityRating(), 1) <= safeInt(profile.getSimplicity(), 3);
    }

    private boolean matchesCookingTime(Integer maxCookingTime, Recipe recipe) {
        if (maxCookingTime == null) return true;
        return safeInt(recipe.getTotalTimeMinutes(), Integer.MAX_VALUE) <= maxCookingTime;
    }

    private int relaxMaxTime(Integer maxTime) {
        if (maxTime == null) return Integer.MAX_VALUE;
        return (int) Math.ceil(maxTime * (1.0 + RELAX_TIME_PCT));
    }

    private MenuType safeMenuType(Recipe r) {
        return (r.getMenuType() != null) ? r.getMenuType() : MenuType.BALANCED;
    }

    private int safeInt(Integer v, int def) {
        return v != null ? v : def;
    }

    /**
     * Меню-тип: BALANCED дозволяє все.
     * Інші типи — сумісність з BALANCED як “нейтральним”.
     */
    private boolean matchesMenuType(MenuType userType, MenuType recipeType) {
        if (userType == null || userType == MenuType.BALANCED) return true;

        return switch (userType) {
            case VEGETARIAN -> recipeType == MenuType.VEGETARIAN
                    || recipeType == MenuType.MORE_VEGGIES
                    || recipeType == MenuType.BALANCED;
            case MORE_MEAT -> recipeType == MenuType.MORE_MEAT
                    || recipeType == MenuType.BALANCED;
            case MORE_FISH -> recipeType == MenuType.MORE_FISH
                    || recipeType == MenuType.BALANCED;
            case MORE_VEGGIES -> recipeType == MenuType.MORE_VEGGIES
                    || recipeType == MenuType.VEGETARIAN
                    || recipeType == MenuType.BALANCED;
            default -> true;
        };
    }

    private List<Recipe> fetchRecipesForGeneration(UUID userId, MealType mealType) {
        return new ArrayList<>(recipeRepository.findByUserAndFilters(
                userId,
                null,
                null,
                null,
                mealType,
                null,
                Pageable.unpaged()
        ).getContent());
    }

    private record Scored(Recipe recipe, double score) {}
    private record IngredientHits(int favoriteHits, int dislikedHits) {}
    private record IngredientPrefs(Set<UUID> excludedIngredientIds,
                                   Set<UUID> favoriteIngredientIds,
                                   Set<UUID> dislikedIngredientIds) {}
}
