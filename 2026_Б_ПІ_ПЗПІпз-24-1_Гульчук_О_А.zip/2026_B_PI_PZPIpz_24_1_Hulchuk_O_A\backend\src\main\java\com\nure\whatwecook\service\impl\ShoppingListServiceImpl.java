package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.entity.menu.WeeklyMenu;
import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.entity.shopping.ShoppingItem;
import com.nure.whatwecook.domain.entity.shopping.ShoppingList;
import com.nure.whatwecook.repository.ShoppingItemRepository;
import com.nure.whatwecook.repository.ShoppingListRepository;
import com.nure.whatwecook.repository.WeeklyMenuRepository;
import com.nure.whatwecook.service.ShoppingListService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.math.BigDecimal;
import java.util.Comparator;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ShoppingListServiceImpl implements ShoppingListService {

    private final WeeklyMenuRepository weeklyMenuRepository;
    private final ShoppingListRepository shoppingListRepository;
    private final ShoppingItemRepository shoppingItemRepository;

    @Override
    @Transactional
    public ShoppingList generateFromWeeklyMenu(UUID userId, UUID weeklyMenuId) {
        WeeklyMenu weeklyMenu = weeklyMenuRepository.findById(weeklyMenuId)
                .orElseThrow(() -> new EntityNotFoundException("Weekly menu not found"));

        if (!weeklyMenu.getUser().getId().equals(userId)) {
            throw new EntityNotFoundException("Weekly menu not found");
        }

        ShoppingList existing = shoppingListRepository.findByWeeklyMenuId(weeklyMenuId)
                .orElse(null);

        if (existing != null) {
            existing.getItems().size();
            return existing;
        }

        ShoppingList shoppingList = new ShoppingList();
        shoppingList.setWeeklyMenu(weeklyMenu);

        shoppingList.setItems(new ArrayList<>());
        Map<Ingredient, AggregatedQuantity> aggregated = new LinkedHashMap<>();

        weeklyMenu.getDays().forEach(day ->
                day.getMeals().forEach(meal -> {
                    Recipe recipe = meal.getRecipe();
                    if (recipe == null || recipe.getIngredients() == null) {
                        return;
                    }
                    recipe.getIngredients().forEach(ri -> {
                        Ingredient ingredient = ri.getIngredient();
                        if (ingredient == null) {
                            return;
                        }

                        AggregatedQuantity aq = aggregated.computeIfAbsent(
                                ingredient,
                                ing -> new AggregatedQuantity(ing, ri.getUnit(), BigDecimal.ZERO)
                        );

                        aq.quantity = aq.quantity.add(ri.getQuantity());
                    });
                })
        );

        for (AggregatedQuantity aq : aggregated.values()) {
            ShoppingItem item = new ShoppingItem();
            item.setShoppingList(shoppingList);
            item.setIngredient(aq.ingredient);
            item.setQuantityUnit(aq.unit);
            item.setNeededQuantity(aq.quantity);
            item.setHaveQuantity(BigDecimal.ZERO);

            shoppingList.getItems().add(item);
        }

        return shoppingListRepository.save(shoppingList);
    }

    @Override
    public ShoppingList getShoppingList(UUID userId, UUID shoppingListId) {
        ShoppingList list = shoppingListRepository.findById(shoppingListId)
                .orElseThrow(() -> new EntityNotFoundException("Shopping list not found"));
        return list;
    }

    @Override
    public ShoppingList getShoppingListByStartDate(UUID userId, LocalDate startDate) {
        WeeklyMenu weeklyMenu = weeklyMenuRepository.findByUserIdAndStartDate(userId, startDate)
                .orElseThrow(() -> new EntityNotFoundException(
                        "Weekly menu not found for user " + userId + " and startDate " + startDate
                ));

        return shoppingListRepository.findByWeeklyMenuId(weeklyMenu.getId())
                .orElseThrow(() -> new EntityNotFoundException(
                        "Shopping list not found for weekly menu " + weeklyMenu.getId()
                ));
    }

    @Override
    @Transactional
    public ShoppingList updateItemsHaveQuantity(UUID userId,
                                                UUID shoppingListId,
                                                Map<UUID, BigDecimal> haveQuantitiesByItemId) {
        ShoppingList list = getShoppingList(userId, shoppingListId);

        list.getItems().forEach(item -> {
            BigDecimal newVal = haveQuantitiesByItemId.get(item.getId());
            if (newVal != null) {
                item.setHaveQuantity(newVal);
            }
        });

        return shoppingListRepository.save(list);
    }

    @Override
    @Transactional
    public ShoppingList updateItemHaveQuantity(UUID userId,
                                               UUID shoppingListId,
                                               UUID shoppingItemId,
                                               BigDecimal haveQuantity) {
        ShoppingList list = getShoppingList(userId, shoppingListId);

        ShoppingItem item = list.getItems().stream()
                .filter(i -> i.getId().equals(shoppingItemId))
                .findFirst()
                .orElseThrow(() -> new EntityNotFoundException("Shopping item not found"));

        item.setHaveQuantity(haveQuantity != null ? haveQuantity : BigDecimal.ZERO);

        return shoppingListRepository.save(list);
    }

    @Override
    @Transactional
    public ShoppingList deleteItem(UUID userId, UUID shoppingListId, UUID shoppingItemId) {
        ShoppingList list = getShoppingList(userId, shoppingListId);

        boolean removed = list.getItems().removeIf(item -> item.getId().equals(shoppingItemId));
        if (!removed) {
            throw new EntityNotFoundException("Shopping item not found");
        }

        shoppingItemRepository.deleteById(shoppingItemId);

        return shoppingListRepository.save(list);
    }

    @Override
    public String exportShoppingList(UUID userId, UUID shoppingListId) {
        ShoppingList list = getShoppingList(userId, shoppingListId);

        StringBuilder builder = new StringBuilder();
        builder.append("Shopping list for week starting ")
                .append(list.getWeeklyMenu() != null ? list.getWeeklyMenu().getStartDate() : "N/A")
                .append('\n');

        list.getItems().stream()
                .sorted(Comparator.comparing(item -> item.getIngredient().getNameUk(), String.CASE_INSENSITIVE_ORDER))
                .forEach(item -> builder.append("- ")
                        .append(item.getIngredient().getNameUk())
                        .append(" (needed: ")
                        .append(item.getNeededQuantity())
                        .append(" ")
                        .append(item.getQuantityUnit())
                        .append(", have: ")
                        .append(item.getHaveQuantity())
                        .append(", to buy: ")
                        .append(item.getNeededQuantity().subtract(item.getHaveQuantity()).max(BigDecimal.ZERO))
                        .append(")\n"));

        return builder.toString();
    }

    private static class AggregatedQuantity {
        private final Ingredient ingredient;
        private final com.nure.whatwecook.domain.enums.MeasurementUnit unit;
        private BigDecimal quantity;

        private AggregatedQuantity(Ingredient ingredient,
                                   com.nure.whatwecook.domain.enums.MeasurementUnit unit,
                                   BigDecimal quantity) {
            this.ingredient = ingredient;
            this.unit = unit;
            this.quantity = quantity;
        }
    }
}
