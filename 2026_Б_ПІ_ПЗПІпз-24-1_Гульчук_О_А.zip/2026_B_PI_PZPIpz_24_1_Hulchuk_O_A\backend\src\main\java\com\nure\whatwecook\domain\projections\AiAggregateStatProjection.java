package com.nure.whatwecook.domain.projections;

import java.math.BigDecimal;

public interface AiAggregateStatProjection {
    Integer getAiMeals();

    Integer getAllMeals();

    Integer getVerifiedCnt();

    Integer getRejectedCnt();

    Integer getRatedCnt();

    BigDecimal getAvgTaste(); // nullable
}
