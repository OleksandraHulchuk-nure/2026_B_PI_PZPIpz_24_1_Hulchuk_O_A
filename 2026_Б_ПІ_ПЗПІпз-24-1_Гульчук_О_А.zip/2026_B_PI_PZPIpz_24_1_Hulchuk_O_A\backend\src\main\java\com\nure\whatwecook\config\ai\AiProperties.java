package com.nure.whatwecook.config.ai;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Getter
@Setter
@ConfigurationProperties(prefix = "whatwecook.ai")
public class AiProperties {

    private boolean enabled = true;

    private AiProvider provider = AiProvider.OPENAI;

    private String model = "gpt-4o-mini";

    private Double temperature = 0.4d;

    private Integer maxTokens = 1200;
}
