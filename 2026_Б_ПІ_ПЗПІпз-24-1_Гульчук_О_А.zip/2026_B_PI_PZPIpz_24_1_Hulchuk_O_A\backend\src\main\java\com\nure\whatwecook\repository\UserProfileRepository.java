package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.profile.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface UserProfileRepository extends JpaRepository<UserProfile, UUID> {

}
