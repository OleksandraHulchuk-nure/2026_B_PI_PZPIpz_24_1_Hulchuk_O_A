package com.nure.whatwecook.mapper;

import com.nure.whatwecook.domain.entity.menu.MenuDay;
import com.nure.whatwecook.domain.entity.menu.MenuMeal;
import com.nure.whatwecook.domain.entity.menu.WeeklyMenu;
import com.nure.whatwecook.dto.menu.MenuDayPlanDto;
import com.nure.whatwecook.dto.menu.MenuMealPlanDto;
import com.nure.whatwecook.dto.menu.WeeklyMenuResponseDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(
        componentModel = "spring",
        uses = {RecipeMapper.class},
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface WeeklyMenuMapper {

    @Mapping(target = "days", source = "days")
    WeeklyMenuResponseDto toDto(WeeklyMenu entity);

    List<WeeklyMenuResponseDto> toDtoList(List<WeeklyMenu> entities);

    @Mapping(target = "meals", source = "meals")
    MenuDayPlanDto toDayDto(MenuDay day);

    List<MenuDayPlanDto> toDayDtos(List<MenuDay> days);

    @Mapping(target = "recipeId", source = "recipe.id")
    @Mapping(target = "recipe", source = "recipe")
    MenuMealPlanDto toMealDto(MenuMeal meal);

    List<MenuMealPlanDto> toMealDtos(List<MenuMeal> meals);
}
