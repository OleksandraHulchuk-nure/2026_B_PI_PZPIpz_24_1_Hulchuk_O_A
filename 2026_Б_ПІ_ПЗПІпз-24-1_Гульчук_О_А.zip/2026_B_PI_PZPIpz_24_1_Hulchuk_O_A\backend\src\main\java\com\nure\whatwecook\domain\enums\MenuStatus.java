package com.nure.whatwecook.domain.enums;

import lombok.Getter;

@Getter
public enum MenuStatus {

    DRAFT("Чернетка"),
    APPROVED("Підтверджено");

    private final String ukrainianName;

    MenuStatus(String ukrainianName) {
        this.ukrainianName = ukrainianName;
    }

}
