'use client';

import React from 'react';
import { MaterialIcon } from '@/components/ui/materialIcon';
import type { DecimalLike, StatPeriodMenuMetricsDto } from '@/lib/api/statsApi';

function dec(v: DecimalLike): number | undefined {
    if (typeof v === 'number' && Number.isFinite(v)) return v;
    if (v && typeof v === 'object' && Number.isFinite(v.parsedValue)) {
        return v.parsedValue;
    }
    return undefined;
}

function pctSmart(v: DecimalLike): string {
    const n0 = dec(v);
    if (typeof n0 !== 'number' || !Number.isFinite(n0)) return '—';

    const p = n0 <= 1.000001 ? n0 * 100 : n0;
    return `${Math.round(p)}%`;
}

function numSmart(v: DecimalLike, digits = 1): string {
    const n = dec(v);
    if (typeof n !== 'number' || !Number.isFinite(n)) return '—';
    return n.toFixed(digits);
}

function formatMinutesDhm(v: DecimalLike): string {
    const mins0 = dec(v);
    if (typeof mins0 !== 'number' || !Number.isFinite(mins0)) return '—';

    const m = Math.round(mins0);

    const days = Math.floor(m / 1440);
    const hours = Math.floor((m % 1440) / 60);
    const minutes = m % 60;

    if (days > 0) {
        if (hours > 0) return `${days} д ${hours} год`;
        return `${days} д`;
    }

    if (m < 60) return `${m} хв`;
    if (minutes === 0) return `${hours} год`;
    return `${hours} год ${minutes} хв`;
}

function GroupLine(props: { icon: string; label: string; value: string; tooltip: string }) {
    return (
        <div className="flex items-center justify-between gap-3 py-1">
            <div className="flex items-center gap-2 min-w-0">
                <MaterialIcon name={props.icon} className="text-[18px] shrink-0 text-text-muted" />
                <div className="text-xs text-text-muted truncate">{props.label}</div>
                <MaterialIcon name="info" className="text-[16px] shrink-0 text-text-muted" title={props.tooltip} />
            </div>

            <div className="text-base font-bold whitespace-nowrap leading-none">{props.value}</div>
        </div>
    );
}

function KpiGroupCard(props: { title: string; lines: Array<React.ComponentProps<typeof GroupLine>> }) {
    return (
        <div className="h-full rounded-xl border border-border bg-surface px-3 py-2 flex flex-col">
            <div className="text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted leading-snug">
                {props.title}
            </div>

            <div className="mt-2 pt-2 border-t border-border flex flex-col gap-1">
                {props.lines.map((l, idx) => (
                    <GroupLine key={idx} {...l} />
                ))}
            </div>
        </div>
    );
}

export function StatsKpiGrid(props: { data?: StatPeriodMenuMetricsDto }) {
    const d = props.data;

    return (
        <div className="grid grid-cols-1 items-stretch gap-2 md:grid-cols-2 xl:grid-cols-3">
            <KpiGroupCard
                title="Меню"
                lines={[
                    {
                        icon: 'local_fire_department',
                        label: 'Меню поспіль',
                        value: typeof d?.streakWeeksMax === 'number' ? `${d.streakWeeksMax} тиж.` : '—',
                        tooltip: 'Максимальна серія тижнів із затвердженим меню в межах періоду.',
                    },
                    {
                        icon: 'task_alt',
                        label: 'Швидкість затвердження',
                        value: formatMinutesDhm(d?.approvalSpeedMinutesAvg),
                        tooltip: 'Середній час від створення чернетки до затвердження меню.',
                    },
                ]}
            />

            <KpiGroupCard
                title="Якість готування"
                lines={[
                    {
                        icon: 'schedule',
                        label: 'Час готування / день',
                        value: formatMinutesDhm(d?.avgCookingTimePerDayMinutes),
                        tooltip: 'Середній час готування на день за період.',
                    },
                    {
                        icon: 'signal_cellular_alt',
                        label: 'Складність',
                        value: numSmart(d?.avgComplexity, 1),
                        tooltip: 'Середня оцінка складності рецептів за період.',
                    },
                ]}
            />

            <KpiGroupCard
                title="Дотримання лімітів"
                lines={[
                    {
                        icon: 'verified',
                        label: 'В межах часу',
                        value: pctSmart(d?.timeAdherence?.pct),
                        tooltip: 'Частка страв, що вписались у обмеження часу приготування.',
                    },
                    {
                        icon: 'verified',
                        label: 'В межах складності',
                        value: pctSmart(d?.complexityAdherence?.pct),
                        tooltip: 'Частка страв, що вписались у обмеження складності.',
                    },
                ]}
            />
        </div>
    );
}
