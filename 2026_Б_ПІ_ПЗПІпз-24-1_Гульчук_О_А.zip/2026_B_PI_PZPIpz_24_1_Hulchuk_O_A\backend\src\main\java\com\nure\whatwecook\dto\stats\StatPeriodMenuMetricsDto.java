package com.nure.whatwecook.dto.stats;

import java.math.BigDecimal;
import java.time.LocalDate;

public record StatPeriodMenuMetricsDto(
        LocalDate from,
        LocalDate to,

        Integer streakWeeksMax,

        BigDecimal avgCookingTimePerDayMinutes,

        RatioDto timeAdherence,
        BigDecimal avgComplexity,
        RatioDto complexityAdherence,

        BigDecimal approvalSpeedMinutesAvg
) {
    public record RatioDto(
            Integer constraintsCnt,
            Integer withinCnt,
            BigDecimal pct // 0..1, nullable
    ) {}
}
