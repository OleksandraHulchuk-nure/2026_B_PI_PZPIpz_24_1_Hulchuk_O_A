'use client';

import {useState, type FormEvent} from 'react';
import Link from 'next/link';
import {useRouter} from 'next/navigation';

import {loginUser} from '@/lib/api/authApi';
import {saveAuthToken} from '@/lib/auth/tokenStorage';
import {Card} from '@/components/ui/card';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Alert} from "@/components/ui/alert";

export default function LoginPage() {
    const router = useRouter();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        setError(null);

        if (!email || !email.includes('@')) {
            setError('Будь ласка, введіть коректний email.');
            return;
        }

        if (!password) {
            setError('Будь ласка, введіть пароль.');
            return;
        }

        setIsSubmitting(true);

        try {
            const auth = await loginUser({email, password});
            saveAuthToken(auth);

            router.push('/');
        } catch (err) {
            const message =
                err instanceof Error
                    ? err.message
                    : 'Не вдалося увійти. Перевірте email та пароль і спробуйте ще раз.';
            setError(message);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <Card className="w-full max-w-md">
            <h1 className="mb-1 text-2xl font-bold">Вхід</h1>
            <p className="mb-6 text-sm text-text-muted">
                Увійдіть у свій акаунт WhatWeCook, щоб продовжити планування меню.
            </p>

            <form className="space-y-4" onSubmit={handleSubmit} noValidate>
                <div>
                    <label
                        htmlFor="email"
                        className="mb-1 block text-xs font-semibold uppercase tracking-[0.08em] text-text-muted"
                    >
                        Email
                    </label>
                    <Input
                        id="email"
                        type="email"
                        autoComplete="email"
                        placeholder="family@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </div>

                <div>
                    <label
                        htmlFor="password"
                        className="mb-1 block text-xs font-semibold uppercase tracking-[0.08em] text-text-muted"
                    >
                        Пароль
                    </label>
                    <Input
                        id="password"
                        type="password"
                        autoComplete="current-password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </div>

                {error && (
                    <Alert variant="error">
                        {error}
                    </Alert>
                )}

                <Button
                    type="submit"
                    className="w-full justify-center"
                    disabled={isSubmitting}
                >
                    {isSubmitting ? 'Вхід...' : 'Увійти'}
                </Button>
            </form>

            <p className="mt-4 text-center text-sm text-text-muted">
                Ще не маєте акаунта?{' '}
                <Link
                    href="/register"
                    className="font-medium text-primary hover:underline"
                >
                    Зареєструватися
                </Link>
            </p>
        </Card>
    );
}
