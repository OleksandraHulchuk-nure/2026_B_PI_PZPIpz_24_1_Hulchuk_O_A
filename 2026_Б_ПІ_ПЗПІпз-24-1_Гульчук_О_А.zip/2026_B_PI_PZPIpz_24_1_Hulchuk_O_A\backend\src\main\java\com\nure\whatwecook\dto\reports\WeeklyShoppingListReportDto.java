package com.nure.whatwecook.dto.reports;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public record WeeklyShoppingListReportDto(
        UUID shoppingListId,
        LocalDate weekStartDate,
        List<CategoryBlock> categories
) {
    public record CategoryBlock(
            String category,
            long itemsCnt,
            long toBuyItemsCnt,
            BigDecimal fullyCoveredSharePct,
            List<ItemLine> items
    ) {}

    public record ItemLine(
            String productName,
            BigDecimal needed,
            BigDecimal have,
            BigDecimal toBuy,
            String unit,
            boolean fullyCovered
    ) {}
}
