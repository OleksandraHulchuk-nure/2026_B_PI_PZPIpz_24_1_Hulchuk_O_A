package com.nure.whatwecook.dto.menu;

import lombok.Data;

import java.util.UUID;

@Data
public class MenuMealReplacementRequestDto {

    private UUID recipeId;
}
