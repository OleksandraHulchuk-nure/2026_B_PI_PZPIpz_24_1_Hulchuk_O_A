'use client';

import {useEffect, useMemo, useState} from 'react';

import {Alert} from '@/components/ui/alert';
import {Badge} from '@/components/ui/badge';
import {Button} from '@/components/ui/button';
import {Card} from '@/components/ui/card';
import {PaginationControls} from '@/components/ui/PaginationControls';

import type {SlotRef} from '@/components/weekly-menu/WeeklyMenuGrid';

import {useDebouncedValue} from '@/lib/hooks/useDebouncedValue';
import * as recipeApi from '@/lib/api/recipeApi';

import {RecipeFilters} from '@/components/recipes/RecipeFilters';
import type {RecipeFiltersValue} from '@/components/recipes/types';

import {
    MEAL_TYPE_LABELS,
    RECIPE_SOURCE_LABELS,
    RECIPE_STATUS_LABELS,
    recipeSourceBadgeVariant,
    recipeStatusBadgeVariant,
} from '@/lib/constants/enums';

interface ReplaceRecipeDialogProps {
    open: boolean;
    slot: SlotRef | null;
    weeklyMenuId: string | null;

    onClose: () => void;
    onPickRecipe: (recipeId: string) => void | Promise<void>;
    onAiGenerated: () => void | Promise<void>;
}

const PAGE_SIZE = 3;

export default function ReplaceRecipeDialog({
                                                open,
                                                slot,
                                                weeklyMenuId: _weeklyMenuId,
                                                onClose,
                                                onPickRecipe,
                                                onAiGenerated: _onAiGenerated,
                                            }: ReplaceRecipeDialogProps) {
    void _weeklyMenuId;
    void _onAiGenerated;

    const slotMealType = slot?.mealType ?? null;

    const [filtersUi, setFiltersUi] = useState<RecipeFiltersValue>({
        status: '',
        sourceType: '',
        mealType: '',
        maxTime: '',
        search: '',
    });

    const debouncedSearch = useDebouncedValue(filtersUi.search.trim(), 250);

    const [items, setItems] = useState<recipeApi.RecipeListItem[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string>('');

    const [page, setPage] = useState(0);
    const [hasNext, setHasNext] = useState(false);
    const [totalCount, setTotalCount] = useState(0);

    const title = useMemo(() => {
        if (!slot) return 'Заміна рецепта';
        return `Заміна: ${MEAL_TYPE_LABELS[slot.mealType]} (${slot.date})`;
    }, [slot]);

    useEffect(() => {
        if (!open) return;

        setFiltersUi((prev) => ({
            ...prev,
            mealType: prev.mealType ? prev.mealType : (slotMealType ?? ''),
        }));
    }, [open, slotMealType]);

    useEffect(() => {
        if (!open) return;
        setPage(0);
    }, [open, debouncedSearch, filtersUi.status, filtersUi.sourceType, filtersUi.maxTime, filtersUi.mealType]);

    function resetFilters() {
        setFiltersUi({status: '', sourceType: '', mealType: '', maxTime: '', search: ''});
        setPage(0);
    }

    useEffect(() => {
        if (!open) return;

        let cancelled = false;

        const load = async () => {
            setLoading(true);
            setError('');

            try {
                const data = await recipeApi.getRecipes({
                    mealType: filtersUi.mealType || undefined,
                    search: debouncedSearch || undefined,
                    status: filtersUi.status || undefined,
                    sourceType: filtersUi.sourceType || undefined,
                    maxTime: typeof filtersUi.maxTime === 'number' ? filtersUi.maxTime : undefined,
                    page,
                    size: PAGE_SIZE,
                    sort: {field: 'CREATED_AT', direction: 'DESC'},
                });

                const filtered = data.items.filter((r) => r.status !== 'REJECTED');
                if (cancelled) return;

                setItems(filtered);
                setHasNext(data.hasNext);
                setTotalCount(data.totalCount);
            } catch (e) {
                if (!cancelled) setError(e instanceof Error ? e.message : 'Не вдалося завантажити рецепти.');
            } finally {
                if (!cancelled) setLoading(false);
            }
        };

        void load();

        return () => {
            cancelled = true;
        };
    }, [open, debouncedSearch, filtersUi.status, filtersUi.sourceType, filtersUi.maxTime, filtersUi.mealType, page]);

    useEffect(() => {
        if (open) return;
        setFiltersUi({status: '', sourceType: '', mealType: '', maxTime: '', search: ''});
        setItems([]);
        setError('');
        setLoading(false);
        setPage(0);
        setHasNext(false);
        setTotalCount(0);
    }, [open]);

    const totalPages = totalCount ? Math.max(1, Math.ceil(totalCount / PAGE_SIZE)) : 1;

    if (!open) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/30 p-3 md:items-center">
            <Card className="w-full max-w-3xl overflow-hidden rounded-2xl border border-border bg-surface">
                <div className="flex items-center justify-between border-b border-border px-4 py-3">
                    <div className="flex flex-col gap-1">
                        <div className="text-sm font-semibold text-text-primary">{title}</div>
                        {slotMealType ? (
                            <div className="text-xs text-text-muted">
                                Порада: для цього слоту зазвичай підходить{' '}
                                <span className="font-semibold">{MEAL_TYPE_LABELS[slotMealType]}</span>, але можна
                                обрати будь-який.
                            </div>
                        ) : null}
                    </div>

                    <Button variant="icon" size="icon" onClick={onClose} aria-label="Закрити">
                        ×
                    </Button>
                </div>

                <div className="flex flex-col gap-4 p-4">
                    <RecipeFilters value={filtersUi} onReset={resetFilters} onChange={setFiltersUi}/>

                    {error && (
                        <Alert variant="error" title="Помилка">
                            {error}
                        </Alert>
                    )}

                    {loading ? (
                        <div
                            className="rounded-xl border border-border bg-background px-4 py-6 text-center text-sm text-text-muted">
                            Завантажуємо рецепти…
                        </div>
                    ) : items.length === 0 ? (
                        <div
                            className="rounded-xl border border-border bg-background px-4 py-6 text-center text-sm text-text-muted">
                            Нічого не знайдено. Спробуйте змінити фільтри або пошук.
                        </div>
                    ) : (
                        <>
                            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-text-muted">
                                <div>
                                    Сторінка <span className="font-semibold text-text-primary">{page + 1}</span> з{' '}
                                    <span className="font-semibold text-text-primary">{totalPages}</span> • Всього:{' '}
                                    <span className="font-semibold text-text-primary">{totalCount}</span>
                                </div>
                            </div>

                            <div className="grid max-h-[48vh] gap-3 overflow-y-auto pr-1">
                                {items.map((r) => (
                                    <div key={r.id}
                                         className="flex flex-col gap-2 rounded-2xl border border-border bg-surface p-4">
                                        <div className="flex flex-wrap items-start justify-between gap-3">
                                            <div className="min-w-0">
                                                <div
                                                    className="truncate text-sm font-semibold text-text-primary">{r.name}</div>

                                                <div className="mt-1 flex flex-wrap items-center gap-2">
                                                    {r.status ? (
                                                        <Badge variant={recipeStatusBadgeVariant(r.status)}>
                                                            {RECIPE_STATUS_LABELS[r.status] ?? r.status}
                                                        </Badge>
                                                    ) : null}
                                                    {r.sourceType ? (
                                                        <Badge variant={recipeSourceBadgeVariant(r.sourceType)}>
                                                            {RECIPE_SOURCE_LABELS[r.sourceType] ?? r.sourceType}
                                                        </Badge>
                                                    ) : null}
                                                </div>
                                            </div>

                                            <Button variant="secondary" onClick={() => void onPickRecipe(r.id)}
                                                    title="Поставити цей рецепт у слот">
                                                Використати
                                            </Button>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <PaginationControls
                                page={page}
                                totalPages={totalPages}
                                hasNext={hasNext}
                                disabled={loading}
                                onPageChange={setPage}
                            />
                        </>
                    )}
                </div>
            </Card>
        </div>
    );
}
