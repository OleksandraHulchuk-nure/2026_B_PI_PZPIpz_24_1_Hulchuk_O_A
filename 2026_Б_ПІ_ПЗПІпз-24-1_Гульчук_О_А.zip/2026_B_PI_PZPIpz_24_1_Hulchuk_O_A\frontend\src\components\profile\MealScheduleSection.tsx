'use client';

import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
    type DayOfWeek,
} from '@/lib/api/profileApi';
import {Alert} from "@/components/ui/alert";
import {MEAL_TYPE_LABELS, MEAL_TYPES} from '@/lib/constants/enums';
import { useMealSchedule } from './hooks/useMealSchedule';
import type { CellKey, MealScheduleSectionProps } from './profile.types';

const DAYS: DayOfWeek[] = [
    'MONDAY',
    'TUESDAY',
    'WEDNESDAY',
    'THURSDAY',
    'FRIDAY',
    'SATURDAY',
    'SUNDAY',
];

const DAY_LABELS: Record<DayOfWeek, string> = {
    MONDAY: 'Пн',
    TUESDAY: 'Вт',
    WEDNESDAY: 'Ср',
    THURSDAY: 'Чт',
    FRIDAY: 'Пт',
    SATURDAY: 'Сб',
    SUNDAY: 'Нд',
};

export function MealScheduleSection({ familySize }: MealScheduleSectionProps) {
    const {
        cells,
        loading,
        saving,
        error,
        success,
        handleChange,
        handleSave,
    } = useMealSchedule({
        days: DAYS,
        mealTypes: MEAL_TYPES,
    });

    return (
        <section className="space-y-4">
            <div>
                <h2 className="section-title">Розклад прийомів їжі</h2>
                <p className="section-subtitle">
                    Для кожного дня тижня можна задати окрему кількість
                    порцій. Порожнє поле означає, що використовується розмір сім&apos;ї
                    {familySize ? ` (${familySize})` : ''}.
                </p>
            </div>

            {loading && <p>Завантаження розкладу...</p>}

            {error && !loading && (
                <Alert variant="error">
                    {error}
                </Alert>
            )}

            {!loading && (
                <Card className="overflow-x-auto">
                    <table className="w-full border-collapse text-sm">
                        <thead>
                        <tr className="border-b border-border bg-background">
                            <th className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-[0.08em] text-text-muted">
                                День
                            </th>
                            {MEAL_TYPES.map((mealType) => (
                                <th
                                    key={mealType}
                                    className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-[0.08em] text-text-muted"
                                >
                                    {MEAL_TYPE_LABELS[mealType]}
                                </th>
                            ))}
                        </tr>
                        </thead>
                        <tbody>
                        {DAYS.map((day) => (
                            <tr
                                key={day}
                                className="border-b border-border/60 hover:bg-primary-soft/40"
                            >
                                <td className="px-3 py-2 text-xs font-semibold text-text-primary">
                                    {DAY_LABELS[day]}
                                </td>
                                {MEAL_TYPES.map((mealType) => {
                                    const key: CellKey = `${day}-${mealType}`;
                                    const value = cells[key] ?? '';

                                    return (
                                        <td key={mealType} className="px-3 py-2">
                                            <Input
                                                type="number"
                                                min={0}
                                                inputMode="numeric"
                                                className="w-20"
                                                placeholder={
                                                    familySize != null ? String(familySize) : ''
                                                }
                                                value={value}
                                                onChange={(e) =>
                                                    handleChange(day, mealType, e.target.value)
                                                }
                                            />
                                        </td>
                                    );
                                })}
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </Card>
            )}

            <div className="flex justify-end">
                <Button variant="secondary" onClick={handleSave} disabled={saving}>
                    {saving ? 'Збереження...' : 'Зберегти розклад'}
                </Button>
            </div>

            {success && (
                <Alert variant="success">
                    {success}
                </Alert>
            )}
        </section>
    );
}
