package com.nure.whatwecook.controller;

import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.domain.entity.profile.UserMealPreference;
import com.nure.whatwecook.dto.preferences.MealTimePreferenceDto;
import com.nure.whatwecook.mapper.UserMealPreferenceMapper;
import com.nure.whatwecook.service.UserMealPreferenceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@Tag(name = "Meal Time Preferences", description = "Max cooking time per meal type")
@RestController
@RequestMapping("/api/preferences/meal-times")
@RequiredArgsConstructor
public class UserMealPreferenceController {

    private final UserMealPreferenceService userMealPreferenceService;
    private final UserMealPreferenceMapper userMealPreferenceMapper;
    private final CurrentUserProvider currentUserProvider;

    @Operation(summary = "Get meal time preferences")
    @GetMapping
    public ResponseEntity<List<MealTimePreferenceDto>> getMealTimePreferences() {
        UUID currentUserId = currentUserProvider.getCurrentUserId();
        List<UserMealPreference> prefs = userMealPreferenceService.getUserMealPreferences(currentUserId);
        return ResponseEntity.ok(userMealPreferenceMapper.toDtoList(prefs));
    }

    @Operation(summary = "Replace meal time preferences")
    @PutMapping
    public ResponseEntity<List<MealTimePreferenceDto>> updateMealTimePreferences(
            @RequestBody List<MealTimePreferenceDto> requestDtos) {

        UUID currentUserId = currentUserProvider.getCurrentUserId();
        List<UserMealPreference> entities = userMealPreferenceMapper.toEntityList(requestDtos);
        List<UserMealPreference> saved =
                userMealPreferenceService.replaceUserMealPreferences(currentUserId, entities);

        return ResponseEntity.ok(userMealPreferenceMapper.toDtoList(saved));
    }
}
