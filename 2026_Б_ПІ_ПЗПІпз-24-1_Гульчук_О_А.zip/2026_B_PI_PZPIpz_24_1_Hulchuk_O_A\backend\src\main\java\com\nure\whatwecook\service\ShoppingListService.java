package com.nure.whatwecook.service;

import com.nure.whatwecook.domain.entity.shopping.ShoppingList;

import java.time.LocalDate;
import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;

public interface ShoppingListService {

    ShoppingList generateFromWeeklyMenu(UUID userId, UUID weeklyMenuId);

    ShoppingList getShoppingList(UUID userId, UUID shoppingListId);

    ShoppingList getShoppingListByStartDate(UUID userId, LocalDate startDate);

    ShoppingList updateItemsHaveQuantity(UUID userId,
                                         UUID shoppingListId,
                                         Map<UUID, BigDecimal> haveQuantitiesByItemId);

    ShoppingList updateItemHaveQuantity(UUID userId,
                                        UUID shoppingListId,
                                        UUID shoppingItemId,
                                        BigDecimal haveQuantity);

    ShoppingList deleteItem(UUID userId, UUID shoppingListId, UUID shoppingItemId);

    String exportShoppingList(UUID userId, UUID shoppingListId);
}
