package com.nure.whatwecook.domain.enums;

import lombok.Getter;

@Getter
public enum ProductCategory {

    VEGETABLES("Овочі"),
    FRUITS("Фрукти"),
    MEAT("М'ясо"),
    DAIRY("Молочні продукти"),
    GRAINS("Крупи та злаки"),
    FISH_AND_SEAFOOD("Риба та морепродукти"),
    EGGS("Яйця"),
    BAKERY("Випічка та хліб"),
    SWEETS_AND_SNACKS("Солодощі та снеки"),
    BEVERAGES("Напої"),
    CANNED_AND_JARRED("Консерви"),
    FROZEN("Заморожені продукти"),
    SAUCES_AND_SPICES("Соуси та спеції"),
    NUTS_AND_SEEDS("Горіхи та насіння"),
    OTHER("Інше");

    private final String ukrainianName;

    ProductCategory(String ukrainianName) {
        this.ukrainianName = ukrainianName;
    }

}
