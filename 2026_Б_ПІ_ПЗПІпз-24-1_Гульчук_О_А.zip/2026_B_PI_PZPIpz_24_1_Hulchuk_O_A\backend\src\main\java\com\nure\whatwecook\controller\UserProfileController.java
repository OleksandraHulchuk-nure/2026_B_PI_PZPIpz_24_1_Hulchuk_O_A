package com.nure.whatwecook.controller;

import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.domain.entity.profile.UserProfile;
import com.nure.whatwecook.dto.profile.UserProfileResponseDto;
import com.nure.whatwecook.dto.profile.UserProfileUpdateRequestDto;
import com.nure.whatwecook.mapper.UserProfileMapper;
import com.nure.whatwecook.service.UserProfileService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@Tag(name = "User Profile", description = "Operations about user profile")
@RestController
@RequestMapping("/api/profile")
@RequiredArgsConstructor
public class UserProfileController {

    private final UserProfileService userProfileService;
    private final UserProfileMapper userProfileMapper;
    private final CurrentUserProvider currentUserProvider;

    @Operation(
            summary = "Get current user profile",
            description = "Returns profile information for the currently authenticated user"
    )
    @GetMapping
    public ResponseEntity<UserProfileResponseDto> getProfile() {
        UUID currentUserId = currentUserProvider.getCurrentUserId();
        UserProfile profile = userProfileService.getCurrentUserProfile(currentUserId);
        return ResponseEntity.ok(userProfileMapper.toDto(profile));
    }

    @Operation(
            summary = "Update current user profile",
            description = "Creates or updates profile for the currently authenticated user"
    )
    @PutMapping
    public ResponseEntity<UserProfileResponseDto> updateProfile(
            @RequestBody UserProfileUpdateRequestDto requestDto) {

        UUID currentUserId = currentUserProvider.getCurrentUserId();

        UserProfile profileData = userProfileMapper.toEntity(requestDto);
        UserProfile saved = userProfileService.upsertUserProfile(currentUserId, profileData);

        return ResponseEntity.ok(userProfileMapper.toDto(saved));
    }
}
