package com.nure.whatwecook.domain.entity.menu;

import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.enums.MealType;
import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Table(
        name = "menu_meal",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_menu_meal_day_meal_type",
                        columnNames = {"menu_day_id", "meal_type"}
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MenuMeal {

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "menu_day_id", nullable = false)
    private MenuDay menuDay;

    @Enumerated(EnumType.STRING)
    @Column(name = "meal_type", nullable = false, length = 50)
    private MealType mealType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recipe_id")
    private Recipe recipe;

    @PrePersist
    public void prePersist() {
        if (id == null) {
            id = UUID.randomUUID();
        }
    }
}
