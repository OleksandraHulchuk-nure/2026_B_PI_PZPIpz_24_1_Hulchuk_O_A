'use client';

import Link from 'next/link';
import * as React from 'react';
import {useRouter} from 'next/navigation';

import {PageSection} from '@/components/page-section';
import {Alert} from '@/components/ui/alert';
import {Badge} from '@/components/ui/badge';
import {Button} from '@/components/ui/button';
import {Card} from '@/components/ui/card';
import {Input} from '@/components/ui/input';
import {Select} from '@/components/ui/select';
import {Textarea} from '@/components/ui/textarea';

import {RecipeIngredientsStepsCard} from '@/components/recipes/form/RecipeIngredientsStepsCard';
import {useRecipeIngredientsSteps} from '@/components/recipes/form/useRecipeIngredientsSteps';
import type {RecipeIngredientLine} from '@/components/recipes/types';
import {ImageUploadIcon} from '@/components/ui/icons';
import StarRating from '@/components/ui/star-rating';

import {ApiError} from '@/lib/api/apiClient';
import {getIngredientById} from '@/lib/api/ingredientApi';
import {
    createManualRecipe,
    getRecipe,
    getRecipeImageBlob,
    MEAL_TYPE_OPTIONS,
    type MealType,
    type MeasurementUnit,
    MENU_TYPE_OPTIONS,
    type MenuType,
    type RecipeCreateRequestDto,
    type RecipeDetailsDto,
    type RecipeSourceType,
    updateRecipe,
    uploadRecipeImage,
} from '@/lib/api/recipeApi';
import {recipeSourceBadgeVariant} from '@/lib/constants/enums';
import {formatRecipeSource} from '@/lib/formatters/recipeFormatters';
import {createRowId, DEFAULT_STEPS} from '@/lib/recipes/formDefaults';
import {normalizeSteps} from '@/lib/recipes/format';

type EditorMode = 'create' | 'edit';

function toAlertMessage(error: unknown) {
    if (error instanceof ApiError) {
        return {message: error.message, status: error.status};
    }

    return {message: 'Сталася помилка. Спробуйте ще раз.'};
}

function toIngredientLines(recipe: RecipeDetailsDto, ingredientNames: Record<string, string>): RecipeIngredientLine[] {
    if (!(recipe.ingredients ?? []).length) {
        return [
            {
                id: createRowId(),
                ingredientId: null,
                ingredientName: '',
                quantity: '',
                unit: '',
                optional: false,
            },
        ];
    }

    return (recipe.ingredients ?? []).map((ingredient) => ({
        id: createRowId(),
        ingredientId: ingredient.ingredientId,
        ingredientName: ingredientNames[ingredient.ingredientId] ?? ingredient.ingredientId.slice(0, 8),
        quantity: String(ingredient.quantity ?? ''),
        unit: (ingredient.unit as MeasurementUnit) ?? '',
        optional: Boolean(ingredient.optional),
    }));
}

export function RecipeEditorPageClient({
    mode,
    recipeId,
}: {
    mode: EditorMode;
    recipeId?: string;
}) {
    const router = useRouter();
    const isEditMode = mode === 'edit';
    const formId = isEditMode ? 'edit-recipe-form' : 'new-recipe-form';
    const cancelHref = isEditMode && recipeId ? `/recipes/${recipeId}` : '/recipes';

    const {
        ingredients,
        steps,
        addIngredient,
        removeIngredient,
        updateIngredient,
        addStep,
        updateStep,
        clearOrRemoveStep,
        reset,
    } = useRecipeIngredientsSteps({minSteps: DEFAULT_STEPS});

    const [loading, setLoading] = React.useState(isEditMode);
    const [saving, setSaving] = React.useState(false);
    const [formError, setFormError] = React.useState<string | null>(null);
    const [error, setError] = React.useState<{message: string; status?: number} | null>(null);
    const [notice, setNotice] = React.useState<string | null>(null);
    const [successId, setSuccessId] = React.useState<string | null>(null);
    const [successMessage, setSuccessMessage] = React.useState<string | null>(null);

    const [sourceType, setSourceType] = React.useState<RecipeSourceType>('MANUAL');
    const [imageUrl, setImageUrl] = React.useState<string | null>(null);
    const [pendingImageFile, setPendingImageFile] = React.useState<File | null>(null);

    const [name, setName] = React.useState('');
    const [menuType, setMenuType] = React.useState<MenuType>('BALANCED');
    const [mealType, setMealType] = React.useState<MealType | ''>('');
    const [complexityRating, setComplexityRating] = React.useState(3);
    const [activeTime, setActiveTime] = React.useState('');
    const [totalTime, setTotalTime] = React.useState('');
    const [servings, setServings] = React.useState('4');
    const [description, setDescription] = React.useState('');

    const imageInputRef = React.useRef<HTMLInputElement | null>(null);

    React.useEffect(() => {
        if (!imageUrl) return undefined;

        return () => {
            URL.revokeObjectURL(imageUrl);
        };
    }, [imageUrl]);

    const loadRecipe = React.useCallback(async () => {
        if (!isEditMode || !recipeId) return;

        setLoading(true);
        setError(null);
        setFormError(null);

        try {
            const data = await getRecipe(recipeId);
            setSourceType(data.sourceType);

            const ingredientIds = Array.from(new Set((data.ingredients ?? []).map((ingredient) => ingredient.ingredientId)));
            let ingredientNames: Record<string, string> = {};

            if (ingredientIds.length) {
                const pairs = await Promise.all(
                    ingredientIds.map(async (id) => {
                        try {
                            const ingredient = await getIngredientById(id);
                            return [id, ingredient.name] as const;
                        } catch {
                            return [id, id.slice(0, 8)] as const;
                        }
                    }),
                );

                ingredientNames = Object.fromEntries(pairs);
            }

            setName(data.name ?? '');
            setMenuType((data.menuType ?? 'BALANCED') as MenuType);
            setMealType((data.mealType ?? '') as MealType | '');
            setComplexityRating(data.complexityRating ?? 3);
            setActiveTime(data.activeCookingTimeMinutes ? String(data.activeCookingTimeMinutes) : '');
            setTotalTime(data.totalTimeMinutes ? String(data.totalTimeMinutes) : '');
            setServings(data.defaultServings ? String(data.defaultServings) : '4');
            setDescription(data.description ?? '');
            reset({
                ingredients: toIngredientLines(data, ingredientNames),
                steps: normalizeSteps(data.steps, data.description),
            });

            try {
                const blob = await getRecipeImageBlob(recipeId);
                if (blob) {
                    setImageUrl(URL.createObjectURL(blob));
                } else {
                    setImageUrl(null);
                }
            } catch {
                setImageUrl(null);
            }
        } catch (nextError) {
            setError(toAlertMessage(nextError));
        } finally {
            setLoading(false);
        }
    }, [isEditMode, recipeId, reset]);

    React.useEffect(() => {
        if (!isEditMode) return;
        void loadRecipe();
    }, [isEditMode, loadRecipe]);

    const validate = React.useCallback(() => {
        if (!name.trim()) return 'Вкажіть назву рецепта.';
        if (!mealType) return 'Оберіть прийом їжі.';

        if (!Number.isFinite(complexityRating) || complexityRating < 1 || complexityRating > 5) {
            return 'Складність має бути в межах 1–5.';
        }

        const total = Number(totalTime);
        if (!Number.isFinite(total) || total <= 0) {
            return 'Загальний час має бути числом > 0.';
        }

        if (activeTime.trim()) {
            const active = Number(activeTime);
            if (!Number.isFinite(active) || active < 0) {
                return 'Активний час має бути числом ≥ 0.';
            }

            if (active > total) {
                return 'Активний час не може бути більший за загальний.';
            }
        }

        const servingsValue = Number(servings);
        if (!Number.isFinite(servingsValue) || servingsValue <= 0) {
            return 'Кількість порцій має бути числом > 0.';
        }

        const cleanedIngredients = ingredients
            .map((line) => ({
                ...line,
                ingredientName: line.ingredientName.trim(),
                quantityNum: Number(line.quantity),
            }))
            .filter(
                (line) =>
                    Boolean(line.ingredientId) ||
                    line.ingredientName.length > 0 ||
                    String(line.quantity).trim().length > 0 ||
                    Boolean(line.unit),
            );

        if (!cleanedIngredients.length) {
            return 'Додайте хоча б один інгредієнт.';
        }

        for (const line of cleanedIngredients) {
            if (!line.ingredientId) {
                return 'Оберіть інгредієнт зі списку підказок.';
            }

            if (!line.unit) {
                return 'Оберіть одиницю виміру для всіх інгредієнтів.';
            }

            if (!Number.isFinite(line.quantityNum) || line.quantityNum <= 0) {
                return 'Кількість інгредієнта має бути числом > 0.';
            }
        }

        if (!normalizeSteps(steps, description).length) {
            return 'Додайте хоча б один крок приготування.';
        }

        return null;
    }, [activeTime, complexityRating, description, ingredients, mealType, name, servings, steps, totalTime]);

    const buildPayload = React.useCallback((): RecipeCreateRequestDto => {
        return {
            name: name.trim(),
            description: description.trim() || undefined,
            menuType,
            mealType: mealType as MealType,
            complexityRating,
            activeCookingTimeMinutes: activeTime.trim() ? Number(activeTime) : undefined,
            totalTimeMinutes: Number(totalTime),
            defaultServings: Number(servings),
            ingredients: ingredients
                .filter((line) => line.ingredientId)
                .map((line) => ({
                    ingredientId: line.ingredientId as string,
                    quantity: Number(line.quantity),
                    unit: line.unit as MeasurementUnit,
                    optional: line.optional,
                })),
            steps: normalizeSteps(steps, description),
        };
    }, [activeTime, complexityRating, description, ingredients, mealType, menuType, name, servings, steps, totalTime]);

    const handleImageChange = async (file: File | null) => {
        if (!file) return;

        setError(null);
        setFormError(null);
        setSuccessMessage(null);

        if (!isEditMode || !recipeId) {
            setPendingImageFile(file);
            setImageUrl(URL.createObjectURL(file));
            setNotice('Фото буде збережено разом із рецептом.');

            if (imageInputRef.current) {
                imageInputRef.current.value = '';
            }

            return;
        }

        setSaving(true);
        setNotice(null);

        try {
            await uploadRecipeImage(recipeId, file);
            const blob = await getRecipeImageBlob(recipeId);
            if (blob) {
                setImageUrl(URL.createObjectURL(blob));
            }
            setNotice('Фото оновлено.');
        } catch (nextError) {
            setError(toAlertMessage(nextError));
        } finally {
            setSaving(false);
            if (imageInputRef.current) {
                imageInputRef.current.value = '';
            }
        }
    };

    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        if (successId) return;

        setFormError(null);
        setError(null);
        setNotice(null);
        setSuccessMessage(null);

        const validationError = validate();
        if (validationError) {
            setFormError(validationError);
            return;
        }

        setSaving(true);

        try {
            const payload = buildPayload();

            if (isEditMode && recipeId) {
                await updateRecipe(recipeId, payload);
                router.replace(`/recipes/${recipeId}?updated=1`);
                return;
            } else {
                const created = await createManualRecipe(payload);

                if (pendingImageFile) {
                    try {
                        await uploadRecipeImage(created.id, pendingImageFile);
                    } catch {
                        setSuccessId(created.id);
                        setSuccessMessage(
                            'Рецепт створено, але не вдалося завантажити фото. Його можна додати на сторінці редагування.',
                        );
                        return;
                    }
                }

                setSuccessId(created.id);
                setSuccessMessage('Рецепт створено.');
                setNotice(null);
            }
        } catch (nextError) {
            setError(toAlertMessage(nextError));
        } finally {
            setSaving(false);
        }
    };

    const showForm = !loading && (!isEditMode || !error);

    const actions = successId && !isEditMode ? null : (
        <>
            <Link href={cancelHref}>
                <Button variant="secondary" disabled={saving}>
                    Скасувати
                </Button>
            </Link>
            <Button type="submit" form={formId} disabled={saving || !showForm}>
                {saving ? 'Збереження…' : 'Зберегти'}
            </Button>
        </>
    );

    const titleAddon = (
        <Badge variant={recipeSourceBadgeVariant(sourceType)}>{formatRecipeSource(sourceType)}</Badge>
    );

    return (
        <div className="flex flex-col gap-6">
            <PageSection
                titleAs="h2"
                title={isEditMode ? 'Редагувати рецепт' : 'Новий рецепт'}
                subtitle={
                    isEditMode
                        ? 'Оновіть основну інформацію, інгредієнти та кроки приготування в одному місці.'
                        : 'Заповніть основну інформацію, інгредієнти та кроки приготування в одному місці.'
                }
                titleAddon={titleAddon}
                actions={actions}
            />

            {loading ? <Card className="text-sm text-text-muted">Завантаження рецепта…</Card> : null}

            {!loading && error ? (
                <Alert variant="error" title={isEditMode ? 'Не вдалося завантажити рецепт' : 'Не вдалося зберегти рецепт'}>
                    <span>
                        {error.message}
                        {typeof error.status === 'number' ? ` (HTTP ${error.status})` : null}
                    </span>
                </Alert>
            ) : null}

            {!loading && successId && successMessage ? (
                <Alert variant="success" title="Рецепт створено">
                    <div className="flex flex-col gap-3">
                        <span className="text-sm">{successMessage}</span>
                        <div className="flex flex-wrap items-center gap-2">
                            <Link href={`/recipes/${successId}`}>
                                <Button size="sm">Відкрити рецепт</Button>
                            </Link>
                            <Link href="/recipes">
                                <Button size="sm" variant="secondary">
                                    До списку рецептів
                                </Button>
                            </Link>
                        </div>
                    </div>
                </Alert>
            ) : null}

            {!loading && notice ? (
                <Alert variant={notice.includes('не вдалося') ? 'info' : 'success'}>{notice}</Alert>
            ) : null}

            {showForm ? (
                <form id={formId} className="space-y-4" onSubmit={handleSubmit} noValidate>
                    {formError ? (
                        <Alert variant="error" title="Перевірте форму">
                            {formError}
                        </Alert>
                    ) : null}

                    <Card className="grid gap-4 p-4 md:grid-cols-12">
                        <div className="md:col-span-4">
                            <div className="relative">
                                <div className="aspect-[4/3] overflow-hidden rounded-2xl border border-border bg-background">
                                    {imageUrl ? (
                                        // eslint-disable-next-line @next/next/no-img-element
                                        <img src={imageUrl} alt="Фото страви" className="h-full w-full object-cover"/>
                                    ) : (
                                        <div className="flex h-full w-full items-center justify-center text-xs text-text-muted">
                                            Немає фото
                                        </div>
                                    )}
                                </div>

                                <input
                                    ref={imageInputRef}
                                    type="file"
                                    accept="image/*"
                                    className="hidden"
                                    onChange={(event) => void handleImageChange(event.target.files?.[0] ?? null)}
                                />

                                <Button
                                    variant="icon"
                                    size="icon"
                                    onClick={() => imageInputRef.current?.click()}
                                    disabled={saving || Boolean(successId)}
                                    title={imageUrl ? 'Замінити фото' : 'Додати фото'}
                                    aria-label={imageUrl ? 'Замінити фото' : 'Додати фото'}
                                    className="absolute right-2 top-2 border border-border bg-surface/80 backdrop-blur hover:bg-surface"
                                >
                                    <ImageUploadIcon className="h-4 w-4"/>
                                </Button>
                            </div>

                            <p className="mt-2 text-xs text-text-muted">
                                {isEditMode
                                    ? 'Порада: фото опційне, але добре працює в списку рецептів і тижневому меню.'
                                    : 'Порада: фото опційне. Для нового рецепта воно збережеться після першого збереження форми.'}
                            </p>
                        </div>

                        <div className="space-y-4 md:col-span-8">
                            <div>
                                <h2 className="section-title">Основна інформація</h2>
                                <p className="section-subtitle">
                                    Заповніть назву, типи, складність, час і короткий опис.
                                </p>
                            </div>

                            <div className="space-y-1">
                                <label>Назва *</label>
                                <Input
                                    value={name}
                                    onChange={(event) => setName(event.target.value)}
                                    disabled={saving || Boolean(successId)}
                                />
                            </div>

                            <div className="grid gap-3 md:grid-cols-3">
                                <div className="space-y-1">
                                    <label>Тип меню</label>
                                    <Select
                                        value={menuType}
                                        onChange={(event) => setMenuType(event.target.value as MenuType)}
                                        disabled={saving || Boolean(successId)}
                                    >
                                        {MENU_TYPE_OPTIONS.map((option) => (
                                            <option key={option.value} value={option.value}>
                                                {option.label}
                                            </option>
                                        ))}
                                    </Select>
                                </div>

                                <div className="space-y-1">
                                    <label>Прийом їжі *</label>
                                    <Select
                                        value={mealType}
                                        onChange={(event) => setMealType(event.target.value as MealType | '')}
                                        disabled={saving || Boolean(successId)}
                                    >
                                        <option value="">Оберіть…</option>
                                        {MEAL_TYPE_OPTIONS.map((option) => (
                                            <option key={option.value} value={option.value}>
                                                {option.label}
                                            </option>
                                        ))}
                                    </Select>
                                </div>

                                <div className="space-y-1">
                                    <label>Складність *</label>
                                    <div className="flex items-center justify-between gap-3">
                                        <StarRating
                                            value={complexityRating}
                                            onChange={setComplexityRating}
                                            disabled={saving || Boolean(successId)}
                                        />
                                        <div className="w-10 text-right text-sm font-semibold">{complexityRating}/5</div>
                                    </div>
                                </div>
                            </div>

                            <div className="grid gap-3 md:grid-cols-2">
                                <div className="space-y-1">
                                    <label>Активний час (хв)</label>
                                    <Input
                                        inputMode="numeric"
                                        value={activeTime}
                                        onChange={(event) => setActiveTime(event.target.value)}
                                        disabled={saving || Boolean(successId)}
                                        placeholder="напр., 20"
                                    />
                                </div>

                                <div className="space-y-1">
                                    <label>Загальний час (хв) *</label>
                                    <Input
                                        inputMode="numeric"
                                        value={totalTime}
                                        onChange={(event) => setTotalTime(event.target.value)}
                                        disabled={saving || Boolean(successId)}
                                        placeholder="напр., 45"
                                    />
                                </div>
                            </div>

                            <div className="space-y-1">
                                <label>Опис (опційно)</label>
                                <Textarea
                                    rows={3}
                                    value={description}
                                    onChange={(event) => setDescription(event.target.value)}
                                    disabled={saving || Boolean(successId)}
                                    placeholder="Короткі нотатки або поради…"
                                />
                            </div>
                        </div>
                    </Card>

                    <RecipeIngredientsStepsCard
                        ingredients={ingredients}
                        steps={steps}
                        disabled={saving || Boolean(successId)}
                        minSteps={DEFAULT_STEPS}
                        servings={servings}
                        onServingsChange={setServings}
                        onAddIngredient={addIngredient}
                        onRemoveIngredient={removeIngredient}
                        onUpdateIngredient={updateIngredient}
                        onAddStep={addStep}
                        onUpdateStep={updateStep}
                        onClearOrRemoveStep={clearOrRemoveStep}
                    />
                </form>
            ) : null}
        </div>
    );
}
