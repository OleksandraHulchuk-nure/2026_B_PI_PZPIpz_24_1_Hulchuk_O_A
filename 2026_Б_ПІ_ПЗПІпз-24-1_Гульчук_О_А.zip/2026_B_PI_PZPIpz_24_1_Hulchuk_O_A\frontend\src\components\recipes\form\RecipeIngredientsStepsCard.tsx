'use client';

import * as React from 'react';
import {Card} from '@/components/ui/card';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Select} from '@/components/ui/select';
import {Textarea} from '@/components/ui/textarea';

import {UNIT_OPTIONS, type MeasurementUnit, type ProductCategory} from '@/lib/api/recipeApi';
import {IngredientAutocomplete} from '@/components/recipes/form/IngredientAutocomplete';

export type RecipeIngredientLine = {
    id: string;
    ingredientId: string | null;
    ingredientName: string;
    ingredientNameUk?: string | null;
    ingredientNameEn?: string | null;
    category?: ProductCategory | null;
    defaultUnit?: MeasurementUnit | null;
    quantity: string;
    unit: MeasurementUnit | '';
    optional: boolean;
};

export function RecipeIngredientsStepsCard({
                                               ingredients,
                                               steps,
                                               disabled,
                                               minSteps = 5,

                                               servings,
                                               onServingsChange,

                                               onAddIngredient,
                                               onRemoveIngredient,
                                               onUpdateIngredient,
                                               onAddStep,
                                               onUpdateStep,
                                               onClearOrRemoveStep,
                                           }: {
    ingredients: RecipeIngredientLine[];
    steps: string[];
    disabled?: boolean;
    minSteps?: number;

    servings?: string;
    onServingsChange?: (v: string) => void;

    onAddIngredient: () => void;
    onRemoveIngredient: (id: string) => void;
    onUpdateIngredient: (id: string, patch: Partial<RecipeIngredientLine>) => void;

    onAddStep: () => void;
    onUpdateStep: (index: number, value: string) => void;
    onClearOrRemoveStep: (index: number) => void;
}) {
    return (
        <Card className="p-4">
            <div className="grid gap-4 md:grid-cols-2 md:gap-4">
                {/* INGREDIENTS */}
                <div className="md:border-r md:border-border/60 md:pr-4">
                    <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
                        <div>
                            <h3 className="section-title">Інгредієнти *</h3>
                            <p className="section-subtitle">Введіть 2+ символи — виберіть зі словника.</p>
                        </div>
                        <Button
                            variant="secondary"
                            size="sm"
                            onClick={onAddIngredient}
                            disabled={disabled}
                            type="button"
                        >
                            Додати
                        </Button>
                    </div>

                    <div className="mb-3 flex justify-end">
                        {onServingsChange ? (
                            <div className="flex items-center gap-2">
                                <label className="whitespace-nowrap text-xs text-text-muted">Порції *</label>

                                <div className="w-14">
                                    <Input
                                        inputMode="numeric"
                                        value={servings}
                                        disabled={disabled}
                                        onChange={(e) => onServingsChange(e.target.value)}
                                    />
                                </div>
                            </div>
                        ) : null}
                    </div>

                    <div className="hidden md:grid grid-cols-12 gap-2 text-xs text-text-muted mb-2">
                        <div className="col-span-6">Інгредієнт</div>
                        <div className="col-span-2">К-ть</div>
                        <div className="col-span-2">Одиниця</div>
                        <div className="col-span-1 text-center">Опц.</div>
                        <div className="col-span-1" />
                    </div>

                    <div className="space-y-2">
                        {ingredients.map((line) => (
                            <div key={line.id} className="grid grid-cols-12 gap-2 items-center">
                                <div className="col-span-12 md:col-span-6">
                                    <IngredientAutocomplete
                                        value={line.ingredientName}
                                        disabled={disabled}
                                        placeholder="Напр. Морква"
                                        onValueChange={(v) =>
                                            onUpdateIngredient(line.id, {
                                                ingredientName: v,
                                                ingredientNameUk: v,
                                                ingredientNameEn: null,
                                                ingredientId: null,
                                                category: null,
                                                defaultUnit: null,
                                            })
                                        }
                                        onPick={(i) => {
                                            onUpdateIngredient(line.id, {
                                                ingredientId: i.id,
                                                ingredientName: i.name,
                                                ingredientNameUk: i.nameUk ?? i.name,
                                                ingredientNameEn: i.nameEn ?? null,
                                                category: i.category ?? null,
                                                defaultUnit: i.defaultUnit ?? null,
                                                unit: (line.unit || i.defaultUnit || '') as MeasurementUnit | '',
                                            });
                                        }}
                                    />
                                </div>

                                <div className="col-span-4 md:col-span-2">
                                    <Input
                                        inputMode="decimal"
                                        value={line.quantity}
                                        disabled={disabled}
                                        onChange={(e) => onUpdateIngredient(line.id, { quantity: e.target.value })}
                                        placeholder="200"
                                    />
                                </div>

                                <div className="col-span-4 md:col-span-2">
                                    <Select
                                        value={line.unit}
                                        disabled={disabled}
                                        onChange={(e) => onUpdateIngredient(line.id, {unit: e.target.value as MeasurementUnit | ''})}
                                    >
                                        <option value=""></option>
                                        {UNIT_OPTIONS.map((o) => (
                                            <option key={o.value} value={o.value}>
                                                {o.label}
                                            </option>
                                        ))}
                                    </Select>
                                </div>

                                <div className="col-span-2 md:col-span-1 flex justify-center">
                                    <label
                                        className="flex h-10 w-10 items-center justify-center rounded-lg hover:bg-background/60"
                                        title="Опційний інгредієнт"
                                    >
                                        <input
                                            type="checkbox"
                                            className="h-4 w-4 accent-[color:var(--primary)]"
                                            checked={line.optional}
                                            disabled={disabled}
                                            onChange={(e) => onUpdateIngredient(line.id, { optional: e.target.checked })}
                                        />
                                        <span className="sr-only">Опційний інгредієнт</span>
                                    </label>
                                </div>

                                <div className="col-span-2 md:col-span-1 flex justify-end">
                                    <Button
                                        variant="iconDanger"
                                        size="icon"
                                        disabled={disabled || ingredients.length <= 1}
                                        onClick={() => onRemoveIngredient(line.id)}
                                        type="button"
                                        title="Видалити"
                                        aria-label="Видалити інгредієнт"
                                    >
                                        ✕
                                    </Button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* STEPS */}
                <div>
                    <div className="mb-3 flex items-start justify-between gap-3">
                        <div>
                            <h3 className="section-title">Кроки приготування *</h3>
                        </div>
                        <Button variant="secondary" size="sm" onClick={onAddStep} disabled={disabled} type="button">
                            Додати
                        </Button>
                    </div>

                    <div className="space-y-2">
                        {steps.map((step, idx) => (
                            <div key={idx} className="flex items-start gap-2">
                                <div className="flex-1 space-y-1">
                                    <label>Крок {idx + 1}</label>
                                    <Textarea
                                        value={step}
                                        disabled={disabled}
                                        onChange={(e) => onUpdateStep(idx, e.target.value)}
                                        rows={2}
                                        placeholder={idx === 0 ? 'Напр.: Наріжте овочі…' : ''}
                                    />
                                </div>

                                <Button
                                    variant="iconDanger"
                                    size="icon"
                                    type="button"
                                    disabled={disabled}
                                    onClick={() => onClearOrRemoveStep(idx)}
                                    title={steps.length > minSteps ? 'Видалити' : 'Очистити'}
                                    aria-label={steps.length > minSteps ? 'Видалити крок' : 'Очистити крок'}
                                >
                                    ✕
                                </Button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </Card>
    );
}
