import type { IngredientPreferenceKind } from '@/lib/api/profileApi';

export const KINDS: IngredientPreferenceKind[] = [
    'FAVORITE',
    'DISLIKED',
    'ALLERGY',
    'EXCLUDED',
];

export const KIND_META: Record<
    IngredientPreferenceKind,
    { title: string; description: string }
> = {
    FAVORITE: {
        title: 'Улюблені інгредієнти',
        description: 'Частіше підставляти ці продукти в рецептах.',
    },
    DISLIKED: {
        title: 'Не любимо',
        description: 'Старатися уникати в меню.',
    },
    ALLERGY: {
        title: 'Алергії',
        description: 'Ніколи не використовувати в рецептах.',
    },
    EXCLUDED: {
        title: 'Суворі виключення',
        description: 'Не включати в меню навіть у малих кількостях.',
    },
};
