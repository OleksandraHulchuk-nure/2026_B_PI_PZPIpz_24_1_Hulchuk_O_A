import type { BadgeProps } from '@/components/ui/badge';

export type MealType = 'BREAKFAST' | 'LUNCH' | 'DINNER' | 'SNACK';
export type MeasurementUnit = 'GRAM' | 'MILLILITER' | 'PIECE';
export type MenuStatus = 'DRAFT' | 'APPROVED';
export type MenuType = 'BALANCED' | 'VEGETARIAN' | 'MORE_MEAT' | 'MORE_FISH' | 'MORE_VEGGIES';
export type RecipeSourceType = 'MANUAL' | 'AI';
export type RecipeStatus = 'TO_VERIFY' | 'VERIFIED' | 'REJECTED';
export type ProductCategory =
    | 'VEGETABLES'
    | 'FRUITS'
    | 'MEAT'
    | 'DAIRY'
    | 'GRAINS'
    | 'FISH_AND_SEAFOOD'
    | 'EGGS'
    | 'BAKERY'
    | 'SWEETS_AND_SNACKS'
    | 'BEVERAGES'
    | 'CANNED_AND_JARRED'
    | 'FROZEN'
    | 'SAUCES_AND_SPICES'
    | 'NUTS_AND_SEEDS'
    | 'OTHER';

type BadgeVariant = BadgeProps['variant'];

export const MEAL_TYPE_LABELS: Record<MealType, string> = {
    BREAKFAST: 'Сніданок',
    LUNCH: 'Обід',
    DINNER: 'Вечеря',
    SNACK: 'Перекус',
};

export const MEASUREMENT_UNIT_LABELS: Record<MeasurementUnit, string> = {
    GRAM: 'г',
    MILLILITER: 'мл',
    PIECE: 'шт',
};

export const MENU_STATUS_LABELS: Record<MenuStatus, string> = {
    DRAFT: 'Чернетка',
    APPROVED: 'Підтверджено',
};

export const MENU_TYPE_LABELS: Record<MenuType, string> = {
    BALANCED: 'Збалансоване',
    VEGETARIAN: 'Вегетаріанське',
    MORE_MEAT: "Більше м'яса",
    MORE_FISH: 'Більше риби',
    MORE_VEGGIES: 'Більше овочів',
};

export const MENU_TYPE_ICONS: Record<MenuType, string> = {
    BALANCED: 'balance',
    VEGETARIAN: 'nutrition',
    MORE_MEAT: "kebab_dining",
    MORE_FISH: 'set_meal',
    MORE_VEGGIES: 'grass',
};

export const RECIPE_SOURCE_LABELS: Record<RecipeSourceType, string> = {
    MANUAL: 'Мій рецепт',
    AI: 'AI рецепт',
};

export const RECIPE_SOURCE_ICONS: Record<RecipeSourceType, string> = {
    MANUAL: 'face',
    AI: 'smart_toy',
};

export const RECIPE_STATUS_LABELS: Record<RecipeStatus, string> = {
    TO_VERIFY: 'Не тестований',
    VERIFIED: 'Перевірений',
    REJECTED: 'Не сподобалось',
};

export const RECIPE_STATUS_ICONS: Record<RecipeStatus, string> = {
    TO_VERIFY: 'lab_research',
    VERIFIED: 'done_outline',
    REJECTED: 'thumb_down',
};

export const PRODUCT_CATEGORY_LABELS: Record<ProductCategory, string> = {
    VEGETABLES: 'Овочі',
    FRUITS: 'Фрукти',
    MEAT: "М'ясо",
    DAIRY: 'Молочні продукти',
    GRAINS: 'Крупи та макарони',
    FISH_AND_SEAFOOD: 'Риба та морепродукти',
    EGGS: 'Яйця',
    BAKERY: 'Хліб та випічка',
    SWEETS_AND_SNACKS: 'Солодощі та снеки',
    BEVERAGES: 'Напої',
    CANNED_AND_JARRED: 'Консервація',
    FROZEN: 'Заморожене',
    SAUCES_AND_SPICES: 'Соуси та спеції',
    NUTS_AND_SEEDS: 'Горіхи та насіння',
    OTHER: 'Інше',
};

export const MEAL_TYPES = Object.keys(MEAL_TYPE_LABELS) as MealType[];
export const MENU_TYPES = Object.keys(MENU_TYPE_LABELS) as MenuType[];
export const RECIPE_STATUSES = Object.keys(RECIPE_STATUS_LABELS) as RecipeStatus[];
export const RECIPE_SOURCE_TYPES = Object.keys(RECIPE_SOURCE_LABELS) as RecipeSourceType[];

export const MEAL_TYPE_OPTIONS: Array<{ value: MealType; label: string }> = MEAL_TYPES.map(
    (value) => ({ value, label: MEAL_TYPE_LABELS[value] }),
);

export const MENU_TYPE_OPTIONS: Array<{ value: MenuType; label: string }> = MENU_TYPES.map(
    (value) => ({ value, label: MENU_TYPE_LABELS[value] }),
);

export const UNIT_OPTIONS: Array<{ value: MeasurementUnit; label: string }> = (
    Object.entries(MEASUREMENT_UNIT_LABELS)
).map(([value, label]) => ({ value: value as MeasurementUnit, label }));

export const RECIPE_STATUS_OPTIONS: Array<{ value: RecipeStatus; label: string }> = (
    RECIPE_STATUSES
).map((value) => ({ value, label: RECIPE_STATUS_LABELS[value] }));

export const RECIPE_SOURCE_OPTIONS: Array<{ value: RecipeSourceType; label: string }> = (
    RECIPE_SOURCE_TYPES
).map((value) => ({ value, label: RECIPE_SOURCE_LABELS[value] }));

export function mealTypeBadgeVariant(mealType: MealType): BadgeVariant {
    switch (mealType) {
        case 'BREAKFAST':
            return 'info';
        case 'LUNCH':
            return 'soft';
        case 'DINNER':
            return 'warm';
        case 'SNACK':
            return 'secondary';
    }
}

export function menuTypeBadgeVariant(menuType: MenuType): BadgeVariant {
    switch (menuType) {
        case 'BALANCED':
            return 'soft';
        case 'VEGETARIAN':
            return 'secondary';
        case 'MORE_MEAT':
            return 'warm';
        case 'MORE_FISH':
            return 'info';
        case 'MORE_VEGGIES':
            return 'soft';
    }
}

export function menuStatusBadgeVariant(status: MenuStatus): BadgeVariant {
    switch (status) {
        case 'APPROVED':
            return 'status';
        case 'DRAFT':
            return 'statusWarning';
    }
}

export function recipeStatusBadgeVariant(status: RecipeStatus): BadgeVariant {
    switch (status) {
        case 'VERIFIED':
            return 'status';
        case 'TO_VERIFY':
            return 'statusWarning';
        case 'REJECTED':
            return 'statusError';
    }
}

export function recipeSourceBadgeVariant(source: RecipeSourceType): BadgeVariant {
    switch (source) {
        case 'AI':
            return 'ai';
        case 'MANUAL':
            return 'soft';
    }
}

export function measurementUnitBadgeVariant(): BadgeVariant {
    return 'info';
}

export const PRODUCT_CATEGORY_ORDER: ProductCategory[] = [
    'VEGETABLES',
    'FRUITS',
    'MEAT',
    'FISH_AND_SEAFOOD',
    'DAIRY',
    'EGGS',
    'GRAINS',
    'BAKERY',
    'SAUCES_AND_SPICES',
    'CANNED_AND_JARRED',
    'FROZEN',
    'NUTS_AND_SEEDS',
    'SWEETS_AND_SNACKS',
    'BEVERAGES',
    'OTHER',
];

