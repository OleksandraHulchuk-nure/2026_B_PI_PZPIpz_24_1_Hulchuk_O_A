package com.nure.whatwecook.repository.reports;

import com.nure.whatwecook.dto.reports.WeeklyMenuReportDto;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.DataClassRowMapper;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Repository
@RequiredArgsConstructor
public class WeeklyMenuReportQueryRepository {

    private final JdbcClient jdbc;

    public WeeklyMenuReportDto loadWeeklyMenuReport(UUID userId, UUID weeklyMenuId) {

        List<MenuMealFlatRow> rows = jdbc.sql("""
                            SELECT
                              wm.id                 AS weeklyMenuId,
                              wm.start_date         AS startDate,
                              wm.status             AS status,
                              md.date               AS dayDate,
                              mm.meal_type          AS mealType,
                              r.id                  AS recipeId,
                              r.name                AS recipeName,
                              r.total_time_minutes  AS totalTimeMinutes,
                              r.default_servings    AS defaultServings
                            FROM weekly_menu wm
                            JOIN menu_day md ON md.weekly_menu_id = wm.id
                            JOIN menu_meal mm ON mm.menu_day_id = md.id
                            LEFT JOIN recipe r ON r.id = mm.recipe_id
                            WHERE wm.id = :weeklyMenuId
                              AND wm.user_id = :userId
                            ORDER BY md.date, mm.meal_type
                        """)
                .param("weeklyMenuId", weeklyMenuId)
                .param("userId", userId)
                .query(new DataClassRowMapper<>(MenuMealFlatRow.class))
                .list();

        if (rows.isEmpty()) {
            throw new IllegalArgumentException("Weekly menu not found or not owned by user");
        }

        LocalDate startDate = rows.get(0).startDate();
        String status = rows.get(0).status();

        Map<LocalDate, List<WeeklyMenuReportDto.MenuMeal>> mealsByDay = new LinkedHashMap<>();
        for (MenuMealFlatRow r : rows) {
            mealsByDay.computeIfAbsent(r.dayDate(), d -> new ArrayList<>())
                    .add(new WeeklyMenuReportDto.MenuMeal(
                            r.mealType(),
                            r.recipeId(),
                            r.recipeName(),
                            r.totalTimeMinutes()
                    ));
        }

        List<WeeklyMenuReportDto.MenuDay> days = mealsByDay.entrySet().stream()
                .map(e -> new WeeklyMenuReportDto.MenuDay(e.getKey(), e.getValue()))
                .toList();

        List<UUID> recipeIds = rows.stream()
                .map(MenuMealFlatRow::recipeId)
                .filter(Objects::nonNull)
                .distinct()
                .toList();

        Map<UUID, List<WeeklyMenuReportDto.IngredientLine>> ingredientsByRecipe = loadIngredients(recipeIds);
        Map<UUID, List<WeeklyMenuReportDto.StepLine>> stepsByRecipe = loadSteps(recipeIds);

        Map<UUID, WeeklyMenuReportDto.RecipeDetails> details = new LinkedHashMap<>();
        for (MenuMealFlatRow r : rows) {
            if (r.recipeId() == null) continue;
            details.putIfAbsent(r.recipeId(), new WeeklyMenuReportDto.RecipeDetails(
                    r.recipeId(),
                    r.recipeName(),
                    r.totalTimeMinutes(),
                    r.defaultServings(),
                    ingredientsByRecipe.getOrDefault(r.recipeId(), List.of()),
                    stepsByRecipe.getOrDefault(r.recipeId(), List.of())
            ));
        }

        return new WeeklyMenuReportDto(weeklyMenuId, startDate, status, days, details);
    }

    private Map<UUID, List<WeeklyMenuReportDto.IngredientLine>> loadIngredients(List<UUID> recipeIds) {
        if (recipeIds.isEmpty()) return Map.of();

        List<IngredientRow> rows = jdbc.sql("""
                            SELECT
                              ri.recipe_id   AS recipeId,
                              i.name_uk      AS ingredientNameUk,
                              ri.quantity    AS quantity,
                              ri.unit        AS unit
                            FROM recipe_ingredient ri
                            JOIN ingredient i ON i.id = ri.ingredient_id
                            WHERE ri.recipe_id IN (:recipeIds)
                            ORDER BY ri.recipe_id, i.name_uk
                        """)
                .param("recipeIds", recipeIds)
                .query(new DataClassRowMapper<>(IngredientRow.class))
                .list();

        Map<UUID, List<WeeklyMenuReportDto.IngredientLine>> map = new LinkedHashMap<>();
        for (IngredientRow r : rows) {
            map.computeIfAbsent(r.recipeId(), k -> new ArrayList<>())
                    .add(new WeeklyMenuReportDto.IngredientLine(r.ingredientNameUk(), r.quantity(), r.unit()));
        }
        return map;
    }

    private Map<UUID, List<WeeklyMenuReportDto.StepLine>> loadSteps(List<UUID> recipeIds) {
        if (recipeIds.isEmpty()) return Map.of();

        List<StepRow> rows = jdbc.sql("""
                            SELECT
                              recipe_id    AS recipeId,
                              order_index  AS orderIndex,
                              description  AS description
                            FROM recipe_step
                            WHERE recipe_id IN (:recipeIds)
                            ORDER BY recipe_id, order_index
                        """)
                .param("recipeIds", recipeIds)
                .query(new DataClassRowMapper<>(StepRow.class))
                .list();

        Map<UUID, List<WeeklyMenuReportDto.StepLine>> map = new LinkedHashMap<>();
        for (StepRow r : rows) {
            map.computeIfAbsent(r.recipeId(), k -> new ArrayList<>())
                    .add(new WeeklyMenuReportDto.StepLine(r.orderIndex(), r.description()));
        }
        return map;
    }

    private record MenuMealFlatRow(
            UUID weeklyMenuId,
            LocalDate startDate,
            String status,
            LocalDate dayDate,
            String mealType,
            UUID recipeId,
            String recipeName,
            Integer totalTimeMinutes,
            Integer defaultServings
    ) {
    }

    private record IngredientRow(
            UUID recipeId,
            String ingredientNameUk,
            BigDecimal quantity,
            String unit
    ) {
    }

    private record StepRow(
            UUID recipeId,
            int orderIndex,
            String description
    ) {
    }
}
