package com.nure.whatwecook.dto.reports;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public record WeeklyMenuReportDto(
        UUID weeklyMenuId,
        LocalDate startDate,
        String status,
        List<MenuDay> days,
        Map<UUID, RecipeDetails> recipeDetailsById
) {
    public record MenuDay(
            LocalDate date,
            List<MenuMeal> meals
    ) {}

    public record MenuMeal(
            String mealType,
            UUID recipeId,
            String recipeName,
            Integer totalTimeMinutes
    ) {}

    public record RecipeDetails(
            UUID recipeId,
            String recipeName,
            Integer totalTimeMinutes,
            Integer defaultServings,
            List<IngredientLine> ingredients,
            List<StepLine> steps
    ) {}

    public record IngredientLine(
            String ingredientNameUk,
            BigDecimal quantity,
            String unit
    ) {}

    public record StepLine(
            int orderIndex,
            String description
    ) {}
}
