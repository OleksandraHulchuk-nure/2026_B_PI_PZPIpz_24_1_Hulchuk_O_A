package com.nure.whatwecook.controller;


import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.enums.ProductCategory;
import com.nure.whatwecook.dto.ingredient.AggregatedIngredientDto;
import com.nure.whatwecook.dto.ingredient.IngredientDetailsDto;
import com.nure.whatwecook.dto.ingredient.IngredientShortDto;
import com.nure.whatwecook.mapper.IngredientMapper;
import com.nure.whatwecook.service.IngredientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Tag(name = "Ingredients", description = "Ingredient dictionary and search")
@RestController
@RequestMapping("/api/ingredients")
@RequiredArgsConstructor
public class IngredientController {

    private final CurrentUserProvider currentUserProvider;
    private final IngredientService ingredientService;
    private final IngredientMapper ingredientMapper;

    @Operation(
            summary = "Search ingredients",
            description = "Search ingredients for autocomplete by name and optional category"
    )
    @GetMapping
    public ResponseEntity<List<IngredientShortDto>> searchIngredients(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "category", required = false) ProductCategory category
    ) {
        List<Ingredient> ingredients = ingredientService.searchIngredients(search, category);
        return ResponseEntity.ok(ingredientMapper.toShortDtoList(ingredients));
    }

    @Operation(
            summary = "Get ingredient by id",
            description = "Retrieve ingredient details (for debug/admin usage)"
    )
    @GetMapping("/{id}")
    public ResponseEntity<IngredientDetailsDto> getIngredientById(@PathVariable("id") UUID id) {
        Ingredient ingredient = ingredientService.getIngredientById(id);
        return ResponseEntity.ok(ingredientMapper.toDetailsDto(ingredient));
    }

    @Operation(
            summary = "Get aggregated ingredients for a menu day",
            description = "Aggregates recipe ingredients for all meals planned on the specified date"
    )
    @GetMapping("/aggregated/{date}")
    public ResponseEntity<List<AggregatedIngredientDto>> getAggregatedIngredientsByDate(
            @PathVariable("date")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        List<AggregatedIngredientDto> aggregated = ingredientService.getAggregatedIngredientsByDate(userId, date);
        return ResponseEntity.ok(aggregated);
    }
}
