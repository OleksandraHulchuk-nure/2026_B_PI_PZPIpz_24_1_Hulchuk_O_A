package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.entity.recipe.RecipeIngredient;
import com.nure.whatwecook.domain.entity.profile.User;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.RecipeSourceType;
import com.nure.whatwecook.domain.enums.RecipeStatus;
import com.nure.whatwecook.repository.RecipeIngredientRepository;
import com.nure.whatwecook.repository.RecipeRepository;
import com.nure.whatwecook.repository.UserRepository;
import com.nure.whatwecook.service.RecipeService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class RecipeServiceImpl implements RecipeService {

    private final RecipeRepository recipeRepository;
    private final RecipeIngredientRepository recipeIngredientRepository;
    private final UserRepository userRepository;

    @Override
    public Page<Recipe> getUserRecipes(UUID userId,
                                       String search,
                                       RecipeStatus status,
                                       RecipeSourceType sourceType,
                                       MealType mealType,
                                       Integer maxTotalTimeMinutes,
                                       Pageable pageable) {

        String pattern = null;
        if (search != null && !search.isBlank()) {
            pattern = "%" + search.trim().toLowerCase() + "%";
        }

        return recipeRepository.findByUserAndFilters(
                userId,
                pattern,
                status,
                sourceType,
                mealType,
                maxTotalTimeMinutes,
                pageable
        );
    }

    @Override
    public Recipe getRecipeById(UUID userId, UUID recipeId) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new EntityNotFoundException("Recipe not found"));

        if (!recipe.getUser().getId().equals(userId)) {
            throw new EntityNotFoundException("Recipe not found");
        }
        return recipe;
    }

    @Override
    @Transactional
    public Recipe createManualRecipe(UUID userId,
                                     Recipe recipe,
                                     List<RecipeIngredient> ingredients) {
        return createRecipe(userId, recipe, ingredients, RecipeSourceType.MANUAL);
    }

    @Override
    @Transactional
    public Recipe createAiRecipe(UUID userId,
                                 Recipe recipe,
                                 List<RecipeIngredient> ingredients) {
        return createRecipe(userId, recipe, ingredients, RecipeSourceType.AI);
    }

    private Recipe createRecipe(UUID userId,
                                Recipe recipe,
                                List<RecipeIngredient> ingredients,
                                RecipeSourceType sourceType) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));

        recipe.setId(null);
        recipe.setUser(user);
        recipe.setSourceType(sourceType);
        recipe.setStatus(RecipeStatus.TO_VERIFY);

        recipe.getIngredients().clear();
        for (RecipeIngredient ingredient : ingredients) {
            ingredient.setId(null);
            ingredient.setRecipe(recipe);
            recipe.getIngredients().add(ingredient);
        }

        return recipeRepository.save(recipe);
    }

    @Override
    @Transactional
    public Recipe updateManualRecipe(UUID userId,
                                     UUID recipeId,
                                     Recipe recipeData,
                                     List<RecipeIngredient> ingredients) {
        Recipe existing = getRecipeById(userId, recipeId);

        existing.setName(recipeData.getName());
        existing.setDescription(recipeData.getDescription());
        existing.setMenuType(recipeData.getMenuType());
        existing.setMealType(recipeData.getMealType());
        existing.setActiveCookingTimeMinutes(recipeData.getActiveCookingTimeMinutes());
        existing.setTotalTimeMinutes(recipeData.getTotalTimeMinutes());
        existing.setDefaultServings(recipeData.getDefaultServings());
        existing.setComplexityRating(recipeData.getComplexityRating());
        existing.setSteps(recipeData.getSteps());

        existing.getIngredients().clear();
        recipeIngredientRepository.deleteByRecipeId(existing.getId());

        for (RecipeIngredient ingredient : ingredients) {
            ingredient.setId(null);
            ingredient.setRecipe(existing);
            existing.getIngredients().add(ingredient);
        }

        return recipeRepository.save(existing);
    }

    @Override
    @Transactional
    public void deleteRecipe(UUID userId, UUID recipeId) {
        Recipe recipe = getRecipeById(userId, recipeId);
        recipeRepository.delete(recipe); // hard delete
    }

    @Override
    @Transactional
    public Recipe updateRecipeRating(UUID userId,
                                     UUID recipeId,
                                     Integer complexityRating,
                                     Integer tasteRating,
                                     String ratingComment,
                                     RecipeStatus status) {
        Recipe recipe = getRecipeById(userId, recipeId);
        if (complexityRating != null) {
            recipe.setComplexityRating(complexityRating);
        }
        if (tasteRating != null) {
            recipe.setTasteRating(tasteRating);
        }
        if (ratingComment != null) {
            recipe.setRatingComment(ratingComment);
        }
        if (status != null) {
            recipe.setStatus(status);
        }
        return recipeRepository.save(recipe);
    }

    @Override
    @Transactional
    public Recipe updateRecipeStatus(UUID userId,
                                     UUID recipeId,
                                     RecipeStatus status) {
        Recipe recipe = getRecipeById(userId, recipeId);
        recipe.setStatus(status);
        return recipeRepository.save(recipe);
    }
}
