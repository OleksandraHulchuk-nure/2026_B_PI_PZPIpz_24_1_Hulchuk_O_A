export const API_ROUTES = {
    auth: {
        register: '/api/auth/register',
        login: '/api/auth/login',
        logout: '/api/auth/logout',
        me: '/api/auth/me',
    },

    profile: '/api/profile',

    preferences: {
        mealTimes: '/api/preferences/meal-times',
        ingredients: '/api/preferences/ingredients',
        mealSchedule: '/api/preferences/meal-schedule',
    },

    ingredients: {
        root: '/api/ingredients',
        aggregated: '/api/ingredients/aggregated',
    },

    recipes: {
        root: '/api/recipes',
        manual: '/api/recipes/manual',
        aiGenerate: '/api/recipes/ai/generate',
        aiRegenerate: '/api/recipes/ai/regenerate',
        aiSave: '/api/recipes/ai/save',
    },

    weeklyMenus: {
        root: '/api/menus/weekly',
        generate: '/api/menus/weekly/generate',
        byStartDate: '/api/menus/weekly/by-start-date',
    },

    shoppingLists: {
        root: '/api/shopping-lists',
        fromWeeklyMenu: '/api/shopping-lists/from-weekly-menu',
        byStartDate: '/api/shopping-lists/by-start-date',
    },

    reports: {
        weeklyMenu: '/api/reports/weekly-menu',
        shoppingList: '/api/reports/shopping-list',
    },

    stats: {
        menuMetrics: '/api/stats/menu',
        aiMetrics: '/api/stats/ai',
        topCategories: '/api/stats/top-categories',
        topIngredients: '/api/stats/top-ingredients',
    },
} as const;
