package com.nure.whatwecook.service;

import com.nure.whatwecook.domain.entity.profile.UserMealPreference;

import java.util.List;
import java.util.UUID;

public interface UserMealPreferenceService {

    List<UserMealPreference> getUserMealPreferences(UUID userId);

    List<UserMealPreference> replaceUserMealPreferences(UUID userId, List<UserMealPreference> preferences);
}
