package com.nure.whatwecook.controller;

import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.entity.recipe.RecipeImage;
import com.nure.whatwecook.dto.ai.AiRecipeDraftDto;
import com.nure.whatwecook.dto.ai.AiRecipeGenerateRequestDto;
import com.nure.whatwecook.dto.recipe.RecipeDetailsDto;
import com.nure.whatwecook.mapper.RecipeMapper;
import com.nure.whatwecook.service.AiRecipeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@Tag(name = "AI recipes", description = "Generate and save AI recipe drafts")
@RestController
@RequestMapping("/api/recipes/ai")
@RequiredArgsConstructor
public class AiRecipeController {

    private final CurrentUserProvider currentUserProvider;
    private final AiRecipeService aiRecipeService;
    private final RecipeMapper recipeMapper;

    @Operation(summary = "Generate AI recipe draft")
    @PostMapping("/generate")
    public ResponseEntity<AiRecipeDraftDto> generateRecipeDraft(
            @Valid @RequestBody AiRecipeGenerateRequestDto request
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        return ResponseEntity.ok(aiRecipeService.generateRecipeDraft(userId, request));
    }

    @Operation(summary = "Save AI recipe draft to recipe book")
    @PostMapping("/save")
    public ResponseEntity<RecipeDetailsDto> saveRecipeDraft(
            @Valid @RequestBody AiRecipeDraftDto draft
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        Recipe recipe = aiRecipeService.saveGeneratedRecipe(userId, draft);
        return ResponseEntity.ok(enrichDetails(recipe));
    }

    private RecipeDetailsDto enrichDetails(Recipe recipe) {
        RecipeDetailsDto dto = recipeMapper.toDetailsDto(recipe);
        if (dto != null && recipe.getImages() != null) {
            boolean hasImage = recipe.getImages().stream().anyMatch(RecipeImage::isPrimary);
            if (hasImage) {
                dto.setImageUrl("/api/recipes/" + recipe.getId() + "/image");
            }
        }
        return dto;
    }
}
