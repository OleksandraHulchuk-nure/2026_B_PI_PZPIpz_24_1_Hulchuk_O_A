package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.config.security.JwtService;
import com.nure.whatwecook.config.security.UserPrincipal;
import com.nure.whatwecook.domain.entity.profile.User;
import com.nure.whatwecook.domain.entity.profile.UserProfile;
import com.nure.whatwecook.dto.auth.AuthResponseDto;
import com.nure.whatwecook.dto.auth.LoginRequestDto;
import com.nure.whatwecook.dto.auth.RegisterRequestDto;
import com.nure.whatwecook.repository.UserProfileRepository;
import com.nure.whatwecook.repository.UserRepository;
import com.nure.whatwecook.service.AuthService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final UserProfileRepository userProfileRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;


    @Override
    @Transactional
    public AuthResponseDto register(RegisterRequestDto request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("User with this email already exists");
        }

        User user = new User();
        user.setEmail(request.getEmail());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));

        User saved = userRepository.save(user);

        UserProfile profile = new UserProfile();
        profile.setUser(saved);
        userProfileRepository.save(profile);

        UserPrincipal principal = new UserPrincipal(saved);
        String token = jwtService.generateToken(principal);

        AuthResponseDto response = new AuthResponseDto();
        response.setAccessToken(token);
        response.setTokenType("Bearer");
        return response;
    }

    @Override
    public AuthResponseDto login(LoginRequestDto request) {
        var authToken = new UsernamePasswordAuthenticationToken(
                request.getEmail(),
                request.getPassword()
        );
        authenticationManager.authenticate(authToken);

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new EntityNotFoundException("User not found"));

        UserPrincipal principal = new UserPrincipal(user);
        String token = jwtService.generateToken(principal);

        AuthResponseDto response = new AuthResponseDto();
        response.setAccessToken(token);
        response.setTokenType("Bearer");
        return response;
    }

    @Override
    public void logout() {
    }
}
