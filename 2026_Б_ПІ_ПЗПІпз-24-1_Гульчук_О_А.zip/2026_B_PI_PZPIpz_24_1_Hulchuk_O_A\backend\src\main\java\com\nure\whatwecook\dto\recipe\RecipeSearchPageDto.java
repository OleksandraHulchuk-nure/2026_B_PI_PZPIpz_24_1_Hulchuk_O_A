package com.nure.whatwecook.dto.recipe;

import java.util.List;

public record RecipeSearchPageDto (
    long totalCount,
    int page,
    int size,
    boolean hasNext,
    List<RecipeListItemDto> items
) {}
