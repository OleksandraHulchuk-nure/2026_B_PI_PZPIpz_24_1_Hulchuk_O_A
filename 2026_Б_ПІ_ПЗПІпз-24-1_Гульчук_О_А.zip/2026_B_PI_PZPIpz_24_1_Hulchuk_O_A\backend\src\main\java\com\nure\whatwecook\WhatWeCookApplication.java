package com.nure.whatwecook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhatWeCookApplication {

    public static void main(String[] args) {
        SpringApplication.run(WhatWeCookApplication.class, args);
    }

}
