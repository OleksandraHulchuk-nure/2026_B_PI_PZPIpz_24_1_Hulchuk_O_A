package com.nure.whatwecook.dto.recipe;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Sort;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecipeSortDto {

    @Schema(description = "Field to sort recipes by")
    private RecipeSortField field;

    @Schema(description = "Sort direction", example = "DESC")
    private Sort.Direction direction;

    @JsonIgnore
    public boolean isValid() {
        return field != null && direction != null;
    }
}
