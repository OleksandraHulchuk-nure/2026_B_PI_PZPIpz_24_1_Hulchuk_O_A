'use client';

import { type FormEvent, useEffect, useState } from 'react';

import {
    getMealTimePreferences,
    getUserProfile,
    type IngredientPreference,
    type MealTimePreference,
    type MealType,
    type MenuType,
    updateIngredientPreferences,
    updateMealTimePreferences,
    updateUserProfile,
} from '@/lib/api/profileApi';
import { MEAL_TYPES } from '@/lib/constants/enums';

import { PageSection } from '@/components/page-section';
import { Button } from '@/components/ui/button';
import { Alert } from '@/components/ui/alert';

import { ProfileBasicsSection } from '@/components/profile/ProfileBasicsSection';
import { MealTimePreferencesSection } from '@/components/profile/MealTimePreferencesSection';
import { IngredientPreferencesSection } from '@/components/profile/IngredientPreferencesSection';
import { CookingStyleSection } from '@/components/profile/CookingStyleSection';

const DEFAULT_MEAL_TIME_MINUTES = 30;

type InitialProfileSnapshot = {
    name: string;
    familySize: number | null;
    simplicity: number;
    menuType: MenuType;
    existingRecipeRatio: number;
    mealTimePrefs: MealTimePreference[];
};

function normalizeName(value: string) {
    return value.trim();
}

function normalizeFamilySize(value: number | '') {
    return value === '' ? null : value;
}

function normalizeMealTimePreferences(prefs: MealTimePreference[]) {
    return MEAL_TYPES.map((mealType) => {
        const preference = prefs.find((item) => item.mealType === mealType);

        return {
            mealType,
            maxCookingTimeMinutes: preference?.maxCookingTimeMinutes ?? DEFAULT_MEAL_TIME_MINUTES,
        };
    });
}

function normalizeIngredientPreferences(prefs: IngredientPreference[] | null | undefined) {
    return [...(prefs ?? [])]
        .map(({ kind, ingredientId }) => ({ kind, ingredientId }))
        .sort((left, right) => {
            const kindCompare = left.kind.localeCompare(right.kind);
            if (kindCompare !== 0) {
                return kindCompare;
            }

            return left.ingredientId.localeCompare(right.ingredientId);
        });
}

function serializeMealTimePreferences(prefs: MealTimePreference[]) {
    return JSON.stringify(normalizeMealTimePreferences(prefs));
}

function serializeIngredientPreferences(prefs: IngredientPreference[] | null | undefined) {
    return JSON.stringify(normalizeIngredientPreferences(prefs));
}

export function ProfilePageClient() {
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);

    const [name, setName] = useState('');
    const [familySize, setFamilySize] = useState<number | ''>('');

    const [simplicity, setSimplicity] = useState<number>(3);
    const [menuType, setMenuType] = useState<MenuType>('BALANCED');
    const [existingRecipeRatio, setExistingRecipeRatio] = useState<number>(70);

    const [mealTimePrefs, setMealTimePrefs] = useState<MealTimePreference[]>([]);
    const [ingredientPrefs, setIngredientPrefs] = useState<IngredientPreference[] | null>(null);
    const [initialProfileSnapshot, setInitialProfileSnapshot] = useState<InitialProfileSnapshot | null>(null);
    const [initialIngredientPrefs, setInitialIngredientPrefs] = useState<IngredientPreference[] | undefined>(undefined);
    const [ingredientSectionResetKey, setIngredientSectionResetKey] = useState(0);

    useEffect(() => {
        let cancelled = false;

        const load = async () => {
            try {
                setError(null);

                const [profile, mealTimes] = await Promise.all([
                    getUserProfile(),
                    getMealTimePreferences(),
                ]);

                if (cancelled) return;

                const nextName = profile.name ?? '';
                const nextFamilySize = profile.familySize ?? '';
                const nextSimplicity = profile.simplicity ?? 3;
                const nextMenuType = (profile.menuType as MenuType) ?? 'BALANCED';
                const nextExistingRecipeRatio = profile.existingRecipeRatio ?? 70;

                setName(nextName);
                setFamilySize(nextFamilySize);
                setSimplicity(nextSimplicity);
                setMenuType(nextMenuType);
                setExistingRecipeRatio(nextExistingRecipeRatio);
                setMealTimePrefs(mealTimes);

                setInitialProfileSnapshot({
                    name: normalizeName(nextName),
                    familySize: profile.familySize ?? null,
                    simplicity: nextSimplicity,
                    menuType: nextMenuType,
                    existingRecipeRatio: nextExistingRecipeRatio,
                    mealTimePrefs: normalizeMealTimePreferences(mealTimes),
                });
            } catch (e) {
                if (cancelled) return;
                setError(e instanceof Error ? e.message : 'Не вдалося завантажити налаштування профілю.');
            } finally {
                if (!cancelled) setLoading(false);
            }
        };

        void load();
        return () => {
            cancelled = true;
        };
    }, []);

    const handleMealTimeChange = (mealType: MealType, minutes: number) => {
        setMealTimePrefs((prev) => {
            const idx = prev.findIndex((p) => p.mealType === mealType);

            if (idx === -1) {
                return [...prev, { mealType, maxCookingTimeMinutes: minutes }];
            }

            const copy = [...prev];
            copy[idx] = { ...copy[idx], maxCookingTimeMinutes: minutes };
            return copy;
        });
    };

    const handleIngredientPreferencesChange = (prefs: IngredientPreference[]) => {
        setIngredientPrefs(prefs);
        setInitialIngredientPrefs((prev) => (prev === undefined ? prefs : prev));
    };

    const hasBasicChanges = initialProfileSnapshot !== null && (
        normalizeName(name) !== initialProfileSnapshot.name ||
        normalizeFamilySize(familySize) !== initialProfileSnapshot.familySize ||
        simplicity !== initialProfileSnapshot.simplicity ||
        menuType !== initialProfileSnapshot.menuType ||
        existingRecipeRatio !== initialProfileSnapshot.existingRecipeRatio
    );

    const hasMealTimeChanges = initialProfileSnapshot !== null &&
        serializeMealTimePreferences(mealTimePrefs) !== serializeMealTimePreferences(initialProfileSnapshot.mealTimePrefs);

    const hasIngredientChanges = initialIngredientPrefs !== undefined &&
        serializeIngredientPreferences(ingredientPrefs) !== serializeIngredientPreferences(initialIngredientPrefs);

    const hasChanges = hasBasicChanges || hasMealTimeChanges || hasIngredientChanges;

    useEffect(() => {
        if (hasChanges && success) {
            setSuccess(null);
        }
    }, [hasChanges, success]);

    const handleCancel = () => {
        if (!initialProfileSnapshot || !hasChanges) {
            return;
        }

        setError(null);
        setSuccess(null);
        setName(initialProfileSnapshot.name);
        setFamilySize(initialProfileSnapshot.familySize ?? '');
        setSimplicity(initialProfileSnapshot.simplicity);
        setMenuType(initialProfileSnapshot.menuType);
        setExistingRecipeRatio(initialProfileSnapshot.existingRecipeRatio);
        setMealTimePrefs(initialProfileSnapshot.mealTimePrefs);
        setIngredientPrefs(initialIngredientPrefs ?? null);
        setIngredientSectionResetKey((prev) => prev + 1);
    };

    const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        setError(null);
        setSuccess(null);

        if (!hasChanges) {
            return;
        }

        if (!name.trim()) {
            setError("Будь ласка, введіть назву сім'ї.");
            return;
        }

        const sizeNumber = typeof familySize === 'string' ? Number(familySize) : familySize;
        if (!sizeNumber || sizeNumber <= 0) {
            setError('Кількість людей у сім’ї має бути більшою за 0.');
            return;
        }

        setSaving(true);
        try {
            const [updatedProfile, updatedMealTimes, updatedIngredients] = await Promise.all([
                updateUserProfile({
                    name: name.trim(),
                    familySize: sizeNumber,
                    simplicity,
                    menuType,
                    existingRecipeRatio,
                }),
                updateMealTimePreferences(mealTimePrefs),
                ingredientPrefs ? updateIngredientPreferences(ingredientPrefs) : Promise.resolve(undefined),
            ]);

            const nextName = updatedProfile.name ?? '';
            const nextFamilySize = updatedProfile.familySize ?? '';
            const nextSimplicity = updatedProfile.simplicity ?? 3;
            const nextMenuType = (updatedProfile.menuType as MenuType) ?? 'BALANCED';
            const nextExistingRecipeRatio = updatedProfile.existingRecipeRatio ?? 70;

            setName(nextName);
            setFamilySize(nextFamilySize);
            setSimplicity(nextSimplicity);
            setMenuType(nextMenuType);
            setExistingRecipeRatio(nextExistingRecipeRatio);
            setMealTimePrefs(updatedMealTimes);

            if (updatedIngredients) {
                setIngredientPrefs(updatedIngredients);
                setInitialIngredientPrefs(updatedIngredients);
            }

            setInitialProfileSnapshot({
                name: normalizeName(nextName),
                familySize: updatedProfile.familySize ?? null,
                simplicity: nextSimplicity,
                menuType: nextMenuType,
                existingRecipeRatio: nextExistingRecipeRatio,
                mealTimePrefs: normalizeMealTimePreferences(updatedMealTimes),
            });

            setSuccess('Налаштування збережено.');
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Не вдалося зберегти зміни. Спробуйте ще раз.');
        } finally {
            setSaving(false);
        }
    };

    const formId = 'profile-form';

    return (
        <div className="space-y-6">
            <PageSection
                titleAs="h2"
                title="Профіль та вподобання"
                subtitle="Опишіть свою сім’ю та звички в їжі — застосунок підбиратиме меню саме під вас."
                actions={
                    <>
                        <Button type="submit" form={formId} disabled={saving || !hasChanges}>
                            {saving ? 'Збереження…' : 'Зберегти'}
                        </Button>
                        <Button type="button" variant="secondary" onClick={handleCancel} disabled={saving || !hasChanges}>
                            Скасувати
                        </Button>
                    </>
                }
            />

            {loading ? (
                <p className="section-subtitle">Завантажуємо ваші налаштування…</p>
            ) : (
                <>
                    {error && <Alert variant="error">{error}</Alert>}
                    {success && <Alert variant="success">{success}</Alert>}

                    <form id={formId} className="space-y-5" onSubmit={handleSubmit} noValidate>
                        <ProfileBasicsSection
                            name={name}
                            familySize={familySize}
                            menuType={menuType}
                            onNameChange={setName}
                            onFamilySizeChange={setFamilySize}
                            onMenuTypeChange={setMenuType}
                        />

                        <div className="grid gap-5 2xl:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]">
                            <CookingStyleSection
                                simplicity={simplicity}
                                existingRecipeRatio={existingRecipeRatio}
                                onSimplicityChange={setSimplicity}
                                onExistingRecipeRatioChange={setExistingRecipeRatio}
                            />

                            <MealTimePreferencesSection
                                mealTimePrefs={mealTimePrefs}
                                onMealTimeChange={handleMealTimeChange}
                            />
                        </div>

                        <IngredientPreferencesSection
                            key={ingredientSectionResetKey}
                            initialPreferences={initialIngredientPrefs}
                            onPreferencesChange={handleIngredientPreferencesChange}
                        />
                    </form>
                </>
            )}
        </div>
    );
}
