'use client';

import { useCallback, useState } from 'react';
import * as weeklyMenuApi from '@/lib/api/weeklyMenuApi';

export type UiStatus = 'idle' | 'loading' | 'error' | 'success';

export function useWeeklyMenusHistory() {
    const [history, setHistory] = useState<weeklyMenuApi.WeeklyMenuResponseDto[]>([]);
    const [status, setStatus] = useState<UiStatus>('idle');
    const [error, setError] = useState<string>('');

    const loadHistory = useCallback(async () => {
        setStatus('loading');
        setError('');
        try {
            const data = await weeklyMenuApi.getWeeklyMenus();
            setHistory(data);
            setStatus('success');
            return data;
        } catch (e) {
            setStatus('error');
            setError(e instanceof Error ? e.message : 'Не вдалося завантажити історію меню.');
            return null;
        }
    }, []);

    const findByStartDate = useCallback(
        (startDate: string) => history.find((m) => m.startDate === startDate) ?? null,
        [history],
    );

    return { history, status, error, loadHistory, findByStartDate };
}
