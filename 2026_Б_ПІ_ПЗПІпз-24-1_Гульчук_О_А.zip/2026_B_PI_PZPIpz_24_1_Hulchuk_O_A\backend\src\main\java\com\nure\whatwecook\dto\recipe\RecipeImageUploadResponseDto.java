package com.nure.whatwecook.dto.recipe;

import lombok.Data;

@Data
public class RecipeImageUploadResponseDto {
    private String imageUrl;
}
