import {ApiError, apiFetch} from '@/lib/api/apiClient';
import { API_ROUTES } from '@/lib/api/endpoints';
import type { MeasurementUnit, ProductCategory } from '@/lib/constants/enums';

export type { MeasurementUnit, ProductCategory } from '@/lib/constants/enums';

type IngredientShortDto = {
    id: string;
    nameUk: string;
    nameEn: string;
    category: ProductCategory;
    defaultUnit: MeasurementUnit;
};

export interface Ingredient {
    id: string;
    name: string;
    nameUk?: string;
    nameEn?: string;
    category?: ProductCategory;
    defaultUnit?: MeasurementUnit;
}

export interface AggregatedIngredientDto {
    id: string;
    ingredientNameUk?: string;
    nameUk: string;
    category: string;
    unit: MeasurementUnit;
    quantity: number;
}

/**
 * Пошук інгредієнтів для автодоповнення.
 * query → параметр `search` згідно Swagger.
 * category поки опційний, але можна буде використати потім у фільтрах.
 */
export async function searchIngredients(query: string, category?: string): Promise<Ingredient[]> {
    if (!query || query.trim().length < 2) return [];

    const params = new URLSearchParams();
    params.set('search', query.trim());
    if (category) params.set('category', category);

    const url = `${API_ROUTES.ingredients.root}?${params.toString()}`;
    const raw = await apiFetch<unknown>(url);

    if (!Array.isArray(raw)) return [];

    const items = raw as IngredientShortDto[];
    return items.map((i) => ({
        id: i.id,
        name: i.nameUk || i.nameEn,
        nameUk: i.nameUk,
        nameEn: i.nameEn,
        category: i.category,
        defaultUnit: i.defaultUnit,
    }));
}

type IngredientDetailsDto = {
    id: string;
    nameUk: string;
    nameEn: string;
    category: ProductCategory;
    defaultUnit: MeasurementUnit;
};

export async function getIngredientById(id: string): Promise<Ingredient> {
    const dto = await apiFetch<IngredientDetailsDto>(`${API_ROUTES.ingredients.root}/${id}`);
    return {
        id: dto.id,
        name: dto.nameUk || dto.nameEn,
        nameUk: dto.nameUk,
        nameEn: dto.nameEn,
        category: dto.category,
        defaultUnit: dto.defaultUnit,
    };
}

export async function getAggregatedIngredientsByDate(date: string): Promise<AggregatedIngredientDto[]> {
    try {
        return await apiFetch<AggregatedIngredientDto[]>(`${API_ROUTES.ingredients.aggregated}/${date}`);
    } catch (e) {
        if (e instanceof ApiError && e.status === 404) {
            return [];
        }
        throw e;
    }
}
