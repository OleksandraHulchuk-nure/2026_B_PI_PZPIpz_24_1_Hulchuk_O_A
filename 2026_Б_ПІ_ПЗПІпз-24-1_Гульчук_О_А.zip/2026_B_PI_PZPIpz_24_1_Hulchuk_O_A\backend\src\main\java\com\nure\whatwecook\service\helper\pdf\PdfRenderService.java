package com.nure.whatwecook.service.helper.pdf;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class PdfRenderService {

    private final PdfTemplatePipeline pipeline;

    public byte[] render(String templateName, Map<String, Object> model) {
        return pipeline.render(PdfRenderRequest.of(templateName, model));
    }
}
