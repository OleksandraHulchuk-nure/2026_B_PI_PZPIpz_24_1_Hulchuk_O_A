import * as React from 'react';
import { cn } from '@/lib/utils';

export type CardVariant = 'default' | 'muted' | 'ai' | 'warm';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
    variant?: CardVariant;
}

const baseClasses = 'rounded-2xl p-5 shadow-sm';

const variantClasses: Record<CardVariant, string> = {
    default: 'border border-border bg-surface',
    muted: 'border border-border bg-background',
    ai: 'border border-accent-ai/25 bg-accent-soft-ai',
    warm: 'border border-accent-warm/25 bg-accent-soft-warm',
};

export const Card = React.forwardRef<HTMLDivElement, CardProps>(
    ({ className, variant = 'default', ...props }, ref) => {
        return (
            <div
                ref={ref}
                className={cn(baseClasses, variantClasses[variant], className)}
                {...props}
            />
        );
    },
);

Card.displayName = 'Card';

type CardSectionProps = React.HTMLAttributes<HTMLDivElement>;

export const CardHeader = React.forwardRef<HTMLDivElement, CardSectionProps>(
    ({ className, ...props }, ref) => {
        return (
            <div
                ref={ref}
                className={cn('px-5 py-3 border-b border-border/60', className)}
                {...props}
            />
        );
    },
);
CardHeader.displayName = 'CardHeader';

export const CardContent = React.forwardRef<HTMLDivElement, CardSectionProps>(
    ({ className, ...props }, ref) => {
        return <div ref={ref} className={cn('px-5 py-4', className)} {...props} />;
    },
);
CardContent.displayName = 'CardContent';

export const CardFooter = React.forwardRef<HTMLDivElement, CardSectionProps>(
    ({ className, ...props }, ref) => {
        return (
            <div
                ref={ref}
                className={cn('px-5 py-3 border-t border-border/60', className)}
                {...props}
            />
        );
    },
);
CardFooter.displayName = 'CardFooter';
