package com.nure.whatwecook.dto.ai;

import com.nure.whatwecook.domain.enums.MeasurementUnit;
import com.nure.whatwecook.domain.enums.ProductCategory;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
public class AiRecipeDraftIngredientDto {

    private UUID ingredientId;

    @NotBlank
    private String ingredientNameUk;

    private String ingredientNameEn;

    private ProductCategory category;

    private MeasurementUnit defaultUnit;

    @NotNull
    @DecimalMin(value = "0.01")
    private BigDecimal quantity;

    private MeasurementUnit unit;

    private boolean optional;
}
