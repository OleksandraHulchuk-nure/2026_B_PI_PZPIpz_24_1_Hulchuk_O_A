﻿'use client';

import {useEffect} from 'react';
import {useParams, useRouter} from 'next/navigation';

import {getShoppingList} from '@/lib/api/shoppingListApi';
import {toMondayIso} from '@/lib/utils/date';

export default function ShoppingListByIdPage() {
    const params = useParams<{ id: string }>();
    const router = useRouter();
    const id = typeof params?.id === 'string' ? params.id : '';

    useEffect(() => {
        if (!id) {
            router.replace('/shopping-list');
            return;
        }

        let active = true;

        getShoppingList(id)
            .then((list) => {
                if (!active) return;
                const target = list.weekStart
                    ? `/shopping-list?weekStart=${encodeURIComponent(toMondayIso(list.weekStart))}`
                    : '/shopping-list';
                router.replace(target);
            })
            .catch(() => {
                if (!active) return;
                router.replace('/shopping-list');
            });

        return () => {
            active = false;
        };
    }, [id, router]);

    return <div className="text-sm text-text-muted">Перенаправлення…</div>;
}
