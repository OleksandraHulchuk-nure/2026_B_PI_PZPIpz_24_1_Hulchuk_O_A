'use client';

import Link from 'next/link';
import * as React from 'react';
import {usePathname, useRouter, useSearchParams} from 'next/navigation';

import {PageSection} from '@/components/page-section';
import {Alert} from '@/components/ui/alert';
import {Badge} from '@/components/ui/badge';
import {Button} from '@/components/ui/button';
import {Card} from '@/components/ui/card';
import {Select} from '@/components/ui/select';
import {Textarea} from '@/components/ui/textarea';

import {RecipeIngredientsStepsViewCard} from '@/components/recipes/details/RecipeIngredientsStepsViewCard';
import Modal from '@/components/ui/modal';
import StarRating from '@/components/ui/star-rating';

import {ApiError} from '@/lib/api/apiClient';
import {getIngredientById} from '@/lib/api/ingredientApi';
import {
    getRecipe,
    getRecipeImageBlob,
    type RecipeDetailsDto,
    type RecipeStatus,
    updateRecipeRating,
    updateRecipeStatus,
} from '@/lib/api/recipeApi';
import {
    RECIPE_STATUS_LABELS,
    RECIPE_STATUS_OPTIONS,
    recipeSourceBadgeVariant,
    recipeStatusBadgeVariant,
} from '@/lib/constants/enums';
import {formatMealType, formatMenuType, formatRecipeSource} from '@/lib/formatters/recipeFormatters';

function toAlertMessage(error: unknown) {
    if (error instanceof ApiError) {
        return {message: error.message, status: error.status};
    }

    return {message: 'Сталася помилка. Спробуйте ще раз.'};
}

function SummaryField({
    label,
    value,
}: {
    label: string;
    value: React.ReactNode;
}) {
    return (
        <div className="space-y-1">
            <div className="text-[11px] uppercase tracking-[0.08em] text-text-muted">{label}</div>
            <div className="text-sm text-text-primary">{value}</div>
        </div>
    );
}

function RatingRow({
    label,
    value,
}: {
    label: string;
    value?: number;
}) {
    const formattedValue = typeof value === 'number' ? `${value}/5` : '—';

    return (
        <div className="grid grid-cols-[88px_minmax(0,1fr)_40px] items-center gap-2">
            <span className="w-[88px] text-sm text-text-muted">{label}</span>
            <div className="min-w-0">
                <StarRating value={value ?? 0} disabled size="sm"/>
            </div>
            <div className="w-10 text-right text-xs font-semibold text-text-primary tabular-nums">
                {formattedValue}
            </div>
        </div>
    );
}

function formatTimeSummary(recipe: RecipeDetailsDto) {
    if (recipe.activeCookingTimeMinutes == null && recipe.totalTimeMinutes == null) {
        return '—';
    }

    const active = recipe.activeCookingTimeMinutes ?? '—';
    const total = recipe.totalTimeMinutes ?? '—';

    return `${active} / ${total} хв`;
}

export function RecipeDetailsPageClient({recipeId}: {recipeId: string}) {
    const router = useRouter();
    const pathname = usePathname();
    const searchParams = useSearchParams();
    const successHandledRef = React.useRef(false);

    const [recipe, setRecipe] = React.useState<RecipeDetailsDto | null>(null);
    const [loading, setLoading] = React.useState(true);
    const [saving, setSaving] = React.useState(false);
    const [error, setError] = React.useState<{message: string; status?: number} | null>(null);
    const [notice, setNotice] = React.useState<string | null>(null);

    const [ingredientNames, setIngredientNames] = React.useState<Record<string, string>>({});
    const [imageUrl, setImageUrl] = React.useState<string | null>(null);

    const [isReviewModalOpen, setIsReviewModalOpen] = React.useState(false);
    const [statusDraft, setStatusDraft] = React.useState<RecipeStatus>('TO_VERIFY');
    const [tasteDraft, setTasteDraft] = React.useState(3);
    const [ratingComment, setRatingComment] = React.useState('');

    const successNotices = React.useMemo(
        () => new Set(['Зміни збережено.', 'Оцінку і статус оновлено.']),
        [],
    );

    React.useEffect(() => {
        if (!imageUrl) return undefined;

        return () => {
            URL.revokeObjectURL(imageUrl);
        };
    }, [imageUrl]);

    const fetchAll = React.useCallback(async () => {
        setLoading(true);
        setError(null);

        try {
            const data = await getRecipe(recipeId);
            setRecipe(data);
            setStatusDraft(data.status);
            setTasteDraft(data.tasteRating ?? 3);
            setRatingComment(data.ratingComment ?? '');

            const ingredientIds = Array.from(new Set((data.ingredients ?? []).map((ingredient) => ingredient.ingredientId)));
            let nextIngredientNames: Record<string, string> = {};

            if (ingredientIds.length) {
                const pairs = await Promise.all(
                    ingredientIds.map(async (id) => {
                        try {
                            const ingredient = await getIngredientById(id);
                            return [id, ingredient.name] as const;
                        } catch {
                            return [id, id.slice(0, 8)] as const;
                        }
                    }),
                );

                nextIngredientNames = Object.fromEntries(pairs);
            }

            setIngredientNames(nextIngredientNames);

            try {
                const blob = await getRecipeImageBlob(recipeId);
                if (blob) {
                    setImageUrl(URL.createObjectURL(blob));
                } else {
                    setImageUrl(null);
                }
            } catch {
                setImageUrl(null);
            }
        } catch (nextError) {
            setError(toAlertMessage(nextError));
        } finally {
            setLoading(false);
        }
    }, [recipeId]);

    React.useEffect(() => {
        void fetchAll();
    }, [fetchAll]);

    React.useEffect(() => {
        if (successHandledRef.current || searchParams.get('updated') !== '1') {
            return;
        }

        successHandledRef.current = true;
        setNotice('Зміни збережено.');
        router.replace(pathname);
    }, [pathname, router, searchParams]);

    const openReviewModal = () => {
        if (!recipe) return;

        setStatusDraft(recipe.status);
        setTasteDraft(recipe.tasteRating ?? 3);
        setRatingComment(recipe.ratingComment ?? '');
        setIsReviewModalOpen(true);
    };

    const saveReview = async () => {
        if (!recipe) return false;

        const nextComment = ratingComment.trim();
        const previousComment = recipe.ratingComment?.trim() ?? '';
        const statusChanged = statusDraft !== recipe.status;
        const reviewChanged = tasteDraft !== (recipe.tasteRating ?? 3) || nextComment !== previousComment;

        if (!statusChanged && !reviewChanged) {
            return true;
        }

        setSaving(true);
        setNotice(null);

        let persistedSomething = false;

        try {
            if (statusChanged) {
                await updateRecipeStatus(recipeId, statusDraft);
                persistedSomething = true;
            }

            if (reviewChanged) {
                await updateRecipeRating(recipeId, {
                    tasteRating: tasteDraft,
                    ratingComment: nextComment || undefined,
                });
                persistedSomething = true;
            }

            await fetchAll();
            setNotice('Оцінку і статус оновлено.');
            return true;
        } catch (nextError) {
            if (persistedSomething) {
                await fetchAll();
                setNotice('Частину змін збережено, але сталася помилка під час оновлення.');
            } else {
                const nextMessage = toAlertMessage(nextError);
                setNotice(nextMessage.message);
            }

            return false;
        } finally {
            setSaving(false);
        }
    };

    const actions = (
        <>
            <Link href="/recipes">
                <Button variant="ghost" disabled={saving}>
                    Назад
                </Button>
            </Link>
            {recipe ? (
                <Link href={`/recipes/${recipeId}/edit`}>
                    <Button disabled={saving}>
                        Редагувати
                    </Button>
                </Link>
            ) : null}
        </>
    );

    return (
        <div className="flex flex-col gap-6">
            <PageSection
                titleAs="h2"
                title={recipe ? recipe.name : 'Рецепт'}
                subtitle="Перегляньте рецепт і окремо оновіть статус та оцінку після приготування."
                titleAddon={
                    recipe ? (
                        <Badge variant={recipeSourceBadgeVariant(recipe.sourceType)}>
                            {formatRecipeSource(recipe.sourceType)}
                        </Badge>
                    ) : null
                }
                actions={actions}
            />

            {loading ? <Card className="text-sm text-text-muted">Завантаження рецепта…</Card> : null}

            {!loading && error ? (
                <Alert variant="error" title="Не вдалося завантажити рецепт">
                    <div className="flex flex-col gap-2">
                        <span>
                            {error.message}
                            {typeof error.status === 'number' ? ` (HTTP ${error.status})` : null}
                        </span>
                        <div>
                            <Button variant="secondary" onClick={() => void fetchAll()}>
                                Спробувати ще раз
                            </Button>
                        </div>
                    </div>
                </Alert>
            ) : null}

            {!loading && !error && recipe ? (
                <>
                    {notice ? (
                        <Alert variant={successNotices.has(notice) ? 'success' : 'info'}>{notice}</Alert>
                    ) : null}

                    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
                        <Card className="p-4">
                            <div className="grid gap-6 md:grid-cols-[320px_minmax(0,1fr)]">
                                <div>
                                    <div className="aspect-[4/3] overflow-hidden rounded-2xl border border-border bg-background">
                                        {imageUrl ? (
                                            // eslint-disable-next-line @next/next/no-img-element
                                            <img src={imageUrl} alt="Фото страви" className="h-full w-full object-cover"/>
                                        ) : (
                                            <div className="flex h-full w-full items-center justify-center text-xs text-text-muted">
                                                Немає фото
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div className="space-y-5">
                                    <div className="grid gap-4 sm:grid-cols-2">
                                        <SummaryField label="Прийом їжі" value={formatMealType(recipe.mealType)}/>
                                        <SummaryField label="Тип меню" value={formatMenuType(recipe.menuType)}/>
                                        <SummaryField label="Активний / загальний час" value={formatTimeSummary(recipe)}/>
                                    </div>

                                    <div className="space-y-1">
                                        <div className="text-[11px] uppercase tracking-[0.08em] text-text-muted">Опис</div>
                                        <div className="whitespace-pre-line text-sm text-text-primary">
                                            {recipe.description?.trim() ? recipe.description : '—'}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Card>

                        <Card variant="muted" className="p-3 lg:self-start">
                            <div className="space-y-2.5">
                                <div className="text-[11px] uppercase tracking-[0.08em] text-text-muted">
                                    Оцінка і статус
                                </div>

                                <div className="flex items-center justify-between gap-3">
                                    <span className="text-sm text-text-muted">Статус</span>
                                    <Badge variant={recipeStatusBadgeVariant(recipe.status)}>
                                        {RECIPE_STATUS_LABELS[recipe.status]}
                                    </Badge>
                                </div>

                                <RatingRow label="Складність" value={recipe.complexityRating}/>
                                <RatingRow label="Смак" value={recipe.tasteRating}/>

                                <div className="space-y-1">
                                    <div className="text-xs text-text-muted">Коментар</div>
                                    <div
                                        className="h-16 overflow-y-auto rounded-xl border border-border bg-background px-3 py-2 text-sm text-text-primary"
                                        style={{
                                            overflowWrap: 'anywhere',
                                            wordBreak: 'break-word',
                                            whiteSpace: 'pre-wrap',
                                        }}
                                    >
                                        {recipe.ratingComment?.trim() ? recipe.ratingComment : 'Коментар відсутній.'}
                                    </div>
                                </div>

                                <Button
                                    variant="secondary"
                                    className="w-full justify-center"
                                    onClick={openReviewModal}
                                    disabled={saving}
                                >
                                    Оновити оцінку і статус
                                </Button>
                            </div>
                        </Card>
                    </div>

                    <RecipeIngredientsStepsViewCard recipe={recipe} ingredientNames={ingredientNames}/>

                    <Modal
                        open={isReviewModalOpen}
                        title="Оновити оцінку і статус"
                        onClose={() => (saving ? null : setIsReviewModalOpen(false))}
                        actions={
                            <>
                                <Button
                                    variant="secondary"
                                    disabled={saving}
                                    onClick={() => setIsReviewModalOpen(false)}
                                >
                                    Скасувати
                                </Button>
                                <Button
                                    disabled={saving}
                                    onClick={async () => {
                                        const ok = await saveReview();
                                        if (ok) {
                                            setIsReviewModalOpen(false);
                                        }
                                    }}
                                >
                                    {saving ? 'Збереження…' : 'Зберегти'}
                                </Button>
                            </>
                        }
                    >
                        <div className="space-y-4">
                            <div className="space-y-1">
                                <label>Статус</label>
                                <Select
                                    value={statusDraft}
                                    onChange={(event) => setStatusDraft(event.target.value as RecipeStatus)}
                                    disabled={saving}
                                >
                                    {RECIPE_STATUS_OPTIONS.map((option) => (
                                        <option key={option.value} value={option.value}>
                                            {option.label}
                                        </option>
                                    ))}
                                </Select>
                            </div>

                            <div className="rounded-xl border border-border bg-background px-3 py-3">
                                <div className="flex items-center justify-between gap-3">
                                    <div className="text-xs text-text-muted">Смак</div>
                                    <div className="flex items-center gap-2">
                                        <StarRating value={tasteDraft} onChange={setTasteDraft} disabled={saving}/>
                                        <div className="w-10 text-right text-sm font-semibold">{tasteDraft}/5</div>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-1">
                                <label>Коментар (опційно)</label>
                                <Textarea
                                    rows={3}
                                    value={ratingComment}
                                    onChange={(event) => setRatingComment(event.target.value)}
                                    disabled={saving}
                                />
                            </div>
                        </div>
                    </Modal>
                </>
            ) : null}
        </div>
    );
}
