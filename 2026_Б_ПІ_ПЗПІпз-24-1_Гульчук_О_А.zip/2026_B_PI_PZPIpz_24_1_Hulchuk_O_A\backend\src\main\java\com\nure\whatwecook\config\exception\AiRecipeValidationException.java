package com.nure.whatwecook.config.exception;

import lombok.Getter;

import java.util.Map;

@Getter
public class AiRecipeValidationException extends RuntimeException {

    private final Map<String, String> validationErrors;

    public AiRecipeValidationException(String message, Map<String, String> validationErrors) {
        super(message);
        this.validationErrors = validationErrors;
    }
}
