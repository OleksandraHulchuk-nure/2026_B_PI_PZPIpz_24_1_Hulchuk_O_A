package com.nure.whatwecook.dto.shopping;

import lombok.Data;

import java.util.UUID;

@Data
public class ShoppingListFromWeeklyMenuRequestDto {

    private UUID weeklyMenuId;
}
