import { UNIT_OPTIONS, type MeasurementUnit } from '@/lib/api/recipeApi';

const unitLabelMap = new Map<string, string>(UNIT_OPTIONS.map((x) => [x.value, x.label]));

export function getUnitLabel(u?: MeasurementUnit | string | null): string {
    if (!u) return '';
    return unitLabelMap.get(u) ?? String(u);
}
