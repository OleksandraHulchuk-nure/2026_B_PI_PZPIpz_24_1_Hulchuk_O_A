import { RecipesPageClient } from '@/components/recipes/RecipesPageClient';

export default function RecipesPage() {
    return <RecipesPageClient />;
}
