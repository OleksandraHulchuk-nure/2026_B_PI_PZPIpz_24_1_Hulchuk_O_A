'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';

type RangeTone = 'primary' | 'ai';

export interface RangeProps
    extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
    tone?: RangeTone;
}

export function Range({ className, tone = 'primary', style, ...props }: RangeProps) {
    const rangeColor = tone === 'ai' ? 'var(--color-accent-ai)' : 'var(--color-primary)';
    const rangeFocus = tone === 'ai' ? 'var(--color-accent-soft-ai)' : 'var(--color-primary-soft)';
    const min = Number(props.min ?? 0);
    const max = Number(props.max ?? 100);
    const value = Number(props.value ?? min);
    const progress =
        Number.isFinite(min) && Number.isFinite(max) && max > min
            ? `${Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100))}%`
            : '0%';

    return (
        <input
            type="range"
            className={cn('range-input w-full cursor-pointer', className)}
            style={
                {
                    '--range-color': rangeColor,
                    '--range-focus': rangeFocus,
                    '--range-progress': progress,
                    ...style,
                } as React.CSSProperties
            }
            {...props}
        />
    );
}
