package com.nure.whatwecook.domain.entity.menu;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(
        name = "menu_day",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_menu_day_menu_date",
                        columnNames = {"weekly_menu_id", "date"}
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MenuDay {

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "weekly_menu_id", nullable = false)
    private WeeklyMenu weeklyMenu;

    @Column(name = "date", nullable = false)
    private LocalDate date;

    @OneToMany(mappedBy = "menuDay", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<MenuMeal> meals = new ArrayList<>();

    @PrePersist
    public void prePersist() {
        if (id == null) {
            id = UUID.randomUUID();
        }
    }
}
