package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.recipe.RecipeIngredient;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface RecipeIngredientRepository extends JpaRepository<RecipeIngredient, UUID> {

    List<RecipeIngredient> findByRecipeId(UUID recipeId);

    void deleteByRecipeId(UUID recipeId);
}
