package com.nure.whatwecook.mapper;

import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.dto.recipe.*;
import org.mapstruct.*;

import java.util.List;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        uses = {RecipeIngredientMapper.class}
)
public interface RecipeMapper {

    RecipeListItemDto toListItemDto(Recipe recipe);

    List<RecipeListItemDto> toListItemDtoList(List<Recipe> recipes);

    RecipeDetailsDto toDetailsDto(Recipe recipe);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "user", ignore = true)
    @Mapping(target = "sourceType", ignore = true)
    @Mapping(target = "status", ignore = true)
    @Mapping(target = "ingredients", ignore = true)
    @Mapping(target = "images", ignore = true)
    Recipe fromCreateDto(RecipeCreateRequestDto dto);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "user", ignore = true)
    @Mapping(target = "sourceType", ignore = true)
    @Mapping(target = "status", ignore = true)
    @Mapping(target = "ingredients", ignore = true)
    @Mapping(target = "images", ignore = true)
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    void updateEntityFromDto(RecipeUpdateRequestDto dto, @MappingTarget Recipe recipe);
}
