import { apiFetch, buildQuery } from '@/lib/api/apiClient';
import { API_ROUTES } from '@/lib/api/endpoints';

/**
 * Backend інколи повертає числа як:
 * - number
 * - { source: "1.0000", parsedValue: 1 }
 * - null
 */
export type DecimalDto = { source: string; parsedValue: number };
export type DecimalLike = number | DecimalDto | null | undefined;

export type StatPeriodMenuMetricsDto = {
    from: string;
    to: string;

    streakWeeksMax: number;

    avgCookingTimePerDayMinutes?: number;
    timeAdherence?: { constraintsCnt?: number; withinCnt?: number; pct?: number };

    avgComplexity?: number;
    complexityAdherence?: { constraintsCnt?: number; withinCnt?: number; pct?: number };

    approvalSpeedMinutesAvg?: number;
};

export type AiPeriodStatsDto = {
    allMeals: number;
    aiMeals: number;

    aiSharePct: DecimalLike;

    verifiedCnt: number;
    rejectedCnt: number;

    successPct: DecimalLike;

    ratedCnt: number;
    ratedPct: DecimalLike;

    avgTaste: DecimalLike;
};

export type AiDailyStatsDto = {
    date: string; // YYYY-MM-DD
    totalAi: number;

    verifiedCnt: number;
    rejectedCnt: number;
    ratedCnt: number;

    avgTaste: DecimalLike;

    successPct: DecimalLike;
    verifiedPct: DecimalLike;
    ratedPct: DecimalLike;
};

export type StatPeriodAiMetricsDto = {
    from: string;
    to: string;
    ai: AiPeriodStatsDto;
};


export type TopCategoryItemDto = {
    category: string; // ProductCategory enum value
    itemsCnt: number;
};

export type ShoppingListCategoryTotalsStatDto = {
    category: string;
    itemsCnt: number;
    fullyCoveredItemsCnt?: number;
};

export type StatPeriodTopCategoriesDto = {
    from: string;
    to: string;
    limit: number;
    includeOptional: boolean;
    items: TopCategoryItemDto[];
};


export type TopIngredientItemDto = {
    ingredientId: string;
    ingredientNameUk: string;
    unit: string;
    totalQuantity: number;
};

export type StatPeriodTopIngredientsDto = {
    from: string;
    to: string;
    limit: number;
    includeOptional: boolean;
    items: TopIngredientItemDto[];
};

export type StatsPeriodQuery = {
    from: string;
    to: string;
    limit?: number;
    includeOptional?: boolean;
};

export async function getMenuMetrics(params: { from: string; to: string }) {
    return apiFetch<StatPeriodMenuMetricsDto>(
        `${API_ROUTES.stats.menuMetrics}${buildQuery(params)}`,
        { method: 'GET' },
    );
}

export async function getAiMetrics(params: { from: string; to: string }) {
    return apiFetch<StatPeriodAiMetricsDto>(
        `${API_ROUTES.stats.aiMetrics}${buildQuery(params)}`,
        { method: 'GET' },
    );
}

export async function getTopCategories(params: StatsPeriodQuery) {
    const { from, to, limit = 8, includeOptional = false } = params;

    return apiFetch<StatPeriodTopCategoriesDto>(
        `${API_ROUTES.stats.topCategories}${buildQuery({ from, to, limit, includeOptional })}`,
        { method: 'GET' },
    );
}

export async function getTopIngredients(params: StatsPeriodQuery) {
    const { from, to, limit = 8, includeOptional = false } = params;

    return apiFetch<StatPeriodTopIngredientsDto>(
        `${API_ROUTES.stats.topIngredients}${buildQuery({ from, to, limit, includeOptional })}`,
        { method: 'GET' },
    );
}
