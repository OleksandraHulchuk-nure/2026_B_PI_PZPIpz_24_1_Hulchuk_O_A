package com.nure.whatwecook.dto.recipe;

import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.RecipeSourceType;
import com.nure.whatwecook.domain.enums.RecipeStatus;
import com.nure.whatwecook.dto.PaginationDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecipeSearchRequestDto {

    @Schema(description = "Search query by recipe name", example = "Pasta")
    private String search;

    @Schema(description = "Recipe status filter")
    private RecipeStatus status;

    @Schema(description = "Recipe source filter")
    private RecipeSourceType sourceType;

    @Schema(description = "Recipe meal type filter")
    private MealType mealType;

    @Schema(description = "Maximum total cooking time in minutes", example = "30")
    private Integer maxTotalTimeMinutes;

    @Schema(description = "Pagination parameters")
    private PaginationDto pagination;

    @Schema(description = "Sorting parameters")
    private RecipeSortDto sort;
}
