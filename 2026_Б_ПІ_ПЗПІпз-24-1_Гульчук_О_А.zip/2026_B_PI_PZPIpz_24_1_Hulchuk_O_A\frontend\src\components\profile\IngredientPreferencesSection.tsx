'use client';

import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Alert } from '@/components/ui/alert';
import { Chip } from '@/components/ui/chip';

import { type Ingredient } from '@/lib/api/ingredientApi';

import { KIND_META, KINDS } from './ingredientPreferences.constants';
import { useIngredientPreferences } from './hooks/useIngredientPreferences';
import { useIngredientSearch } from './hooks/useIngredientSearch';
import type {
    IngredientPreferenceCardProps,
    IngredientPreferencesSectionProps,
} from './profile.types';

export function IngredientPreferencesSection({
    onPreferencesChange,
    initialPreferences,
}: IngredientPreferencesSectionProps) {
    const { state, loading, error, handleRemove, handleAdd } = useIngredientPreferences({
        onPreferencesChange,
        initialPreferences,
    });

    return (
        <section className="space-y-4">
            <div>
                <h2 className="section-title">Інгредієнти та вподобання</h2>
                <p className="section-subtitle">
                    Допомагає генератору меню підбирати страви під ваші улюблені продукти та уникати небажаних.
                </p>
            </div>

            {loading && <p>Завантаження вподобань...</p>}

            {error && !loading && (
                <Alert variant="error">{error}</Alert>
            )}

            {!loading && (
                <div className="grid gap-4 md:grid-cols-2">
                    {KINDS.map((kind) => (
                        <IngredientPreferenceCard
                            key={kind}
                            kind={kind}
                            title={KIND_META[kind].title}
                            description={KIND_META[kind].description}
                            items={state[kind]}
                            onRemove={handleRemove}
                            onAdd={(preferenceKind, ingredient) =>
                                handleAdd(preferenceKind, {
                                    ingredientId: ingredient.id,
                                    ingredientName: ingredient.name,
                                    kind: preferenceKind,
                                })
                            }
                        />
                    ))}
                </div>
            )}
        </section>
    );
}

function IngredientPreferenceCard({
    kind,
    title,
    description,
    items,
    onRemove,
    onAdd,
}: IngredientPreferenceCardProps) {
    const {
        query,
        suggestions,
        searching,
        handleQueryChange,
        handleSelectSuggestion,
    } = useIngredientSearch((ingredient: Ingredient) => {
        onAdd(kind, ingredient);
    });

    return (
        <Card className="flex flex-col gap-3">
            <div>
                <h3 className="mb-1 text-sm font-semibold">{title}</h3>
                <p className="text-xs text-text-muted">{description}</p>
            </div>

            <div className="relative">
                <Input
                    placeholder="Почніть вводити назву інгредієнта..."
                    value={query}
                    onChange={handleQueryChange}
                />
                {searching && (
                    <p className="mt-1 text-xs text-text-muted">Пошук...</p>
                )}
                {suggestions.length > 0 && (
                    <ul className="absolute z-10 mt-1 max-h-40 w-full overflow-y-auto rounded-lg border border-border bg-surface text-sm shadow-lg">
                        {suggestions.map((ingredient) => (
                            <li
                                key={ingredient.id}
                                className="cursor-pointer px-3 py-1.5 hover:bg-primary-soft"
                                onClick={() => handleSelectSuggestion(ingredient)}
                            >
                                {ingredient.name}
                            </li>
                        ))}
                    </ul>
                )}
            </div>

            {items.length === 0 ? (
                <p className="text-xs text-text-muted">
                    Ще немає інгредієнтів у цьому списку.
                </p>
            ) : (
                <div className="flex flex-wrap gap-2">
                    {items.map((item) => (
                        <Chip
                            key={item.ingredientId}
                            onRemove={() => onRemove(kind, item.ingredientId)}
                        >
                            {item.ingredientName}
                        </Chip>
                    ))}
                </div>
            )}
        </Card>
    );
}
