package com.nure.whatwecook.dto.auth;

import lombok.Data;

@Data
public class RegisterRequestDto {

    private String email;
    private String password;
}
