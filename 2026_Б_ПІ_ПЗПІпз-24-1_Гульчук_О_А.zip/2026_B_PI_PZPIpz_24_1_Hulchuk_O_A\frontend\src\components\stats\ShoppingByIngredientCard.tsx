'use client';

import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { BarList, type BarListItem } from '@/components/stats/BarList';
import type { StatPeriodTopIngredientsDto } from '@/lib/api/statsApi';
import { MEASUREMENT_UNIT_LABELS, type MeasurementUnit } from '@/lib/constants/enums';

function isMeasurementUnit(x: unknown): x is MeasurementUnit {
    return typeof x === 'string' && x in MEASUREMENT_UNIT_LABELS;
}

function formatQty(n: number) {
    const v = Math.round(n * 10) / 10;
    return new Intl.NumberFormat('uk-UA', {
        maximumFractionDigits: Number.isInteger(v) ? 0 : 1,
    }).format(v);
}

export function ShoppingByIngredientCard({ data }: { data?: StatPeriodTopIngredientsDto }) {
    const items = useMemo<BarListItem[]>(() => {
        const rows = data?.items ?? [];

        return rows
            .map((r, idx) => {
                const label = (r.ingredientNameUk ?? '—').trim();

                const valueRaw = r.totalQuantity;
                const value = typeof valueRaw === 'number' && Number.isFinite(valueRaw) && valueRaw > 0 ? valueRaw : 0;

                const unit = isMeasurementUnit(r.unit) ? MEASUREMENT_UNIT_LABELS[r.unit] : (r.unit ? String(r.unit) : 'од.');
                const sub = `${formatQty(value)} ${unit}`;

                const key = `${r.ingredientId ?? 'row'}-${idx}`;

                return { key, label, value, sub };
            })
            .filter((x) => x.label !== '—' && x.value > 0)
            .sort((a, b) => b.value - a.value);
    }, [data]);

    return (
        <Card className="p-0">
            <CardHeader className="flex items-center justify-between">
                <div>
                    <div className="text-sm font-bold">Топ інгредієнтів</div>
                    <div className="text-xs text-text-muted">меню в обраному періоді</div>
                </div>
                <span className="material-symbols-outlined text-[18px] leading-none text-text-muted">shopping_cart</span>
            </CardHeader>

            <CardContent>
                {items.length === 0 ? <div className="text-xs text-text-muted">Немає даних</div> : <BarList items={items} />}
            </CardContent>
        </Card>
    );
}
