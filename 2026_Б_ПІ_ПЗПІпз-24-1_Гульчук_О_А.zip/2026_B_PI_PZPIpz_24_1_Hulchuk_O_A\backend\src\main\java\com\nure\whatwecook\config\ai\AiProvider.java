package com.nure.whatwecook.config.ai;

public enum AiProvider {
    OPENAI,
    GEMINI,
    OLLAMA
}
