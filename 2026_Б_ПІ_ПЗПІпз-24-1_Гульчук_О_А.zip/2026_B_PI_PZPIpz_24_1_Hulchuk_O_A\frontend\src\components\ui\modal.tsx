import React from "react";
import {Button} from "@/components/ui/button";
import {Card} from "@/components/ui/card";

export default function Modal({
                   open,
                   title,
                   onClose,
                   children,
                   actions,
               }: {
    open: boolean;
    title: string;
    onClose: () => void;
    children: React.ReactNode;
    actions?: React.ReactNode;
}) {
    React.useEffect(() => {
        if (!open) return;

        const onKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape') onClose();
        };

        window.addEventListener('keydown', onKeyDown);
        return () => window.removeEventListener('keydown', onKeyDown);
    }, [open, onClose]);

    if (!open) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
            <div className="absolute inset-0 bg-black/40" onMouseDown={onClose}/>
            <Card
                className="relative w-full max-w-lg p-4"
                onMouseDown={(e) => {
                    e.stopPropagation();
                }}
            >
                <div className="mb-3 flex items-start justify-between gap-3">
                    <h3 className="section-title">{title}</h3>
                    <Button variant="icon" size="icon" onClick={onClose} aria-label="Закрити">
                        ✕
                    </Button>
                </div>

                {children}

                {actions ? <div className="mt-4 flex items-center justify-end gap-2">{actions}</div> : null}
            </Card>
        </div>
    );
}