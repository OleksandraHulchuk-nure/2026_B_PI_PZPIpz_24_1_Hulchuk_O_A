package com.nure.whatwecook.service;

import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.entity.recipe.RecipeIngredient;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.RecipeSourceType;
import com.nure.whatwecook.domain.enums.RecipeStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;

public interface RecipeService {

    Page<Recipe> getUserRecipes(UUID userId,
                                String search,
                                RecipeStatus status,
                                RecipeSourceType sourceType,
                                MealType mealType,
                                Integer maxTotalTimeMinutes,
                                Pageable pageable);

    Recipe getRecipeById(UUID userId, UUID recipeId);

    Recipe createManualRecipe(UUID userId,
                              Recipe recipe,
                              List<RecipeIngredient> ingredients);

    Recipe createAiRecipe(UUID userId,
                          Recipe recipe,
                          List<RecipeIngredient> ingredients);

    Recipe updateManualRecipe(UUID userId,
                              UUID recipeId,
                              Recipe recipeData,
                              List<RecipeIngredient> ingredients);

    void deleteRecipe(UUID userId, UUID recipeId);

    Recipe updateRecipeRating(UUID userId,
                              UUID recipeId,
                              Integer complexityRating,
                              Integer tasteRating,
                              String ratingComment,
                              RecipeStatus status);

    Recipe updateRecipeStatus(UUID userId,
                              UUID recipeId,
                              RecipeStatus status);
}
