package com.nure.whatwecook.dto.menu;

import com.nure.whatwecook.domain.enums.MenuStatus;
import lombok.Data;

@Data
public class WeeklyMenuStatusUpdateRequestDto {

    private MenuStatus status;
}
