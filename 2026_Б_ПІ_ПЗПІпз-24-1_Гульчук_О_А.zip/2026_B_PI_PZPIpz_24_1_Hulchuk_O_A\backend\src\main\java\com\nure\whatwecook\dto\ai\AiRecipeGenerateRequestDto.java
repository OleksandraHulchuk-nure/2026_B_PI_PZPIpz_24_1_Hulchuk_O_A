package com.nure.whatwecook.dto.ai;

import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MenuType;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
public class AiRecipeGenerateRequestDto {

    @NotNull
    private MealType mealType;

    private MenuType menuType;

    @Min(1)
    private Integer servings;

    private List<UUID> preferredIngredientIds;

    private String additionalNotes;
}
