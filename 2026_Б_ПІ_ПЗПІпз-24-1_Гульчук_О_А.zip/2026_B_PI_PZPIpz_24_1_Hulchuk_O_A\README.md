# WhatWeCook

WhatWeCook — вебзастосунок для керування книгою рецептів, формування тижневого меню та створення списку покупок.

Проєкт складається з трьох основних частин:

* `backend` — серверна частина на Java Spring Boot;
* `frontend` — клієнтська частина на Next.js / React / TypeScript;
* `postgres` — база даних PostgreSQL, що запускається через Docker Compose.

## Структура проєкту

```text
whatwecook/
  backend/
    Dockerfile
    pom.xml
    src/

  frontend/
    Dockerfile
    package.json

  docker-compose.yml
  .env
  README.md
```

## Налаштування змінних середовища

Перед запуском потрібно створити файл `.env` у корені проєкту та зазначити необхідні паролі, секрети та API-ключі.

Приклад `.env`:

```env
POSTGRES_DB=whatwecook
POSTGRES_USER=whatwecook_user
POSTGRES_PASSWORD=whatwecook_password

JWT_SECRET=change_me

WHATWECOOK_AI_ENABLED=true
GOOGLE_API_KEY=

NEXT_PUBLIC_API_BASE_URL=http://localhost:8080
```


## Запуск проєкту

Для запуску всіх сервісів потрібно виконати команду з кореневої папки:

```bash
docker compose up --build
```

Після запуску застосунок буде доступний за адресами:

```text
Frontend: http://localhost:3000
Backend:  http://localhost:8080
PostgreSQL: localhost:5432
```

Swagger UI для перевірки backend API:

```text
http://localhost:8080/swagger-ui/index.html
```

## Завершення роботи

Щоб зупинити запущені контейнери, виконайте:

```bash
docker compose down
```

Щоб зупинити контейнери та видалити дані PostgreSQL:

```bash
docker compose down -v
```

## Примітки

* Backend використовує змінні середовища для підключення до PostgreSQL, JWT та AI API.
* Frontend отримує адресу backend API через `NEXT_PUBLIC_API_BASE_URL`.
* Міграції бази даних виконуються backend-частиною через Liquibase під час запуску застосунку.
