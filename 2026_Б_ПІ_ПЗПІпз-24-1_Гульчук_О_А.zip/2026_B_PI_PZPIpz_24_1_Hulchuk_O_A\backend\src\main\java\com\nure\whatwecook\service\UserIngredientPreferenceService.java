package com.nure.whatwecook.service;

import com.nure.whatwecook.domain.entity.profile.UserIngredientPreference;
import com.nure.whatwecook.domain.enums.IngredientPreferenceType;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface UserIngredientPreferenceService {

    List<UserIngredientPreference> getUserIngredientPreferences(UUID userId);

    List<UserIngredientPreference> replaceUserIngredientPreferences(
            UUID userId,
            Map<IngredientPreferenceType, List<UUID>> ingredientIdsByType
    );
}
