package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.entity.profile.User;
import com.nure.whatwecook.domain.entity.profile.UserIngredientPreference;
import com.nure.whatwecook.domain.enums.IngredientPreferenceType;
import com.nure.whatwecook.repository.IngredientRepository;
import com.nure.whatwecook.repository.UserIngredientPreferenceRepository;
import com.nure.whatwecook.repository.UserRepository;
import com.nure.whatwecook.service.UserIngredientPreferenceService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserIngredientPreferenceServiceImpl implements UserIngredientPreferenceService {

    private final UserRepository userRepository;
    private final IngredientRepository ingredientRepository;
    private final UserIngredientPreferenceRepository userIngredientPreferenceRepository;

    @Override
    public List<UserIngredientPreference> getUserIngredientPreferences(UUID userId) {
        return userIngredientPreferenceRepository.findByUserId(userId);
    }

    @Override
    @Transactional
    public List<UserIngredientPreference> replaceUserIngredientPreferences(
            UUID userId,
            Map<IngredientPreferenceType, List<UUID>> ingredientIdsByType
    ) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));

        if (ingredientIdsByType == null || ingredientIdsByType.isEmpty()
                || ingredientIdsByType.values().stream().allMatch(list -> list == null || list.isEmpty())) {

            List<UserIngredientPreference> existing = userIngredientPreferenceRepository.findByUserId(userId);
            if (!existing.isEmpty()) {
                userIngredientPreferenceRepository.deleteAll(existing);
            }
            return Collections.emptyList();
        }

        Map<UUID, IngredientPreferenceType> preferenceByIngredient = new LinkedHashMap<>();

        ingredientIdsByType.forEach((type, ids) -> {
            if (ids == null) {
                return;
            }
            for (UUID ingredientId : ids) {
                if (ingredientId == null) {
                    continue;
                }
                IngredientPreferenceType existingType = preferenceByIngredient.get(ingredientId);
                if (existingType != null && existingType != type) {
                    throw new IllegalArgumentException(
                            "Ingredient " + ingredientId + " appears in multiple preference groups: "
                                    + existingType + " and " + type
                    );
                }
                preferenceByIngredient.put(ingredientId, type);
            }
        });

        if (preferenceByIngredient.isEmpty()) {
            List<UserIngredientPreference> existing = userIngredientPreferenceRepository.findByUserId(userId);
            if (!existing.isEmpty()) {
                userIngredientPreferenceRepository.deleteAll(existing);
            }
            return Collections.emptyList();
        }

        Set<UUID> allIngredientIds = preferenceByIngredient.keySet();

        List<Ingredient> ingredients = ingredientRepository.findByIdIn(allIngredientIds);
        Map<UUID, Ingredient> ingredientMap = ingredients.stream()
                .collect(Collectors.toMap(Ingredient::getId, i -> i));

        if (ingredientMap.size() != allIngredientIds.size()) {
            throw new EntityNotFoundException("Some ingredient IDs were not found");
        }

        List<UserIngredientPreference> existingPrefs = userIngredientPreferenceRepository.findByUserId(userId);

        Map<UUID, UserIngredientPreference> existingByIngredient = existingPrefs.stream()
                .collect(Collectors.toMap(
                        pref -> pref.getIngredient().getId(),
                        pref -> pref
                ));

        List<UserIngredientPreference> toSave = new ArrayList<>();

        for (Map.Entry<UUID, IngredientPreferenceType> entry : preferenceByIngredient.entrySet()) {
            UUID ingredientId = entry.getKey();
            IngredientPreferenceType type = entry.getValue();

            UserIngredientPreference pref = existingByIngredient.remove(ingredientId);
            if (pref == null) {
                pref = new UserIngredientPreference();
                pref.setUser(user);
                pref.setIngredient(ingredientMap.get(ingredientId));
            }

            pref.setPreferenceType(type);
            toSave.add(pref);
        }

        if (!existingByIngredient.isEmpty()) {
            userIngredientPreferenceRepository.deleteAll(existingByIngredient.values());
        }

        return userIngredientPreferenceRepository.saveAll(toSave);
    }



}
