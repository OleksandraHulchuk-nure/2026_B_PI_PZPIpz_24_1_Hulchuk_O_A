import {useEffect} from "react";
import {Card} from "@/components/ui/card";
import {Button} from "@/components/ui/button";
import * as React from "react";

export default function ConfirmApproveDialog({
                                  open,
                                  weekLabel,
                                  loading,
                                  onCancel,
                                  onConfirm,
                              }: {
    open: boolean;
    weekLabel: string;
    loading: boolean;
    onCancel: () => void;
    onConfirm: () => void;
}) {
    useEffect(() => {
        if (!open) return;

        function onKeyDown(e: KeyboardEvent) {
            if (e.key === 'Escape') onCancel();
        }

        window.addEventListener('keydown', onKeyDown);
        return () => window.removeEventListener('keydown', onKeyDown);
    }, [open, onCancel]);

    if (!open) return null;

    return (
        <div
            className="fixed inset-0 z-50 flex items-end justify-center bg-black/30 p-3 md:items-center"
            role="dialog"
            aria-modal="true"
            aria-label="Підтвердження меню"
            onMouseDown={onCancel}
        >
            <Card
                className="w-full max-w-lg rounded-2xl border border-border bg-surface p-0"
                onMouseDown={(e) => e.stopPropagation()}
            >
                <div className="flex items-center justify-between border-b border-border px-4 py-3">
                    <div className="flex flex-col gap-1">
                        <div className="text-sm font-semibold text-text-primary">Підтвердити меню?</div>
                        <div className="text-xs text-text-muted">Тиждень: {weekLabel}</div>
                    </div>

                    <Button variant="icon" size="icon" onClick={onCancel} aria-label="Закрити">
                        ×
                    </Button>
                </div>

                <div className="space-y-3 px-4 py-4">
                    <div className="rounded-2xl border border-border bg-background px-4 py-3">
                        <div className="text-sm text-text-primary">
                            Після підтвердження меню стане <span className="font-semibold">лише для перегляду</span>.
                        </div>
                        <ul className="mt-2 list-disc pl-5 text-xs text-text-muted">
                            <li>ви не зможете замінювати страви у слотах</li>
                            <li>не зможете “перегенерувати” меню для цього тижня</li>
                            <li>зате зʼявиться можливість створити список продуктів</li>
                        </ul>
                    </div>

                    <div className="flex flex-wrap justify-end gap-2">
                        <Button variant="secondary" onClick={onCancel} disabled={loading}>
                            Скасувати
                        </Button>
                        <Button onClick={onConfirm} disabled={loading}
                                title="Підтвердити меню і заблокувати редагування">
                            {loading ? 'Підтверджуємо…' : 'Підтвердити'}
                        </Button>
                    </div>
                </div>
            </Card>
        </div>
    );
}