import { useEffect, useState } from 'react';
import type { Dispatch, SetStateAction } from 'react';

import {
    getMealSchedule,
    updateMealSchedule,
    type DayOfWeek,
    type MealScheduleEntry,
    type MealType,
} from '@/lib/api/profileApi';

import type {
    CellKey,
    MealScheduleCellMap,
    MealScheduleHandlers,
    MealScheduleState,
} from '../profile.types';

type UseMealScheduleParams = {
    days: DayOfWeek[];
    mealTypes: MealType[];
};

type UseMealScheduleResult = MealScheduleState & MealScheduleHandlers & {
    setCells: Dispatch<SetStateAction<MealScheduleCellMap>>;
};

export function useMealSchedule({
                                    days,
                                    mealTypes,
                                }: UseMealScheduleParams): UseMealScheduleResult {
    const [cells, setCells] = useState<MealScheduleCellMap>({});
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);

    useEffect(() => {
        let isMounted = true;

        async function load() {
            setLoading(true);
            setError(null);

            try {
                const entries = await getMealSchedule();
                if (!isMounted) return;

                const initial: MealScheduleCellMap = {};
                for (const entry of entries) {
                    const key: CellKey = `${entry.dayOfWeek}-${entry.mealType}`;
                    initial[key] =
                        entry.servingsOverride != null
                            ? String(entry.servingsOverride)
                            : '';
                }
                setCells(initial);
            } catch (err) {
                if (!isMounted) return;
                const message =
                    err instanceof Error
                        ? err.message
                        : 'Не вдалося завантажити розклад.';
                setError(message);
            } finally {
                if (isMounted) setLoading(false);
            }
        }

        void load();
        return () => {
            isMounted = false;
        };
    }, [days, mealTypes]);

    const handleChange: MealScheduleHandlers['handleChange'] = (
        day,
        mealType,
        value,
    ) => {
        const key: CellKey = `${day}-${mealType}`;
        if (value === '' || /^[0-9]+$/.test(value)) {
            setCells((prev) => ({
                ...prev,
                [key]: value,
            }));
        }
    };

    const handleSave = async () => {
        setSaving(true);
        setError(null);
        setSuccess(null);

        const entries: MealScheduleEntry[] = [];

        for (const day of days) {
            for (const mealType of mealTypes) {
                const key: CellKey = `${day}-${mealType}`;
                const raw = cells[key];

                if (raw == null || raw === '') {
                    continue;
                }

                const parsed = Number(raw);
                if (Number.isNaN(parsed) || parsed <= 0) {
                    continue;
                }

                entries.push({
                    dayOfWeek: day,
                    mealType,
                    servingsOverride: parsed,
                });
            }
        }

        try {
            await updateMealSchedule(entries);
            setSuccess('Розклад прийомів їжі збережено.');
        } catch (err) {
            const message =
                err instanceof Error
                    ? err.message
                    : 'Не вдалося зберегти розклад.';
            setError(message);
        } finally {
            setSaving(false);
        }
    };

    return {
        cells,
        loading,
        saving,
        error,
        success,
        setCells,
        handleChange,
        handleSave,
    };
}
