package com.nure.whatwecook.domain.enums;

import lombok.Getter;

@Getter
public enum MeasurementUnit {

    GRAM("г"),
    MILLILITER("мл"),
    PIECE("шт");

    private final String ukrainianName;

    MeasurementUnit(String ukrainianName) {
        this.ukrainianName = ukrainianName;
    }

}
