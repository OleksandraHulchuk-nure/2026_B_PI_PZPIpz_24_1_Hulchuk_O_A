package com.nure.whatwecook.service.aggregation;

import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.enums.MeasurementUnit;
import lombok.Getter;

import java.math.BigDecimal;

@Getter
public class AggregatedIngredient {

    private final Ingredient ingredient;
    private final MeasurementUnit unit;
    private BigDecimal quantity;

    public AggregatedIngredient(Ingredient ingredient, MeasurementUnit unit) {
        this.ingredient = ingredient;
        this.unit = unit;
        this.quantity = BigDecimal.ZERO;
    }

    public void addQuantity(BigDecimal increment) {
        if (increment != null) {
            this.quantity = this.quantity.add(increment);
        }
    }
}
