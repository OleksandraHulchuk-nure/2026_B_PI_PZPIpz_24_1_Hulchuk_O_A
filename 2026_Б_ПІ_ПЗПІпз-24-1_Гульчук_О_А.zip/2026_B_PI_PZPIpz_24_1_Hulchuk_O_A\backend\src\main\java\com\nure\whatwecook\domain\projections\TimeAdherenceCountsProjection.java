package com.nure.whatwecook.domain.projections;

public interface TimeAdherenceCountsProjection {
    Integer getTimeConstraintsCnt();

    Integer getWithinTimeCnt();
}
