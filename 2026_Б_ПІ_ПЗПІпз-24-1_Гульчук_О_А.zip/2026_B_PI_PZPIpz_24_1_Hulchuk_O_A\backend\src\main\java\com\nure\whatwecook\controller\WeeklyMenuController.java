package com.nure.whatwecook.controller;


import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.domain.entity.menu.MenuDay;
import com.nure.whatwecook.domain.entity.menu.MenuMeal;
import com.nure.whatwecook.domain.entity.menu.WeeklyMenu;
import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.dto.ai.GenerateAiMenuSlotRequestDto;
import com.nure.whatwecook.dto.menu.*;
import com.nure.whatwecook.mapper.WeeklyMenuMapper;
import com.nure.whatwecook.repository.RecipeRepository;
import com.nure.whatwecook.service.WeeklyMenuService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Tag(name = "Weekly menus", description = "Generate and manage weekly menus")
@RestController
@RequestMapping("/api/menus/weekly")
@RequiredArgsConstructor
public class WeeklyMenuController {

    private final CurrentUserProvider currentUserProvider;
    private final WeeklyMenuService weeklyMenuService;
    private final WeeklyMenuMapper weeklyMenuMapper;
    private final RecipeRepository recipeRepository;

    @Operation(summary = "Get weekly menus history")
    @GetMapping
    public ResponseEntity<List<WeeklyMenuResponseDto>> getWeeklyMenus() {
        UUID userId = currentUserProvider.getCurrentUserId();
        List<WeeklyMenu> menus = weeklyMenuService.getWeeklyMenus(userId);
        return ResponseEntity.ok(weeklyMenuMapper.toDtoList(menus));
    }

    @Operation(summary = "Generate weekly menu for user")
    @PostMapping("/generate")
    public ResponseEntity<WeeklyMenuResponseDto> generateWeeklyMenu(
            @RequestBody(required = false) WeeklyMenuGenerateRequestDto request
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        LocalDate startDate = request != null ? request.getStartDate() : null;

        WeeklyMenu menu = weeklyMenuService.generateWeeklyMenu(
                userId,
                startDate,
                request != null ? request.getDays() : null,
                request != null ? request.getMealsPerDay() : null
        );
        return ResponseEntity.ok(weeklyMenuMapper.toDto(menu));
    }

    @Operation(summary = "Get weekly menu by id")
    @GetMapping("/{id}")
    public ResponseEntity<WeeklyMenuResponseDto> getWeeklyMenu(@PathVariable("id") UUID id) {
        UUID userId = currentUserProvider.getCurrentUserId();
        WeeklyMenu menu = weeklyMenuService.getWeeklyMenu(userId, id);
        return ResponseEntity.ok(weeklyMenuMapper.toDto(menu));
    }

    @Operation(summary = "Update weekly menu structure (days and meals)")
    @PutMapping("/{id}")
    public ResponseEntity<WeeklyMenuResponseDto> updateWeeklyMenu(
            @PathVariable("id") UUID id,
            @RequestBody WeeklyMenuUpdateRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();

        WeeklyMenu updatedStructure = new WeeklyMenu();
        List<MenuDay> days = new ArrayList<>();

        if (requestDto.getDays() != null) {
            for (MenuDayPlanDto dayDto : requestDto.getDays()) {
                MenuDay day = new MenuDay();
                day.setDate(dayDto.getDate());
                List<MenuMeal> meals = new ArrayList<>();

                if (dayDto.getMeals() != null) {
                    for (MenuMealPlanDto mealDto : dayDto.getMeals()) {
                        MenuMeal meal = new MenuMeal();
                        meal.setMealType(mealDto.getMealType());

                        UUID recipeId = mealDto.getRecipeId();
                        if (recipeId != null) {
                            Recipe recipe = recipeRepository.findById(recipeId)
                                    .orElseThrow(() -> new EntityNotFoundException("Recipe not found"));
                            meal.setRecipe(recipe);
                        }

                        meals.add(meal);
                    }
                }

                day.setMeals(meals);
                days.add(day);
            }
        }

        updatedStructure.setDays(days);

        WeeklyMenu saved = weeklyMenuService.updateWeeklyMenuStructure(userId, id, updatedStructure);
        return ResponseEntity.ok(weeklyMenuMapper.toDto(saved));
    }

    @Operation(summary = "Update weekly menu status (e.g. DRAFT -> APPROVED)")
    @PutMapping("/{id}/status")
    public ResponseEntity<WeeklyMenuResponseDto> updateWeeklyMenuStatus(
            @PathVariable("id") UUID id,
            @RequestBody WeeklyMenuStatusUpdateRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        WeeklyMenu saved = weeklyMenuService.updateWeeklyMenuStatus(userId, id, requestDto.getStatus());
        return ResponseEntity.ok(weeklyMenuMapper.toDto(saved));
    }

    @Operation(summary = "Replace recipe for specific menu meal")
    @PutMapping("/{id}/slots/{slotId}")
    public ResponseEntity<WeeklyMenuResponseDto> replaceMenuMeal(
            @PathVariable("id") UUID id,
            @PathVariable("slotId") UUID slotId,
            @RequestBody MenuMealReplacementRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        WeeklyMenu saved = weeklyMenuService.replaceMenuMeal(userId, id, slotId, requestDto.getRecipeId());
        return ResponseEntity.ok(weeklyMenuMapper.toDto(saved));
    }

    @Operation(summary = "Approve weekly menu")
    @PostMapping("/{id}/approve")
    public ResponseEntity<WeeklyMenuResponseDto> approveWeeklyMenu(@PathVariable("id") UUID id) {
        UUID userId = currentUserProvider.getCurrentUserId();
        WeeklyMenu saved = weeklyMenuService.approveWeeklyMenu(userId, id);
        return ResponseEntity.ok(weeklyMenuMapper.toDto(saved));
    }

    @Operation(summary = "Get user's weekly menu by start date")
    @GetMapping("/by-start-date")
    public ResponseEntity<WeeklyMenuResponseDto> getWeeklyMenuByStartDate(
            @RequestParam("startDate")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        WeeklyMenu weeklyMenu = weeklyMenuService.getUserMenuByStartDate(userId, startDate);
        return ResponseEntity.ok(weeklyMenuMapper.toDto(weeklyMenu));
    }

    @Operation(summary = "Generate AI recipe for a specific weekly menu slot")
    @PostMapping("/{id}/slots/{slotId}/generate-ai")
    public ResponseEntity<WeeklyMenuResponseDto> generateAiForSlot(
            @PathVariable("id") UUID weeklyMenuId,
            @PathVariable("slotId") UUID slotId,
            @RequestBody(required = false) GenerateAiMenuSlotRequestDto request
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();

        Integer maxTimeMinutes = request != null ? request.getMaxTimeMinutes() : null;
        String extraNotes = request != null ? request.getExtraNotes() : null;

        WeeklyMenu updatedMenu = weeklyMenuService.generateAiRecipeForSlot(
                userId,
                weeklyMenuId,
                slotId,
                maxTimeMinutes,
                extraNotes
        );

        return ResponseEntity.ok(weeklyMenuMapper.toDto(updatedMenu));
    }
}
