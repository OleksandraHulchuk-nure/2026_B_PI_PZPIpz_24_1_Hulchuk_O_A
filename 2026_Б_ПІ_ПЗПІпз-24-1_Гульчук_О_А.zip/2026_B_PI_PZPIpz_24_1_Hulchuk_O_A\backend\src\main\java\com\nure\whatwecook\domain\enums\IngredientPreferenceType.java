package com.nure.whatwecook.domain.enums;

import lombok.Getter;

@Getter
public enum IngredientPreferenceType {

    FAVORITE("Улюблене"),
    DISLIKED("Не подобається"),
    ALLERGY("Алергія"),
    EXCLUSION("Виключити");

    private final String ukrainianName;

    IngredientPreferenceType(String ukrainianName) {
        this.ukrainianName = ukrainianName;
    }

}
