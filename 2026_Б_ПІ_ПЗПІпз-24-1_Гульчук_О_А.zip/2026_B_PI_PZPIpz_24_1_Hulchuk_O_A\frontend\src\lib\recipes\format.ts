/**
 * Форматує кількість для UI (uk-UA, до 2 знаків після коми).
 */
export function formatQty(value: number, maxFractionDigits = 2): string {
    const nf = new Intl.NumberFormat('uk-UA', { maximumFractionDigits: maxFractionDigits });
    return nf.format(value);
}

/**
 * Беремо steps як масив строк (якщо є), інакше — fallback з description по рядках.
 * Порожні/пробільні рядки прибираємо.
 */
export function normalizeSteps(
    steps?: Array<string | null | undefined> | null,
    fallbackDescription?: string | null,
): string[] {
    const clean = (arr: Array<string | null | undefined>) =>
        arr.map((s) => (s ?? '').trim()).filter(Boolean);

    if (Array.isArray(steps) && steps.length) {
        const cleaned = clean(steps);
        if (cleaned.length) return cleaned;
    }

    if (!fallbackDescription) return [];

    return fallbackDescription
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean);
}
