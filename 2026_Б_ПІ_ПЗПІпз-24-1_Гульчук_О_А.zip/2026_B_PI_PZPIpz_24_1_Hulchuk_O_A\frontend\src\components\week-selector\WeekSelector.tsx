'use client';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MaterialIcon } from '@/components/ui/materialIcon';
import { addDays, toIsoDate, toMondayIso } from '@/lib/utils/date';
import { cn } from '@/lib/utils';

interface WeekSelectorProps {
    weekStart: string;
    onChange: (startDate: string) => void;
    disabled?: boolean;
    label?: string;
    helperText?: string;
    id?: string;
    className?: string;
}

export function WeekSelector({
    weekStart,
    onChange,
    disabled = false,
    label,
    helperText,
    id = 'weekStart',
    className,
}: WeekSelectorProps) {
    function shiftWeek(offset: number) {
        const nextWeekStart = toMondayIso(toIsoDate(addDays(new Date(`${weekStart}T00:00:00`), offset * 7)));
        onChange(nextWeekStart);
    }

    function handleDateChange(value: string) {
        if (!value) return;
        onChange(toMondayIso(value));
    }

    return (
        <div className={cn('flex flex-wrap items-end gap-2', className)}>
            <Button
                variant="secondary"
                size="icon"
                onClick={() => shiftWeek(-1)}
                disabled={disabled}
                title="Попередній тиждень"
                aria-label="Попередній тиждень"
            >
                <MaterialIcon name="chevron_left" className="text-xl" />
            </Button>

            <div className="flex flex-col gap-1">
                {label ? (
                    <label className="text-xs text-text-muted" htmlFor={id}>
                        {label}
                    </label>
                ) : null}
                <Input
                    id={id}
                    type="date"
                    value={weekStart}
                    onChange={(e) => handleDateChange(e.target.value)}
                    disabled={disabled}
                    className="max-w-[220px]"
                />
                {helperText ? <div className="text-xs text-text-muted">{helperText}</div> : null}
            </div>

            <Button
                variant="secondary"
                size="icon"
                onClick={() => shiftWeek(1)}
                disabled={disabled}
                title="Наступний тиждень"
                aria-label="Наступний тиждень"
            >
                <MaterialIcon name="chevron_right" className="text-xl" />
            </Button>
        </div>
    );
}

export default WeekSelector;
