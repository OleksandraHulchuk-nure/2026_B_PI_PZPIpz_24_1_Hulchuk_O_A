package com.nure.whatwecook.service;

import com.nure.whatwecook.dto.auth.AuthResponseDto;
import com.nure.whatwecook.dto.auth.LoginRequestDto;
import com.nure.whatwecook.dto.auth.RegisterRequestDto;

public interface AuthService {

    AuthResponseDto register(RegisterRequestDto request);

    AuthResponseDto login(LoginRequestDto request);

    void logout();
}
