'use client';

import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { MaterialIcon } from '@/components/ui/materialIcon';
import type { StatPeriodAiMetricsDto, DecimalLike } from '@/lib/api/statsApi';

function dec(v: DecimalLike): number | undefined {
    if (typeof v === 'number' && Number.isFinite(v)) return v;
    if (v && typeof v === 'object' && Number.isFinite(v.parsedValue)) {
        return v.parsedValue;
    }
    return undefined;
}

function pct(v: DecimalLike) {
    const n0 = dec(v);
    if (n0 === undefined) return '—';
    const n = n0 <= 1.000001 ? n0 * 100 : n0;
    return `${Math.round(n)}%`;
}

function num(v: DecimalLike, digits = 1) {
    const n = dec(v);
    if (n === undefined) return '—';
    return n.toFixed(digits);
}

function ratioHint(den?: number, numr?: number) {
    if (typeof den !== 'number' || typeof numr !== 'number') return '';
    return ` (${numr}/${den})`;
}

function MiniKpi(props: { label: string; value: string; tooltip: string }) {
    return (
        <div className="h-full rounded-xl border border-border bg-surface px-3 py-2">
            <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted leading-snug">
                    {props.label}
                </div>
                <MaterialIcon name="info" className="text-[16px] shrink-0 text-text-muted" title={props.tooltip} />
            </div>
            <div className="mt-1 text-sm font-bold whitespace-nowrap">{props.value}</div>
        </div>
    );
}

export function AiQualityTrendCard(props: { data?: StatPeriodAiMetricsDto }) {
    const ai = props.data?.ai;

    const verified = ai?.verifiedCnt ?? 0;
    const rejected = ai?.rejectedCnt ?? 0;
    const successDen = verified + rejected;

    const success = ai ? `${pct(ai.successPct)}${ratioHint(successDen, verified)}` : '—';
    const rated = ai ? `${pct(ai.ratedPct)}${ratioHint(ai.aiMeals, ai.ratedCnt)}` : '—';
    const share = ai ? `${pct(ai.aiSharePct)}${ratioHint(ai.allMeals, ai.aiMeals)}` : '—';

    const taste = ai ? `${num(ai.avgTaste, 1)}${ai.ratedCnt ? ` (n=${ai.ratedCnt})` : ''}` : '—';

    const verifiedStr = ai ? String(verified) : '—';
    const rejectedStr = ai ? String(rejected) : '—';

    return (
        <Card className="p-0" variant="ai">
            <CardHeader className="flex items-center justify-between">
                <div>
                    <div className="text-sm font-bold">AI — якість рецептів</div>
                    <div className="text-xs text-text-muted">Агреговані метрики за обраний період</div>
                </div>
                <span className="material-symbols-outlined text-[18px] leading-none text-text-muted">auto_awesome</span>
            </CardHeader>

            <CardContent className="grid grid-cols-2 gap-2 lg:grid-cols-3 xl:grid-cols-6">
                <MiniKpi
                    label="AI у меню"
                    value={share}
                    tooltip="AiSharePct: частка AI-страв серед усіх страв у меню (aiMeals/allMeals)."
                />
                <MiniKpi
                    label="Успішні"
                    value={success}
                    tooltip="SuccessPct: частка VERIFIED серед (VERIFIED+REJECTED) для AI-рецептів."
                />
                <MiniKpi label="Оцінені" value={rated} tooltip="RatedPct: частка оцінених AI-рецептів." />
                <MiniKpi
                    label="Смак AI"
                    value={taste}
                    tooltip="AvgTaste: середній смак (рахується по оцінених; n=ratedCnt)."
                />
                <MiniKpi label="Перевірені" value={verifiedStr} tooltip="Кількість AI-рецептів зі статусом VERIFIED." />
                <MiniKpi label="Відхилені" value={rejectedStr} tooltip="Кількість AI-рецептів зі статусом REJECTED." />
            </CardContent>
        </Card>
    );
}
