package com.nure.whatwecook.domain.projections;

public interface ComplexityAdherenceCountsProjection {
    Integer getComplexityConstraintsCnt();

    Integer getWithinComplexityCnt();
}
