package com.nure.whatwecook.dto.stats;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public record StatPeriodTopIngredientsDto(
        LocalDate from,
        LocalDate to,
        Integer limit,
        boolean includeOptional,
        List<ItemDto> items
) {
    public record ItemDto(
            UUID ingredientId,
            String ingredientNameUk,
            String unit,
            BigDecimal totalQuantity
    ) {}
}
