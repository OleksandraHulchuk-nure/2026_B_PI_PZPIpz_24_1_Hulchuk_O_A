'use client';

import React, { useCallback, useEffect, useState } from 'react';
import { StatsFilters, type Preset } from '@/components/stats/StatsFilters';
import { StatsKpiGrid } from '@/components/stats/KpiGrid';
import { AiQualityTrendCard } from '@/components/stats/AiQualityCard';
import { ShoppingByCategoryCard } from '@/components/stats/ShoppingByCategoryCard';
import { ShoppingByIngredientCard } from '@/components/stats/ShoppingByIngredientCard';

import {
    getAiMetrics,
    getMenuMetrics,
    getTopCategories,
    getTopIngredients,
    type StatPeriodAiMetricsDto,
    type StatPeriodMenuMetricsDto,
    type StatPeriodTopCategoriesDto,
    type StatPeriodTopIngredientsDto,
} from '@/lib/api/statsApi';

function formatDate(d: Date): string {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
}

function todayLocal(): Date {
    const t = new Date();
    t.setHours(0, 0, 0, 0);
    return t;
}

export default function StatsPage() {
    const [preset, setPreset] = useState<Preset>('WEEK');
    const [startDate, setStartDate] = useState(() => {
        const end = todayLocal();
        const start = new Date(end);
        start.setDate(end.getDate() - 6);
        return formatDate(start);
    });
    const [endDate, setEndDate] = useState(() => formatDate(todayLocal()));

    const limit = 10;
    const includeOptional = false;

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [ai, setAi] = useState<StatPeriodAiMetricsDto>();
    const [menu, setMenu] = useState<StatPeriodMenuMetricsDto>();
    const [topCat, setTopCat] = useState<StatPeriodTopCategoriesDto>();
    const [topIng, setTopIng] = useState<StatPeriodTopIngredientsDto>();

    const load = useCallback(async () => {
        setLoading(true);
        setError(null);

        try {
            const [aiRes, menuRes, catRes, ingRes] = await Promise.all([
                getAiMetrics({ from: startDate, to: endDate }),
                getMenuMetrics({ from: startDate, to: endDate }),
                getTopCategories({ from: startDate, to: endDate, limit, includeOptional }),
                getTopIngredients({ from: startDate, to: endDate, limit, includeOptional }),
            ]);

            setAi(aiRes);
            setMenu(menuRes);
            setTopCat(catRes);
            setTopIng(ingRes);
        } catch (e: unknown) {
            setError(e instanceof Error ? e.message : 'Помилка завантаження статистики');
        } finally {
            setLoading(false);
        }
    }, [startDate, endDate, limit, includeOptional]);

    useEffect(() => {
        void load();
    }, [load]);

    return (
        <div className="flex flex-col gap-6">
            <StatsFilters
                preset={preset}
                startDate={startDate}
                endDate={endDate}
                loading={loading}
                onPresetChange={setPreset}
                onStartDateChange={setStartDate}
                onEndDateChange={setEndDate}
                onReload={load}
            />

            {error ? <div className="text-sm text-error">{error}</div> : null}
            {loading ? <div className="text-xs text-text-muted">Завантаження…</div> : null}

            <StatsKpiGrid data={menu} />

            <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
                <div className="lg:col-span-2">
                    <AiQualityTrendCard data={ai} />
                </div>

                <ShoppingByCategoryCard data={topCat} />
                <ShoppingByIngredientCard data={topIng} />
            </div>
        </div>
    );
}
