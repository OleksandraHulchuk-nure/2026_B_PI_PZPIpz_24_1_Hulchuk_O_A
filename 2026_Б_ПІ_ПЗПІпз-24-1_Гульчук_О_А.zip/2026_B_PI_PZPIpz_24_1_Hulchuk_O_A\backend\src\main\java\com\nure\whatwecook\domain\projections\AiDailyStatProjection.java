package com.nure.whatwecook.domain.projections;

import java.time.LocalDate;

public interface AiDailyStatProjection {
    LocalDate getMenuDayDate();

    Integer getTotalAi();

    Integer getVerifiedCnt();

    Integer getRejectedCnt();

    Integer getRatedCnt();

    java.math.BigDecimal getAvgTaste(); // nullable
}
