'use client';

import React from 'react';

export type BarListItem = { key: string; label: string; value: number; sub?: string };

export function BarList({ items }: { items: BarListItem[] }) {
    const max = Math.max(1, ...items.map((i) => i.value));

    return (
        <div className="flex flex-col gap-2">
            {items.map((it, idx) => {
                const w = Math.round((it.value / max) * 100);
                return (
                    <div key={`${it.key}-${idx}`} className="flex items-center gap-3">
                        <div className="w-36 truncate text-xs text-text-muted">{it.label}</div>
                        <div className="flex-1">
                            <div className="h-2 w-full rounded-full bg-primary-soft/60">
                                <div className="h-2 rounded-full bg-primary" style={{ width: `${w}%` }} />
                            </div>
                        </div>
                        <div className="w-20 text-right text-xs font-semibold">{it.sub ?? it.value}</div>
                    </div>
                );
            })}
        </div>
    );
}
