package com.nure.whatwecook.service.helper.pdf;

public record PdfDocument(String filename, byte[] content) {}

