package com.nure.whatwecook.service.reports.pdf;

public enum PdfReportType {
    WEEKLY_MENU,
    WEEKLY_SHOPPING_LIST
}
