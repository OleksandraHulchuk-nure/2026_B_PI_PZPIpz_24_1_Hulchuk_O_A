package com.nure.whatwecook.domain.projections;

public interface IngredientCategoryTopProjection {
    String getIngredientCategory();

    Integer getItemsCnt();
}
