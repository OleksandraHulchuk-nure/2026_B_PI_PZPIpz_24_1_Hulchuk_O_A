﻿'use client';

import Link from 'next/link';
import * as React from 'react';
import {useRouter, useSearchParams} from 'next/navigation';

import {Alert} from '@/components/ui/alert';
import {Badge} from '@/components/ui/badge';
import {Button} from '@/components/ui/button';
import {Card, CardContent, CardHeader} from '@/components/ui/card';
import {Input} from '@/components/ui/input';
import {PageSection} from '@/components/page-section';
import WeekSelector from '@/components/week-selector/WeekSelector';
import {MaterialIcon} from '@/components/ui/materialIcon';

import * as shoppingListApi from '@/lib/api/shoppingListApi';
import * as weeklyMenuApi from '@/lib/api/weeklyMenuApi';
import {ApiError} from '@/lib/api/apiClient';
import {downloadShoppingListReport} from '@/lib/api/reportsApi';
import {
    MEASUREMENT_UNIT_LABELS,
    MENU_STATUS_LABELS,
    menuStatusBadgeVariant,
    PRODUCT_CATEGORY_LABELS,
    PRODUCT_CATEGORY_ORDER,
    ProductCategory,
} from '@/lib/constants/enums';
import {formatWeekRange, startOfWeek, toIsoDate, toMondayIso} from '@/lib/utils/date';
import {downloadBlob} from '@/lib/utils/download';
import type {ShoppingItemDto, ShoppingListResponseDto} from '@/lib/api/shoppingListApi';

type LoadState = 'loading' | 'error' | 'ready' | 'not_found';
type Notice = { type: 'success' | 'error' | 'info'; message: string } | null;

function clampNumber(n: number) {
    if (!Number.isFinite(n)) return 0;
    return Math.max(0, n);
}

function formatQty(n: number) {
    return Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100);
}

function groupByCategory(items: ShoppingItemDto[]) {
    const map = new Map<ProductCategory, ShoppingItemDto[]>();
    items.forEach((it) => {
        const arr = map.get(it.category) ?? [];
        arr.push(it);
        map.set(it.category, arr);
    });
    return map;
}

function lsKey(listId: string) {
    return `whatwecook:shopping:${listId}:have`;
}

export default function ShoppingListEntryClient() {
    const router = useRouter();
    const searchParams = useSearchParams();

    const currentWeekStart = React.useMemo(() => toIsoDate(startOfWeek(new Date())), []);
    const weekStart = React.useMemo(() => {
        const rawWeekStart = searchParams.get('weekStart');
        return rawWeekStart ? toMondayIso(rawWeekStart) : currentWeekStart;
    }, [searchParams, currentWeekStart]);

    const weekRange = React.useMemo(() => formatWeekRange(weekStart), [weekStart]);
    const weeklyMenuHref = React.useMemo(
        () => `/weekly-menu?weekStart=${encodeURIComponent(weekStart)}`,
        [weekStart],
    );

    const [menu, setMenu] = React.useState<weeklyMenuApi.WeeklyMenuResponseDto | null>(null);
    const [menuState, setMenuState] = React.useState<LoadState>('loading');
    const [menuError, setMenuError] = React.useState('');

    const [list, setList] = React.useState<ShoppingListResponseDto | null>(null);
    const [state, setState] = React.useState<LoadState>('loading');
    const [error, setError] = React.useState('');

    const [haveById, setHaveById] = React.useState<Record<string, number>>({});
    const [baselineHaveById, setBaselineHaveById] = React.useState<Record<string, number>>({});

    const [saving, setSaving] = React.useState(false);
    const [creating, setCreating] = React.useState(false);
    const [reportLoading, setReportLoading] = React.useState(false);
    const [notice, setNotice] = React.useState<Notice>(null);

    const [query, setQuery] = React.useState('');
    const [onlyToBuy, setOnlyToBuy] = React.useState(false);
    const [collapsed, setCollapsed] = React.useState<Record<string, boolean>>({});

    const loadRequestRef = React.useRef(0);

    const hydrateShoppingList = React.useCallback((data: ShoppingListResponseDto) => {
        const fromLs: Record<string, number> = (() => {
            try {
                const raw = localStorage.getItem(lsKey(data.id));
                if (!raw) return {};
                const parsed = JSON.parse(raw) as Record<string, number>;
                return parsed && typeof parsed === 'object' ? parsed : {};
            } catch {
                return {};
            }
        })();

        const initialHave: Record<string, number> = {};
        data.items.forEach((it) => {
            const apiHave = typeof it.haveQuantity === 'number' ? it.haveQuantity : undefined;
            const lsHave = typeof fromLs[it.id] === 'number' ? fromLs[it.id] : undefined;
            initialHave[it.id] = clampNumber(apiHave ?? lsHave ?? 0);
        });

        setList(data);
        setHaveById(initialHave);
        setBaselineHaveById(initialHave);
        setCollapsed({});
    }, []);

    const loadWeekData = React.useCallback(async (targetWeekStart: string) => {
        const requestId = ++loadRequestRef.current;

        setMenuState('loading');
        setMenu(null);
        setMenuError('');

        setState('loading');
        setList(null);
        setError('');

        setHaveById({});
        setBaselineHaveById({});
        setCollapsed({});
        setNotice(null);

        const [menuResult, listResult] = await Promise.allSettled([
            weeklyMenuApi.getWeeklyMenuByStartDate(targetWeekStart),
            shoppingListApi.getShoppingListByStartDate(targetWeekStart),
        ]);

        if (loadRequestRef.current !== requestId) return;

        if (menuResult.status === 'fulfilled') {
            setMenu(menuResult.value);
            setMenuState('ready');
        } else {
            const reason = menuResult.reason;
            if (reason instanceof ApiError && reason.status === 404) {
                setMenu(null);
                setMenuState('not_found');
            } else {
                setMenu(null);
                setMenuState('error');
                setMenuError(reason instanceof Error ? reason.message : 'Не вдалося завантажити меню для цього тижня.');
            }
        }

        if (listResult.status === 'fulfilled') {
            hydrateShoppingList(listResult.value);
            setState('ready');
        } else {
            const reason = listResult.reason;
            if (reason instanceof ApiError && reason.status === 404) {
                setState('not_found');
            } else {
                setState('error');
                setError(reason instanceof Error ? reason.message : 'Не вдалося завантажити список продуктів.');
            }
        }
    }, [hydrateShoppingList]);

    React.useEffect(() => {
        void loadWeekData(weekStart);
    }, [loadWeekData, weekStart]);

    React.useEffect(() => {
        if (!list?.id) return;
        try {
            localStorage.setItem(lsKey(list.id), JSON.stringify(haveById));
        } catch {
            // ignore
        }
    }, [list?.id, haveById]);

    const filteredItems = React.useMemo(() => {
        const items = list?.items ?? [];
        const q = query.trim().toLowerCase();

        return items
            .filter((it) => {
                if (q && !it.ingredientNameUk.toLowerCase().includes(q)) return false;

                const have = clampNumber(haveById[it.id] ?? 0);
                const needed = clampNumber(it.neededQuantity ?? 0);
                const toBuy = clampNumber(needed - have);

                if (onlyToBuy && toBuy <= 0) return false;
                return true;
            })
            .sort((a, b) => a.ingredientNameUk.localeCompare(b.ingredientNameUk, 'uk'));
    }, [haveById, list, onlyToBuy, query]);

    const grouped = React.useMemo(() => groupByCategory(filteredItems), [filteredItems]);

    const dirtyCount = React.useMemo(() => {
        const ids = Object.keys(haveById);
        let count = 0;

        ids.forEach((id) => {
            const current = clampNumber(haveById[id] ?? 0);
            const baseline = clampNumber(baselineHaveById[id] ?? 0);
            if (current !== baseline) count += 1;
        });

        return count;
    }, [baselineHaveById, haveById]);

    const summary = React.useMemo(() => {
        const items = list?.items ?? [];
        let toBuyTotal = 0;

        items.forEach((it) => {
            const have = clampNumber(haveById[it.id] ?? 0);
            const needed = clampNumber(it.neededQuantity ?? 0);
            if (needed - have > 0) toBuyTotal += 1;
        });

        return {total: items.length, toBuyTotal};
    }, [haveById, list]);

    const isBusy = state === 'loading' || menuState === 'loading' || saving || creating || reportLoading;
    const canCreate = Boolean(menu && menu.status === 'APPROVED' && state === 'not_found');
    const hasBlockingError = state === 'error' || (menuState === 'error' && state !== 'ready');

    function pushWeekStart(nextWeekStart: string) {
        const normalizedWeekStart = toMondayIso(nextWeekStart);
        if (normalizedWeekStart === weekStart) return;

        const params = new URLSearchParams(searchParams.toString());
        if (normalizedWeekStart === currentWeekStart) {
            params.delete('weekStart');
        } else {
            params.set('weekStart', normalizedWeekStart);
        }

        const target = params.toString() ? `/shopping-list?${params.toString()}` : '/shopping-list';
        router.push(target, {scroll: false});
    }

    async function handleCreateShoppingList() {
        if (!menu) return;

        setCreating(true);
        setNotice(null);

        try {
            const created = await shoppingListApi.generateShoppingListFromWeeklyMenu(menu.id);
            hydrateShoppingList(created);
            setState('ready');
            setNotice({type: 'success', message: 'Список продуктів створено.'});
        } catch (e) {
            setNotice({
                type: 'error',
                message: e instanceof Error ? e.message : 'Не вдалося створити список продуктів.',
            });
        } finally {
            setCreating(false);
        }
    }

    async function onSave() {
        if (!list) return;

        const updates: Array<{ itemId: string; haveQuantity: number }> = [];
        list.items.forEach((it) => {
            const current = clampNumber(haveById[it.id] ?? 0);
            const baseline = clampNumber(baselineHaveById[it.id] ?? 0);
            if (current !== baseline) updates.push({itemId: it.id, haveQuantity: current});
        });

        if (updates.length === 0) {
            setNotice({type: 'info', message: 'Немає змін для збереження.'});
            return;
        }

        try {
            setSaving(true);
            setNotice(null);
            const updated = await shoppingListApi.updateHaveQuantities(list.id, updates);
            setList(updated);
            setBaselineHaveById({...haveById});
            setNotice({type: 'success', message: 'Зміни збережено.'});
        } catch (e) {
            setNotice({
                type: 'error',
                message: e instanceof Error ? e.message : 'Не вдалося зберегти зміни.',
            });
        } finally {
            setSaving(false);
        }
    }

    function onCancel() {
        if (dirtyCount === 0) return;

        setHaveById({...baselineHaveById});
        setNotice(null);
    }

    async function onDownloadPdf() {
        if (!list) return;

        try {
            setReportLoading(true);
            setNotice(null);

            const blob = await downloadShoppingListReport(list.id);
            downloadBlob(blob, `shopping-list-${list.weekStart ?? weekStart}.pdf`);
            setNotice({type: 'success', message: 'PDF список продуктів готовий для друку.'});
        } catch (e) {
            setNotice({
                type: 'error',
                message: e instanceof Error ? e.message : 'Не вдалося згенерувати PDF список продуктів.',
            });
        } finally {
            setReportLoading(false);
        }
    }

    function onRetry() {
        void loadWeekData(weekStart);
    }

    function setHave(itemId: string, value: string) {
        const num = clampNumber(Number(value));
        setHaveById((prev) => ({...prev, [itemId]: num}));
        setNotice(null);
    }

    function setHaveAllInCategory(category: ProductCategory) {
        const items = grouped.get(category) ?? [];
        setHaveById((prev) => {
            const next = {...prev};
            items.forEach((it) => {
                next[it.id] = clampNumber(it.neededQuantity ?? 0);
            });
            return next;
        });
        setNotice(null);
    }

    function clearHaveInCategory(category: ProductCategory) {
        const items = grouped.get(category) ?? [];
        setHaveById((prev) => {
            const next = {...prev};
            items.forEach((it) => {
                next[it.id] = 0;
            });
            return next;
        });
        setNotice(null);
    }

    function setHaveAllForItem(itemId: string, needed: number, checked: boolean) {
        setHaveById((prev) => ({
            ...prev,
            [itemId]: checked ? clampNumber(needed) : 0,
        }));
        setNotice(null);
    }

    function toggleCategory(category: ProductCategory) {
        setCollapsed((prev) => ({...prev, [category]: !prev[category]}));
    }

    const dynamicSubtitle = React.useMemo(() => {
        if (state === 'ready') {
            return 'Позначайте наявні продукти й переглядайте, що потрібно докупити.';
        }

        if (state === 'not_found' && menuState === 'ready' && menu?.status === 'APPROVED') {
            return 'Для цього тижня меню підтверджене, але список продуктів ще не створено.';
        }

        if (menuState === 'not_found') {
            return 'Оберіть тиждень, щоб перевірити наявний список продуктів або створити його з меню.';
        }

        return 'Перемикайте тижні та працюйте зі списком продуктів в одному місці.';
    }, [menu?.status, menuState, state]);

    const headerActions =
        state === 'ready' || canCreate ? (
            <>
                {state === 'ready' ? (
                    <>
                        <Button onClick={onSave} disabled={saving || dirtyCount === 0}>
                            {saving ? 'Збереження…' : `Зберегти${dirtyCount ? ` (${dirtyCount})` : ''}`}
                        </Button>
                        <Button variant="secondary" onClick={onCancel} disabled={saving || dirtyCount === 0}>
                            Скасувати
                        </Button>
                    </>
                ) : null}
                {canCreate ? (
                    <Button onClick={handleCreateShoppingList} disabled={creating}>
                        {creating ? 'Створюємо…' : 'Створити список'}
                    </Button>
                ) : null}
            </>
        ) : undefined;

    const titleBadges =
        state === 'ready' && summary.total > 0 ? (
            <>
                <Badge variant="soft">Позицій: {summary.total}</Badge>
                <Badge variant="soft">Купити: {summary.toBuyTotal}</Badge>
            </>
        ) : undefined;

    return (
        <div className="flex flex-col gap-6">
            <PageSection
                titleAs="h2"
                title="Список продуктів"
                subtitle={dynamicSubtitle}
                titleAddon={titleBadges}
                actions={headerActions}
            />

            <div className="flex flex-col gap-3 border-b border-border/70 pb-4 lg:flex-row lg:items-center lg:gap-4">
                <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xl font-semibold text-text-primary">Меню</span>
                    <Badge variant="info">{weekRange}</Badge>
                    {menuState === 'ready' && menu ? (
                        <Badge variant={menuStatusBadgeVariant(menu.status)}>{MENU_STATUS_LABELS[menu.status]}</Badge>
                    ) : null}
                </div>

                <WeekSelector weekStart={weekStart} onChange={pushWeekStart} disabled={isBusy} className="lg:ml-auto lg:flex-nowrap lg:items-center lg:justify-end"/>
            </div>

            {notice ? (
                <Alert
                    variant={notice.type === 'error' ? 'error' : notice.type === 'success' ? 'success' : 'info'}
                    title={notice.type === 'error' ? 'Помилка' : notice.type === 'success' ? 'Готово' : 'Нагадування'}
                >
                    {notice.message}
                </Alert>
            ) : null}

            {hasBlockingError ? (
                <Card className="space-y-3 p-4">
                    <Alert variant="error" title="Не вдалося завантажити дані">
                        {error || menuError || 'Сталася помилка. Спробуйте ще раз.'}
                    </Alert>
                    <div className="flex flex-wrap gap-2">
                        <Button onClick={onRetry}>Спробувати ще раз</Button>
                    </div>
                </Card>
            ) : null}

            {!hasBlockingError && state === 'loading' ? (
                <Card className="p-4">
                    <div className="text-sm text-text-muted">Завантаження списку продуктів…</div>
                </Card>
            ) : null}

            {!hasBlockingError && state === 'not_found' && menuState === 'not_found' ? (
                <Alert title="Меню ще не згенероване">
                    Для цього тижня ще немає меню, тому список продуктів теж відсутній.
                    <div className="mt-3 flex flex-wrap gap-2">
                        <Link href={weeklyMenuHref}>
                            <Button variant="secondary">Перейти до плану тижня</Button>
                        </Link>
                    </div>
                </Alert>
            ) : null}

            {!hasBlockingError && state === 'not_found' && menuState === 'ready' && menu?.status !== 'APPROVED' ? (
                <Alert variant="warning" title="Меню не підтверджено">
                    Підтвердьте меню для цього тижня, щоб створити список продуктів.
                    <div className="mt-3 flex flex-wrap gap-2">
                        <Link href={weeklyMenuHref}>
                            <Button variant="secondary">Відкрити план тижня</Button>
                        </Link>
                    </div>
                </Alert>
            ) : null}

            {!hasBlockingError && canCreate ? (
                <Alert title="Список ще не створено">
                    Для цього тижня вже є підтверджене меню. Створіть список продуктів і працюйте з ним тут же.
                </Alert>
            ) : null}

            {!hasBlockingError && state === 'ready' ? (
                <>
                    <div className="flex flex-col gap-3 md:flex-row md:items-center md:gap-4">
                        <div className="min-w-0 flex-1">
                            <Input
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                placeholder="Пошук продуктів: молоко, помідори…"
                                disabled={saving}
                                aria-label="Пошук продуктів"
                                className="w-full"
                            />
                        </div>

                        <div className="md:ml-auto">
                            <div className="flex flex-col gap-2 sm:flex-row md:items-center md:justify-end">
                                <div className="sm:w-[240px] sm:shrink-0">
                                    <button
                                        type="button"
                                        onClick={() => setOnlyToBuy((prev) => !prev)}
                                        disabled={saving}
                                        aria-pressed={onlyToBuy}
                                        aria-label="Тільки купити"
                                        title="Показувати лише продукти, яких ще не вистачає"
                                        className={`flex w-full items-center justify-between gap-3 rounded-full border px-3 py-2 text-left transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-soft disabled:cursor-not-allowed disabled:opacity-60 ${onlyToBuy ? 'border-primary bg-primary-soft text-text-primary' : 'border-border bg-surface text-text-primary hover:bg-background'}`}
                                    >
                                        <span className="text-sm font-semibold">Тільки купити</span>

                                        <span
                                            className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${onlyToBuy ? 'bg-primary' : 'bg-border'}`}
                                            aria-hidden="true"
                                        >
                                            <span
                                                className={`absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-surface shadow-sm transition-transform ${onlyToBuy ? 'translate-x-5' : 'translate-x-0'}`}
                                            />
                                        </span>
                                    </button>
                                </div>

                                <Button
                                    variant="secondary"
                                    onClick={onDownloadPdf}
                                    disabled={!list || reportLoading}
                                    title="Завантажити список продуктів у PDF"
                                    className="sm:shrink-0"
                                >
                                    {reportLoading ? 'Генеруємо PDF…' : 'Завантажити PDF'}
                                </Button>
                            </div>
                        </div>
                    </div>

                    {list && list.items.length === 0 ? (
                        <Card className="p-4">
                            <div className="text-sm text-text-muted">Список продуктів порожній.</div>
                        </Card>
                    ) : null}

                    {list && list.items.length > 0 ? (
                        <div className="space-y-3">
                            {PRODUCT_CATEGORY_ORDER.map((category) => {
                                const items = grouped.get(category);
                                if (!items || items.length === 0) return null;

                                const isCollapsed = Boolean(collapsed[category]);
                                const toBuyCount = items.reduce((acc, item) => {
                                    const have = clampNumber(haveById[item.id] ?? 0);
                                    const needed = clampNumber(item.neededQuantity ?? 0);
                                    return acc + (needed - have > 0 ? 1 : 0);
                                }, 0);

                                const categoryHaveAll =
                                    items.length > 0 &&
                                    items.every((item) => {
                                        const needed = clampNumber(item.neededQuantity ?? 0);
                                        const have = clampNumber(haveById[item.id] ?? 0);
                                        return needed === 0 || have >= needed;
                                    });

                                return (
                                    <Card key={category} className="p-0">
                                        <CardHeader
                                            className="flex cursor-pointer flex-wrap items-center justify-between gap-2 px-4 py-2 select-none"
                                            role="button"
                                            tabIndex={0}
                                            aria-expanded={!isCollapsed}
                                            onClick={() => toggleCategory(category)}
                                            onKeyDown={(e) => {
                                                if (e.key === 'Enter' || e.key === ' ') {
                                                    e.preventDefault();
                                                    toggleCategory(category);
                                                }
                                            }}
                                        >
                                            <div className="flex min-w-0 items-center gap-2">
                                                <MaterialIcon
                                                    name={isCollapsed ? 'expand_circle_right' : 'expand_circle_down'}
                                                    className="text-[20px] text-text-muted"
                                                />

                                                <h2 className="truncate text-sm font-semibold text-text-primary">
                                                    {PRODUCT_CATEGORY_LABELS[category]}
                                                </h2>

                                                <div className="hidden flex-wrap items-center gap-2 sm:flex">
                                                    <Badge variant="info">Позицій: {items.length}</Badge>
                                                    <Badge variant="soft">Купити: {toBuyCount}</Badge>
                                                </div>
                                            </div>

                                            <div
                                                className="flex items-center gap-3"
                                                onClick={(e) => e.stopPropagation()}
                                                onKeyDown={(e) => e.stopPropagation()}
                                            >
                                                <div className="flex flex-wrap items-center gap-2 sm:hidden">
                                                    <Badge variant="info">Позицій: {items.length}</Badge>
                                                    <Badge variant="soft">Купити: {toBuyCount}</Badge>
                                                </div>

                                                <label className="inline-flex items-center gap-2 text-xs text-text-muted">
                                                    <input
                                                        type="checkbox"
                                                        className="h-4 w-4 accent-primary"
                                                        checked={categoryHaveAll}
                                                        onChange={(e) => {
                                                            if (e.target.checked) setHaveAllInCategory(category);
                                                            else clearHaveInCategory(category);
                                                        }}
                                                        disabled={saving}
                                                        aria-label="Є все вдома для категорії"
                                                    />
                                                    <span className="whitespace-nowrap">Є все</span>
                                                </label>
                                            </div>
                                        </CardHeader>

                                        {!isCollapsed ? (
                                            <CardContent className="p-0">
                                                <div className="max-w-full overflow-x-auto">
                                                    <table className="w-full min-w-[700px] border-collapse text-xs">
                                                        <thead className="hidden md:table-header-group">
                                                            <tr className="bg-primary-soft/60 text-[11px] uppercase tracking-[0.08em] text-text-muted">
                                                                <th className="px-2.5 py-1.5 text-left font-semibold">Продукт</th>
                                                                <th className="px-2.5 py-1.5 text-right font-semibold">Потрібно</th>
                                                                <th className="px-2.5 py-1.5 text-right font-semibold">Є вдома</th>
                                                                <th className="px-2.5 py-1.5 text-right font-semibold">Купити</th>
                                                                <th className="px-2.5 py-1.5 text-center font-semibold">Є все</th>
                                                            </tr>
                                                        </thead>

                                                        <tbody className="divide-y divide-border">
                                                            {items.map((item) => {
                                                                const have = clampNumber(haveById[item.id] ?? 0);
                                                                const needed = clampNumber(item.neededQuantity ?? 0);
                                                                const toBuy = clampNumber(needed - have);
                                                                const unitLabel = MEASUREMENT_UNIT_LABELS[item.unit] ?? item.unit;
                                                                const haveAll = needed > 0 && have >= needed;

                                                                return (
                                                                    <tr key={item.id} className="hover:bg-background/70">
                                                                        <td className="px-2.5 py-1.5">
                                                                            <div className="min-w-0">
                                                                                <div className="truncate text-sm font-medium text-text-primary">
                                                                                    {item.ingredientNameUk}
                                                                                </div>
                                                                                <div className="mt-0.5 text-[11px] text-text-muted md:hidden">
                                                                                    Потрібно {formatQty(needed)} {unitLabel}
                                                                                    <span className="px-1">•</span>
                                                                                    <span className={toBuy > 0 ? 'font-semibold text-text-primary' : ''}>
                                                                                        Купити {formatQty(toBuy)} {unitLabel}
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                        </td>

                                                                        <td className="hidden px-2.5 py-1.5 text-right md:table-cell">
                                                                            {formatQty(needed)} <span className="text-text-muted">{unitLabel}</span>
                                                                        </td>

                                                                        <td className="px-2.5 py-1.5">
                                                                            <div className="flex items-center justify-end gap-2">
                                                                                <Input
                                                                                    type="number"
                                                                                    inputMode="decimal"
                                                                                    value={String(have)}
                                                                                    onChange={(e) => setHave(item.id, e.target.value)}
                                                                                    className="h-7 w-[68px] text-xs"
                                                                                    disabled={saving}
                                                                                    aria-label="Є вдома"
                                                                                />
                                                                                <span className="text-[11px] text-text-muted">{unitLabel}</span>
                                                                            </div>
                                                                        </td>

                                                                        <td className="px-2.5 py-1.5 text-right">
                                                                            <span className={toBuy > 0 ? 'font-semibold text-text-primary' : 'text-text-muted'}>
                                                                                {formatQty(toBuy)}
                                                                            </span>{' '}
                                                                            <span className="text-text-muted">{unitLabel}</span>
                                                                        </td>

                                                                        <td className="px-2.5 py-1.5 text-center">
                                                                            <label className="inline-flex items-center justify-center">
                                                                                <input
                                                                                    type="checkbox"
                                                                                    className="h-4 w-4 accent-primary"
                                                                                    checked={haveAll}
                                                                                    onChange={(e) => setHaveAllForItem(item.id, needed, e.target.checked)}
                                                                                    disabled={saving || needed === 0}
                                                                                    aria-label="Є все вдома для продукту"
                                                                                />
                                                                            </label>
                                                                        </td>
                                                                    </tr>
                                                                );
                                                            })}
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </CardContent>
                                        ) : null}
                                    </Card>
                                );
                            })}
                        </div>
                    ) : null}
                </>
            ) : null}
        </div>
    );
}










