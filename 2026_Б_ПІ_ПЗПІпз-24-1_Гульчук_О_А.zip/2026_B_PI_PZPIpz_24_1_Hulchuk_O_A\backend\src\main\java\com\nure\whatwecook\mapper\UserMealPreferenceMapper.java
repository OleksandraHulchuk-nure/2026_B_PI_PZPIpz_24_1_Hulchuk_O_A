package com.nure.whatwecook.mapper;

import com.nure.whatwecook.domain.entity.profile.UserMealPreference;
import com.nure.whatwecook.dto.preferences.MealTimePreferenceDto;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface UserMealPreferenceMapper {

    MealTimePreferenceDto toDto(UserMealPreference entity);

    UserMealPreference toEntity(MealTimePreferenceDto dto);

    List<MealTimePreferenceDto> toDtoList(List<UserMealPreference> entities);

    List<UserMealPreference> toEntityList(List<MealTimePreferenceDto> dtos);
}
