package com.nure.whatwecook.service.helper.pdf;

import com.nure.whatwecook.service.reports.pdf.ReportLabels;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Service
@RequiredArgsConstructor
public class PdfTemplatePipeline {

    private final TemplateEngine templateEngine;
    private final PdfHtmlToPdfConverter converter;
    private final ReportLabels labels;

    public byte[] render(PdfRenderRequest req) {
        Context ctx = new Context(req.locale());
        req.model().forEach(ctx::setVariable);

        ctx.setVariable("labels", labels);

        String html = templateEngine.process(req.templateName(), ctx);
        return converter.convert(html, req.baseUri());
    }
}
