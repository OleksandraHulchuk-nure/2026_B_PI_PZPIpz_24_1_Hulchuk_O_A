import type { Config } from 'tailwindcss';

const config: Config = {
    content: [
        './app/**/*.{js,ts,jsx,tsx,mdx}',
        './components/**/*.{js,ts,jsx,tsx,mdx}',
    ],
    theme: {
        extend: {
            colors: {
                primary: 'var(--color-primary)',
                'primary-soft': 'var(--color-primary-soft)',

                secondary: 'var(--color-secondary)',

                background: 'var(--color-background)',
                surface: 'var(--color-surface)',
                border: 'var(--color-border)',

                text: {
                    primary: 'var(--color-text-primary)',
                    muted: 'var(--color-text-muted)',
                    inverted: 'var(--color-text-inverted)',
                },

                accent: {
                    DEFAULT: 'var(--color-accent)',
                    warm: 'var(--color-accent-warm)',
                    ai: 'var(--color-accent-ai)',
                    info: 'var(--color-accent-info)',
                    'soft-warm': 'var(--color-accent-soft-warm)',
                    'soft-ai': 'var(--color-accent-soft-ai)',
                },

                success: 'var(--color-success)',
                warning: 'var(--color-warning)',
                error: 'var(--color-error)',
            },
            boxShadow: {
                card: '0 4px 12px rgba(0,0,0,0.04)',
                header: '0 6px 16px rgba(0,0,0,0.04)',
            },
            borderRadius: {
                xl: '0.75rem',
                '2xl': '1rem',
            },
        },
    },
    plugins: [],
};

export default config;
