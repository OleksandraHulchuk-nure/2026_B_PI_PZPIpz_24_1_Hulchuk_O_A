import {apiFetchBlob} from "@/lib/api/apiClient";
import {API_ROUTES} from "@/lib/api/endpoints";

export async function downloadWeeklyMenuReport(weeklyMenuId: string) {
    return apiFetchBlob(`${API_ROUTES.reports.weeklyMenu}/${weeklyMenuId}`, {
        method: 'GET',
        headers: {Accept: 'application/pdf'},
    });
}

export async function downloadShoppingListReport(shoppingListId: string) {
    return apiFetchBlob(`${API_ROUTES.reports.shoppingList}/${shoppingListId}`, {
        method: 'GET',
        headers: {Accept: 'application/pdf'},
    });
}
