package com.nure.whatwecook.mapper;

import com.nure.whatwecook.dto.ingredient.AggregatedIngredientDto;
import com.nure.whatwecook.service.aggregation.AggregatedIngredient;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import java.util.Collection;
import java.util.List;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface AggregatedIngredientMapper {

    @Mapping(target = "ingredientId", source = "ingredient.id")
    @Mapping(target = "ingredientNameUk", source = "ingredient.nameUk")
    @Mapping(target = "category", source = "ingredient.category")
    AggregatedIngredientDto toDto(AggregatedIngredient aggregatedIngredient);

    List<AggregatedIngredientDto> toDtoList(Collection<AggregatedIngredient> aggregatedIngredients);
}
