package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.menu.WeeklyMenu;
import com.nure.whatwecook.domain.enums.MenuStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface WeeklyMenuRepository extends JpaRepository<WeeklyMenu, UUID> {

    List<WeeklyMenu> findByUserIdOrderByStartDateDesc(UUID userId);

    Optional<WeeklyMenu> findFirstByUserIdOrderByStartDateDesc(UUID userId);

    Optional<WeeklyMenu> findByUserIdAndStartDate(UUID userId, LocalDate startDate);

    List<WeeklyMenu> findByUserIdAndStatusOrderByStartDateDesc(UUID userId, MenuStatus status);

    Optional<WeeklyMenu> findByIdAndUserId(UUID id, UUID userId);

    @Query("""
        select distinct mm.recipe.id
        from WeeklyMenu wm
        join wm.days d
        join d.meals mm
        where wm.user.id = :userId
          and wm.startDate >= :fromStart
          and wm.startDate < :toStart
          and wm.status = :status
          and mm.recipe is not null
    """)
    List<UUID> findUsedRecipeIds(@Param("userId") UUID userId,
                                 @Param("fromStart") LocalDate fromStart,
                                 @Param("toStart") LocalDate toStart,
                                 @Param("status") MenuStatus status);
}
