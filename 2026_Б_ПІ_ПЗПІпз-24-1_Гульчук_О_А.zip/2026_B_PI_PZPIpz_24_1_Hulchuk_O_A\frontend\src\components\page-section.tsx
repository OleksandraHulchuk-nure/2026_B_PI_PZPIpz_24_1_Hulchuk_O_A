﻿import * as React from 'react';

import {cn} from '@/lib/utils';

type TitleAs = 'h1' | 'h2' | 'h3';

export interface PageSectionProps {
    title: string;
    subtitle?: string;
    titleAs?: TitleAs;
    className?: string;
    titleAddon?: React.ReactNode;
    actions?: React.ReactNode;
    children?: React.ReactNode;
}

export function PageSection({
    title,
    subtitle,
    titleAs = 'h2',
    className,
    titleAddon,
    actions,
    children,
}: PageSectionProps) {
    const TitleTag = titleAs;
    const isPageHeader = titleAs === 'h1';
    const titleClassName = isPageHeader ? 'page-title' : 'section-title';

    return (
        <section className={cn('flex flex-col gap-3', className)}>
            <div
                className={cn(
                    'border-b border-border/70',
                    isPageHeader ? 'pb-4' : 'pb-3',
                )}
            >
                <div
                    className={cn(
                        'flex flex-col gap-3',
                        actions ? 'lg:flex-row lg:items-start lg:justify-between' : '',
                    )}
                >
                    <div className="min-w-0 flex-1 space-y-1.5">
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
                            <TitleTag className={cn('min-w-0 text-balance', titleClassName)}>{title}</TitleTag>
                            {titleAddon ? <div className="flex flex-wrap items-center gap-2">{titleAddon}</div> : null}
                        </div>

                        {subtitle ? <p className="section-subtitle max-w-2xl">{subtitle}</p> : null}
                    </div>

                    {actions ? (
                        <div className="flex flex-wrap items-center gap-2 lg:shrink-0 lg:justify-end">
                            {actions}
                        </div>
                    ) : null}
                </div>
            </div>

            {children ? children : null}
        </section>
    );
}
