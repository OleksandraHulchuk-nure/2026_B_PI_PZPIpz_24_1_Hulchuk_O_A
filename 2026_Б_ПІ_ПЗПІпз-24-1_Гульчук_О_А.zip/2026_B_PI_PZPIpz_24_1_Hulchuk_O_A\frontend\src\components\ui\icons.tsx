import * as React from "react";

export function ImageUploadIcon(props: React.SVGProps<SVGSVGElement>) {
    return (
        <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            {...props}
        >
            <rect x="3" y="5" width="18" height="14" rx="2"/>
            <path d="M8 13l2-2 4 4 2-2 3 3"/>
            <path d="M9 9h.01"/>
            <path d="M12 14V9"/>
            <path d="M10.5 10.5L12 9l1.5 1.5"/>
        </svg>
    );
}
