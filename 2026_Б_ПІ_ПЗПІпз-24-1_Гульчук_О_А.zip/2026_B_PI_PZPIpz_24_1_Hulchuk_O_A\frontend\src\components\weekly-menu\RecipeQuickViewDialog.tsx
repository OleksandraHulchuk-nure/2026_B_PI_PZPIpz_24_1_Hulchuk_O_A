'use client';

import * as React from 'react';

import Modal from '@/components/ui/modal';
import {Badge} from '@/components/ui/badge';
import {Button} from '@/components/ui/button';
import {MaterialIcon} from '@/components/ui/materialIcon';
import StarRating from '@/components/ui/star-rating';

import {getIngredientById} from '@/lib/api/ingredientApi';
import {getRecipe, getRecipeImageBlob, type RecipeDetailsDto} from '@/lib/api/recipeApi';
import {
    MEAL_TYPE_LABELS, mealTypeBadgeVariant,
    MENU_TYPE_ICONS,
    MENU_TYPE_LABELS,
    menuTypeBadgeVariant,
    RECIPE_SOURCE_ICONS,
    RECIPE_SOURCE_LABELS,
    RECIPE_STATUS_ICONS,
    RECIPE_STATUS_LABELS,
    recipeSourceBadgeVariant,
    recipeStatusBadgeVariant,
} from '@/lib/constants/enums';
import {formatQty, normalizeSteps} from '@/lib/recipes/format';
import {getUnitLabel} from '@/lib/recipes/labels';
import {cn} from '@/lib/utils';

export function RecipeQuickViewDialog({
                                          open,
                                          recipeId,
                                          onClose,
                                      }: {
    open: boolean;
    recipeId: string | null;
    onClose: () => void;
}) {
    const [recipe, setRecipe] = React.useState<RecipeDetailsDto | null>(null);
    const [ingredientNames, setIngredientNames] = React.useState<Record<string, string>>({});
    const ingredientNamesRef = React.useRef<Record<string, string>>({});
    const [imageUrl, setImageUrl] = React.useState<string | null>(null);
    const [loading, setLoading] = React.useState(false);
    const [error, setError] = React.useState<string | null>(null);
    const [refreshKey, setRefreshKey] = React.useState(0);

    React.useEffect(() => {
        ingredientNamesRef.current = ingredientNames;
    }, [ingredientNames]);

    React.useEffect(() => {
        if (!open || !recipeId) return;

        let active = true;
        setLoading(true);
        setError(null);
        setRecipe(null);
        setImageUrl((prev) => {
            if (prev) URL.revokeObjectURL(prev);
            return null;
        });

        const fetchData = async () => {
            try {
                const data = await getRecipe(recipeId);
                if (!active) return;
                setRecipe(data);

                const ingredientIds = Array.from(new Set((data.ingredients ?? []).map((ing) => ing.ingredientId)));
                const missing = ingredientIds.filter((id) => !ingredientNamesRef.current[id]);

                if (missing.length) {
                    const pairs = await Promise.all(
                        missing.map(async (id) => {
                            try {
                                const ing = await getIngredientById(id);
                                return [id, ing.name] as const;
                            } catch {
                                return [id, id.slice(0, 8)] as const;
                            }
                        }),
                    );

                    if (!active) return;
                    setIngredientNames((prev) => {
                        const next = {...prev};
                        for (const [id, nm] of pairs) next[id] = nm;
                        return next;
                    });
                }

                try {
                    const blob = await getRecipeImageBlob(recipeId);
                    if (!active) return;
                    if (blob) {
                        const url = URL.createObjectURL(blob);
                        setImageUrl((prev) => {
                            if (prev) URL.revokeObjectURL(prev);
                            return url;
                        });
                    } else {
                        setImageUrl((prev) => {
                            if (prev) URL.revokeObjectURL(prev);
                            return null;
                        });
                    }
                } catch {
                    if (!active) return;
                    setImageUrl((prev) => {
                        if (prev) URL.revokeObjectURL(prev);
                        return null;
                    });
                }
            } catch (e) {
                if (!active) return;
                setRecipe(null);
                setError(e instanceof Error ? e.message : 'Не вдалося завантажити рецепт.');
            } finally {
                if (active) setLoading(false);
            }
        };

        void fetchData();

        return () => {
            active = false;
        };
    }, [open, recipeId, refreshKey]);

    React.useEffect(() => () => {
        if (imageUrl) URL.revokeObjectURL(imageUrl);
    }, [imageUrl]);

    const steps = normalizeSteps(recipe?.steps, recipe?.description);

    return (
        <Modal
            open={open}
            title={recipe?.name ?? 'Рецепт'}
            onClose={onClose}
        >
            {loading ? (
                <div className="text-sm text-text-muted">Завантажуємо дані рецепту…</div>
            ) : error ? (
                <div className="space-y-2 text-sm">
                    <div className="text-error">{error}</div>
                    <div className="flex items-center gap-0.5">
                        <Button variant="secondary" onClick={() => setRefreshKey((v) => v + 1)}>
                            Спробувати ще раз
                        </Button>
                        <Button variant="ghost" onClick={onClose}>
                            Закрити
                        </Button>
                    </div>
                </div>
            ) : recipe ? (
                <div className="space-y-2">
                    <div className="flex flex-col gap-1 md:flex-row">
                        <div className="flex-shrink-0">
                            {imageUrl ? (
                                // eslint-disable-next-line @next/next/no-img-element
                                <img
                                    src={imageUrl}
                                    alt={recipe.name}
                                    className="h-28 w-40 rounded-xl object-cover"
                                />
                            ) : (
                                <div
                                    className="flex h-28 w-40 items-center justify-center rounded-xl border border-dashed border-border bg-muted text-xs text-text-muted"
                                    aria-label="Зображення рецепту відсутнє"
                                >
                                    Без фото
                                </div>
                            )}
                        </div>

                        <div className="min-w-0 flex-1 space-y-2">
                            <div className="flex flex-wrap items-center gap-2">
                                {recipe.status ? (
                                    <Badge variant={recipeStatusBadgeVariant(recipe.status)}
                                           className="flex items-center gap-1">
                                        <MaterialIcon name={RECIPE_STATUS_ICONS[recipe.status]}
                                                      label={RECIPE_STATUS_LABELS[recipe.status]}/>
                                        {RECIPE_STATUS_LABELS[recipe.status]}
                                    </Badge>
                                ) : null}

                                {recipe.sourceType ? (
                                    <Badge variant={recipeSourceBadgeVariant(recipe.sourceType)}
                                           className="flex items-center gap-1">
                                        <MaterialIcon name={RECIPE_SOURCE_ICONS[recipe.sourceType]}
                                                      label={RECIPE_SOURCE_LABELS[recipe.sourceType]}/>
                                        {RECIPE_SOURCE_LABELS[recipe.sourceType]}
                                    </Badge>
                                ) : null}

                                {recipe.menuType ? (
                                    <Badge variant={menuTypeBadgeVariant(recipe.menuType)}
                                           className="flex items-center gap-1">
                                        <MaterialIcon name={MENU_TYPE_ICONS[recipe.menuType]}
                                                      label={MENU_TYPE_LABELS[recipe.menuType]}/>
                                        {MENU_TYPE_LABELS[recipe.menuType]}
                                    </Badge>
                                ) : null}

                                {recipe.mealType ? (
                                    <Badge variant={mealTypeBadgeVariant(recipe.mealType)}>{MEAL_TYPE_LABELS[recipe.mealType]}</Badge>
                                ) : null}
                            </div>

                            <div className="flex flex-wrap items-center gap-3 text-sm text-text-muted">
                                <span
                                    className="inline-flex items-center gap-1 rounded-full border border-border bg-background px-3 py-1 text-xs whitespace-nowrap">
                                        <span className="text-text-muted">⏱</span>
                                        <span className="tabular-nums font-semibold text-text-primary">
                                          {(recipe.activeCookingTimeMinutes ?? '—')}/{(recipe.totalTimeMinutes ?? '—')}
                                        </span>
                                        <span className="text-text-muted">хв</span>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 mt-2">
                        <div className="flex flex-wrap items-center gap-1 text-sm">
                            {typeof recipe.complexityRating === 'number' ? (
                                <div className="flex items-center gap-2">
                                    <span className="text-text-muted">Складність:</span>
                                    <StarRating value={Math.round(recipe.complexityRating)} disabled size="sm"/>
                                </div>
                            ) : null}
                            {typeof recipe.tasteRating === 'number' ? (
                                <div className="flex items-center gap-2">
                                    <span className="text-text-muted">Смак:</span>
                                    <StarRating value={Math.round(recipe.tasteRating)} disabled size="sm"/>
                                </div>
                            ) : null}
                        </div>
                    </div>

                    <div className="grid gap-3 md:grid-cols-2">
                        <div className="space-y-2">
                            <h4 className="text-sm font-semibold text-text-primary">Інгредієнти - Порції: {recipe.defaultServings ?? '—'}</h4>
                            {recipe.ingredients?.length ? (
                                <ul className="space-y-1">
                                    {recipe.ingredients.map((ing, idx) => (
                                        <li
                                            key={`${ing.ingredientId}-${idx}`}
                                            className="flex items-start justify-between gap-0.5 rounded-xl border border-border bg-background px-1 py-1 text-sm"
                                        >
                                            <div className="min-w-0">
                                                <div className="truncate font-medium">
                                                    {ingredientNames[ing.ingredientId] ?? ing.ingredientId.slice(0, 8)}
                                                    {ing.optional ? (
                                                        <span
                                                            className="ml-2 text-xs font-normal text-text-muted">(опційно)</span>
                                                    ) : null}
                                                </div>
                                            </div>
                                            <div className="shrink-0 text-text-muted">
                                                {formatQty(ing.quantity)} {getUnitLabel(ing.unit)}
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <div className="text-sm text-text-muted">Інгредієнти не вказані.</div>
                            )}
                        </div>

                        <div className="space-y-2">
                            <h4 className="text-sm font-semibold text-text-primary">Кроки</h4>
                            {steps.length ? (
                                <ol className="space-y-2 text-sm">
                                    {steps.map((s, idx) => (
                                        <li
                                            key={idx}
                                            className={cn(
                                                'rounded-xl border border-border bg-background px-1 py-1',
                                                'flex items-start gap-0.5'
                                            )}
                                        >
                                            <span
                                                className="mt-0.5 text-xs font-semibold text-text-muted">{idx + 1}.</span>
                                            <span className="text-text-primary">{s}</span>
                                        </li>
                                    ))}
                                </ol>
                            ) : (
                                <div className="text-sm text-text-muted">Кроки не вказані.</div>
                            )}
                        </div>
                    </div>
                </div>
            ) : (
                <div className="text-sm text-text-muted">Оберіть рецепт для перегляду.</div>
            )}
        </Modal>
    );
}
