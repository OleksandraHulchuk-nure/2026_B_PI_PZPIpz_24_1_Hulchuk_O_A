package com.nure.whatwecook.dto.ai;

import lombok.Data;

@Data
public class GenerateAiMenuSlotRequestDto {

    /**
     * Максимальний бажаний час приготування (хв).
     * Може бути null – тоді беремо з профілю / налаштувань або не обмежуємо.
     */
    private Integer maxTimeMinutes;

    /**
     * Додаткові побажання до AI (наприклад, "менше посуду", "без грибів", тощо).
     */
    private String extraNotes;
}
