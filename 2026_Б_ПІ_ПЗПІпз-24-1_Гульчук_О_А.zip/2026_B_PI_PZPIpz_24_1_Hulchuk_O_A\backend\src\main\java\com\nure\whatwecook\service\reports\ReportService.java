package com.nure.whatwecook.service.reports;

import com.nure.whatwecook.service.helper.pdf.PdfDocument;
import com.nure.whatwecook.service.reports.pdf.PdfReportRegistry;
import com.nure.whatwecook.service.reports.pdf.PdfReportType;
import com.nure.whatwecook.service.reports.pdf.request.WeeklyMenuPdfRequest;
import com.nure.whatwecook.service.reports.pdf.request.WeeklyShoppingListPdfRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final PdfReportRegistry pdfReports;

    public PdfDocument generateWeeklyMenuPdf(UUID userId, UUID weeklyMenuId) {
        return pdfReports.generate(PdfReportType.WEEKLY_MENU,
                new WeeklyMenuPdfRequest(userId, weeklyMenuId));
    }

    public PdfDocument generateWeeklyShoppingListPdf(UUID userId, UUID shoppingListId) {
        return pdfReports.generate(PdfReportType.WEEKLY_SHOPPING_LIST,
                new WeeklyShoppingListPdfRequest(userId, shoppingListId));
    }
}
