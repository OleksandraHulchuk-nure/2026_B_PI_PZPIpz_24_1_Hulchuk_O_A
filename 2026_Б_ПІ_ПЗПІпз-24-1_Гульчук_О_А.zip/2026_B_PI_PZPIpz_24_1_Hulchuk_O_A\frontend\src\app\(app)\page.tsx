'use client';

import {useEffect, useMemo, useState} from 'react';
import {useRouter} from 'next/navigation';

import {Alert} from '@/components/ui/alert';
import {Badge} from '@/components/ui/badge';
import {Button} from '@/components/ui/button';
import {Card} from '@/components/ui/card';
import {MaterialIcon} from '@/components/ui/materialIcon';
import Modal from '@/components/ui/modal';
import {PageSection} from '@/components/page-section';
import {RecipeQuickViewDialog} from '@/components/weekly-menu/RecipeQuickViewDialog';

import * as weeklyMenuApi from '@/lib/api/weeklyMenuApi';
import * as ingredientApi from '@/lib/api/ingredientApi';
import {AggregatedIngredientDto} from '@/lib/api/ingredientApi';
import {ApiError} from '@/lib/api/apiClient';
import {formatUkDateShort, formatUkDayShort, startOfWeek, toIsoDate} from '@/lib/utils/date';
import {
    MEAL_TYPE_LABELS,
    MEAL_TYPES,
    MealType,
    MEASUREMENT_UNIT_LABELS,
    MENU_STATUS_LABELS,
    MENU_TYPE_ICONS,
    MENU_TYPE_LABELS,
    menuStatusBadgeVariant,
    menuTypeBadgeVariant,
    RECIPE_SOURCE_ICONS,
    RECIPE_SOURCE_LABELS,
    RECIPE_STATUS_ICONS,
    RECIPE_STATUS_LABELS,
    recipeSourceBadgeVariant,
    recipeStatusBadgeVariant,
} from '@/lib/constants/enums';

const MEAL_ORDER: MealType[] = ['BREAKFAST', 'LUNCH', 'DINNER', 'SNACK'];

const INGREDIENTS_LIST_SIZE = 8;

type UiStatus = 'idle' | 'loading' | 'error' | 'success';

export default function HomePage() {
    const router = useRouter();

    const todayIso = useMemo(() => toIsoDate(new Date()), []);
    const weekStart = useMemo(() => toIsoDate(startOfWeek(new Date())), []);

    const [menuLoading, setMenuLoading] = useState<boolean>(true);
    const [menuError, setMenuError] = useState<string>('');
    const [menu, setMenu] = useState<weeklyMenuApi.WeeklyMenuResponseDto | null>(null);

    const [actionStatus, setActionStatus] = useState<UiStatus>('idle');
    const [actionMessage, setActionMessage] = useState<string>('');

    const [todaysIngredients, setTodaysIngredients] = useState<AggregatedIngredientDto[]>([]);
    const [todaysIngredientsLoading, setTodaysIngredientsLoading] = useState<boolean>(true);
    const [todaysIngredientsError, setTodaysIngredientsError] = useState<string>('');
    const [ingredientsModalOpen, setIngredientsModalOpen] = useState<boolean>(false);

    const [previewRecipeId, setPreviewRecipeId] = useState<string | null>(null);
    const [previewOpen, setPreviewOpen] = useState<boolean>(false);


    const isBusy = actionStatus === 'loading';

    useEffect(() => {
        let active = true;

        setMenuError('');
        setMenu(null);

        weeklyMenuApi
            .getWeeklyMenuByStartDate(weekStart)
            .then((data) => {
                if (!active) return;
                setMenu(data);
            })
            .catch((e) => {
                if (!active) return;

                if (e instanceof ApiError && e.status === 404) {
                    setMenu(null);
                    return;
                }

                setMenuError(e instanceof Error ? e.message : 'Не вдалося завантажити меню цього тижня.');
            })
            .finally(() => {
                if (!active) return;
                setMenuLoading(false);
            });

        return () => {
            active = false;
        };
    }, [weekStart]);

    useEffect(() => {
        let active = true;

        ingredientApi
            .getAggregatedIngredientsByDate(todayIso)
            .then((data) => {
                if (!active) return;
                setTodaysIngredients(data);
            })
            .catch((e) => {
                if (!active) return;
                setTodaysIngredientsError(
                    e instanceof Error ? e.message : 'Не вдалося завантажити інгредієнти.',
                );
            })
            .finally(() => {
                if (!active) return;
                setTodaysIngredientsLoading(false);
            });

        return () => {
            active = false;
        };
    }, [todayIso]);

    async function handleGenerateMenu() {
        setActionStatus('loading');
        setActionMessage('');
        try {
            const data = await weeklyMenuApi.generateWeeklyMenu({
                startDate: weekStart,
                days: 7,
                mealsPerDay: MEAL_TYPES,
                useProfilePreferences: true,
            });
            setMenu(data);
            setActionMessage('Меню згенеровано.');
            setActionStatus('success');
        } catch (e) {
            setActionStatus('error');
            setActionMessage(e instanceof Error ? e.message : 'Не вдалося згенерувати меню.');
        }
    }

    async function handleApproveMenu() {
        if (!menu) return;
        setActionStatus('loading');
        setActionMessage('');
        try {
            const approved = await weeklyMenuApi.approveWeeklyMenu(menu.id);
            setMenu(approved);
            setActionMessage('Меню підтверджено.');
            setActionStatus('success');
        } catch (e) {
            setActionStatus('error');
            setActionMessage(e instanceof Error ? e.message : 'Не вдалося підтвердити меню.');
        }
    }

    function openRecipe(recipeId: string) {
        setPreviewRecipeId(recipeId);
        setPreviewOpen(true);
    }

    function goToWeeklyMenu() {
        router.push(`/weekly-menu`);
    }

    const highlightedDay = useMemo(() => {
        if (!menu?.days?.length) return null;
        const today = menu.days.find((d) => d.date === todayIso);
        return today ?? menu.days[0];
    }, [menu, todayIso]);

    const highlightedMeals = useMemo(() => {
        if (!highlightedDay) return [];
        return MEAL_ORDER.map((mealType) => ({
            mealType,
            slot: highlightedDay.meals.find((m) => m.mealType === mealType) ?? null,
        }));
    }, [highlightedDay]);

    const menuStats = useMemo(() => {
        if (!menu?.days?.length) {
            return {meals: 0, verified: 0, toVerify: 0};
        }

        let meals = 0;
        let verified = 0;
        let toVerify = 0;

        for (const day of menu.days) {
            meals += day.meals.length;
            for (const meal of day.meals) {
                if (meal.recipe?.status === 'VERIFIED') verified += 1;
                if (meal.recipe?.status === 'TO_VERIFY') toVerify += 1;
            }
        }

        return {meals, verified, toVerify};
    }, [menu]);

    const formatIngredientQuantity = (value: number) =>
        new Intl.NumberFormat('uk-UA', {
            maximumFractionDigits: 2,
            minimumFractionDigits: value % 1 === 0 ? 0 : 1,
        }).format(value);

    const renderIngredientsList = (ingredients: AggregatedIngredientDto[]) => (
        <div className="flex flex-col gap-1">
            {ingredients.map((ingredient, index) => {
                const ingredientLabel = ingredient.ingredientNameUk ?? ingredient.nameUk;
                const ingredientKey = ingredient.id ?? `${ingredientLabel ?? 'ingredient'}-${ingredient.unit}-${index}`;

                return (
                    <div
                        key={ingredientKey}
                        className="flex items-center justify-between"
                    >
                        <span className="text-sm font-medium text-text-primary">{ingredientLabel}</span>
                        <span className="text-sm font-semibold text-text-primary">
                            {formatIngredientQuantity(ingredient.quantity)} {MEASUREMENT_UNIT_LABELS[ingredient.unit]}
                        </span>
                    </div>
                );
            })}
        </div>
    );

    const dayLabel = highlightedDay
        ? new Intl.DateTimeFormat('uk-UA', {weekday: 'long', day: '2-digit', month: 'long'}).format(
            new Date(`${highlightedDay.date}T00:00:00`),
        )
        : '—';

    return (
        <div className="flex flex-col gap-6">
            <PageSection
                titleAs="h2"
                title="Головна"
                subtitle="Огляд тижня та ключові дії — усе поруч."
            />

            {menuError && (
                <Alert variant="error" title="Помилка меню">
                    {menuError}
                </Alert>
            )}

            {actionMessage && !menuError ? (
                <Alert variant="success" title="Готово">
                    {actionMessage}
                </Alert>
            ) : null}

            <div className="grid gap-5 xl:grid-cols-[minmax(0,2fr)_minmax(0,1.2fr)]">
                <Card className="p-4">
                    <div className="mb-3 flex items-start justify-between gap-3">
                        <div>
                            <p className="text-base font-semibold">Сьогодні • {dayLabel}</p>
                            <p className="mt-1 text-xs text-text-muted">
                                Страви для поточного дня. Натисніть на рецепт, щоб побачити деталі.
                            </p>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                            {menu ? (
                                <Badge variant={menuStatusBadgeVariant(menu.status)}>
                                    {MENU_STATUS_LABELS[menu.status]}
                                </Badge>
                            ) : (
                                <Badge variant="secondary">Чернетка</Badge>
                            )}
                        </div>
                    </div>

                    {menuLoading ? (
                        <div className="text-sm text-text-muted">Завантажуємо меню для цього тижня…</div>
                    ) : !highlightedDay ? (
                        <div className="text-sm text-text-muted">Меню ще не згенеровано. Створіть його, щоб побачити
                            страви.</div>
                    ) : (
                        <div className="mb-4 flex flex-col gap-2 text-sm">
                            {highlightedMeals.map(({mealType, slot}) => (
                                <div key={mealType} className="flex flex-col gap-1">
                                    <div className="flex items-center justify-between gap-2">
                                        <button
                                            type="button"
                                            onClick={() => slot?.recipeId && openRecipe(slot.recipeId)}
                                            className="truncate text-left text-sm font-medium text-text-primary hover:text-primary cursor-pointer"
                                            disabled={!slot?.recipeId}
                                        >
                                            <span className="text-text-muted">{MEAL_TYPE_LABELS[mealType]}: </span>
                                            {slot?.recipe?.name ?? '—'}
                                        </button>

                                        <div className="flex flex-wrap items-center gap-2">
                                            {slot?.recipe?.status && (
                                                <MaterialIcon
                                                    name={RECIPE_STATUS_ICONS[slot?.recipe?.status]}
                                                    variant={recipeStatusBadgeVariant(slot?.recipe?.status)}
                                                    label={RECIPE_STATUS_LABELS[slot?.recipe?.status]}
                                                    className="text-[18px]"
                                                />
                                            )}

                                            {slot?.recipe?.sourceType && (
                                                <MaterialIcon
                                                    name={RECIPE_SOURCE_ICONS[slot?.recipe?.sourceType]}
                                                    variant={recipeSourceBadgeVariant(slot?.recipe?.sourceType)}
                                                    label={RECIPE_SOURCE_LABELS[slot?.recipe?.sourceType]}
                                                    className="text-[18px]"
                                                />
                                            )}

                                            {slot?.recipe?.menuType && (
                                                <MaterialIcon
                                                    name={MENU_TYPE_ICONS[slot?.recipe?.menuType]}
                                                    variant={menuTypeBadgeVariant(slot?.recipe?.menuType)}
                                                    label={MENU_TYPE_LABELS[slot?.recipe?.menuType]}
                                                    className="text-[18px]"
                                                />
                                            )}
                                        </div>

                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </Card>

                <Card className="flex h-full flex-col gap-3 p-4">
                    <div className="flex items-start justify-between gap-3">
                        <div>
                            <p className="text-base font-semibold">Інгредієнти на сьогодні</p>
                            <p className="mt-1 text-xs text-text-muted">
                                Натисніть на деталі щоб побачити повний список.
                            </p>
                        </div>

                        {todaysIngredients.length > INGREDIENTS_LIST_SIZE ? (
                            <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setIngredientsModalOpen(true)}
                                className="px-2"
                            >
                                Деталі
                            </Button>
                        ) : null}
                    </div>

                    <div className="space-y-2 text-sm">
                        {todaysIngredientsLoading ? (
                            <div className="text-text-muted">Завантажуємо інгредієнти…</div>
                        ) : todaysIngredientsError ? (
                            <Alert variant="error" title="Не вдалося завантажити інгредієнти">
                                {todaysIngredientsError}
                            </Alert>
                        ) : todaysIngredients.length ? (
                            <>
                                {renderIngredientsList(todaysIngredients.slice(0, INGREDIENTS_LIST_SIZE))}
                            </>
                        ) : (
                            <div className="text-xs text-text-muted">
                                Список інгредієнтів з’явиться після генерації меню на сьогодні.
                            </div>
                        )}
                    </div>

                    <div className="mt-auto flex flex-wrap gap-2">
                        {!menu ? (
                            <Button variant="primary" onClick={handleGenerateMenu} disabled={isBusy}>
                                Згенерувати меню
                            </Button>
                        ) : menu.status === 'DRAFT' ? (
                            <>
                                <Button variant="primary" onClick={handleGenerateMenu} disabled={isBusy}>
                                    Оновити меню
                                </Button>
                                <Button variant="secondary" onClick={handleApproveMenu} disabled={isBusy}>
                                    Підтвердити
                                </Button>
                            </>
                        ) : (
                            <>
                            </>
                        )}
                    </div>
                </Card>
            </div>

            <Card className="p-4">
                <PageSection
                    title="План на тиждень"
                    titleAddon={
                        <div className="flex flex-wrap gap-2">
                            <Badge variant="info">
                                <span>Страв: </span> {menuStats.meals ?? '—'}
                            </Badge>
                            <Badge variant="status">
                                <span>Перевірені: </span> {menuStats.verified ?? '—'}
                            </Badge>
                            <Badge variant="warm">
                                <span>Не тестовані: </span> {menuStats.toVerify ?? '—'}
                            </Badge>
                        </div>
                    }
                    actions={
                        <div className="flex flex-wrap gap-2">
                            <Button variant="primary" onClick={() => goToWeeklyMenu()}>Перейти до плану</Button>
                        </div>
                    }
                />

                {menuLoading ? (
                    <div className="text-sm text-text-muted">Завантажуємо меню для вибраного тижня…</div>
                ) : !menu ? (
                    <div className="text-sm text-text-muted">Ще немає меню. Згенеруйте його, щоб побачити план.</div>
                ) : (
                    <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                        {menu.days.map((day) => (
                            <div key={day.date}
                                 className="flex flex-col gap-2 rounded-xl border border-border bg-surface px-3 py-2">
                                <div className="flex items-center justify-between gap-2">
                                    <div>
                                        <div className="text-[11px] uppercase tracking-[0.06em] text-text-muted">
                                            {formatUkDayShort(day.date)}
                                        </div>
                                        <div className="text-[11px] text-text-muted">{formatUkDateShort(day.date)}</div>
                                    </div>
                                    <Badge variant="soft">{day.meals.length} страв(и)</Badge>
                                </div>
                                <div className="flex flex-col gap-1 text-xs">
                                    {day.meals.map((meal) => (
                                        <button
                                            key={meal.id}
                                            type="button"
                                            onClick={() => openRecipe(meal.recipeId)}
                                            className="truncate text-left text-text-primary hover:text-primary cursor-pointer"
                                        >
                                            <span className="text-text-muted">{MEAL_TYPE_LABELS[meal.mealType]}: </span>
                                            {typeof meal.recipe?.totalTimeMinutes === 'number' && (
                                                <span>⏱ {meal.recipe.totalTimeMinutes} хв</span>
                                            )}
                                            <br/>
                                            {meal.recipe?.name ?? '—'}
                                        </button>
                                    ))}
                                    {day.meals.length === 0 ?
                                        <span className="text-text-muted">Страви не додані</span> : null}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </Card>

            <RecipeQuickViewDialog
                open={previewOpen}
                recipeId={previewRecipeId}
                onClose={() => {
                    setPreviewOpen(false);
                    setPreviewRecipeId(null);
                }}
            />

            <Modal
                open={ingredientsModalOpen}
                title={`Усі інгредієнти на ${formatUkDateShort(todayIso)}`}
                onClose={() => setIngredientsModalOpen(false)}
            >
                {todaysIngredients.length ? (
                    renderIngredientsList(todaysIngredients)
                ) : (
                    <div className="text-sm text-text-muted">
                        Список інгредієнтів з’явиться після генерації меню на сьогодні.
                    </div>
                )}
            </Modal>
        </div>
    );
}


