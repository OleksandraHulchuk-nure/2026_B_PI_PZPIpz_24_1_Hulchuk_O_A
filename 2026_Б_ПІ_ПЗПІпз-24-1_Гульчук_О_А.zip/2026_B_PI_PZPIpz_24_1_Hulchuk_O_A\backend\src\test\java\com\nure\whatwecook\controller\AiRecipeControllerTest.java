package com.nure.whatwecook.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nure.whatwecook.config.exception.AiRecipeValidationException;
import com.nure.whatwecook.config.exception.GlobalExceptionHandler;
import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MeasurementUnit;
import com.nure.whatwecook.domain.enums.MenuType;
import com.nure.whatwecook.dto.ai.AiRecipeDraftDto;
import com.nure.whatwecook.dto.ai.AiRecipeDraftIngredientDto;
import com.nure.whatwecook.mapper.RecipeMapper;
import com.nure.whatwecook.service.AiRecipeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AiRecipeControllerTest {

    @Mock
    private CurrentUserProvider currentUserProvider;
    @Mock
    private AiRecipeService aiRecipeService;
    @Mock
    private RecipeMapper recipeMapper;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper().findAndRegisterModules();
        AiRecipeController controller = new AiRecipeController(currentUserProvider, aiRecipeService, recipeMapper);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    void generateRecipeDraftReturnsDraftPayload() throws Exception {
        UUID userId = UUID.fromString("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa");
        UUID ingredientId = UUID.fromString("11111111-1111-1111-1111-111111111111");

        AiRecipeDraftIngredientDto ingredient = new AiRecipeDraftIngredientDto();
        ingredient.setIngredientId(ingredientId);
        ingredient.setIngredientNameUk("Курка");
        ingredient.setQuantity(new BigDecimal("200"));
        ingredient.setUnit(MeasurementUnit.GRAM);
        ingredient.setDefaultUnit(MeasurementUnit.GRAM);

        AiRecipeDraftDto draft = new AiRecipeDraftDto();
        draft.setName("Швидкий обід");
        draft.setMealType(MealType.LUNCH);
        draft.setMenuType(MenuType.BALANCED);
        draft.setTotalTimeMinutes(25);
        draft.setDefaultServings(3);
        draft.setComplexityRating(2);
        draft.setSteps(List.of("Крок 1"));
        draft.setIngredients(List.of(ingredient));

        when(currentUserProvider.getCurrentUserId()).thenReturn(userId);
        when(aiRecipeService.generateRecipeDraft(eq(userId), any())).thenReturn(draft);

        mockMvc.perform(post("/api/recipes/ai/generate")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "mealType": "LUNCH",
                                  "menuType": "BALANCED",
                                  "servings": 3
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Швидкий обід"))
                .andExpect(jsonPath("$.mealType").value("LUNCH"))
                .andExpect(jsonPath("$.ingredients[0].ingredientId").value(ingredientId.toString()))
                .andExpect(jsonPath("$.ingredients[0].ingredientNameUk").value("Курка"));
    }

    @Test
    void saveRecipeDraftReturnsValidationErrorsWhenDraftCannotBePersisted() throws Exception {
        UUID userId = UUID.fromString("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa");
        when(currentUserProvider.getCurrentUserId()).thenReturn(userId);
        when(aiRecipeService.saveGeneratedRecipe(eq(userId), any()))
                .thenThrow(new AiRecipeValidationException(
                        "AI recipe draft validation failed",
                        Map.of("ingredients[0].ingredientId", "Ingredient was not found")
                ));

        mockMvc.perform(post("/api/recipes/ai/save")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(validDraftPayload())))
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.message").value("AI recipe draft validation failed"))
                .andExpect(jsonPath("$.validationErrors['ingredients[0].ingredientId']").value("Ingredient was not found"));
    }

    private AiRecipeDraftDto validDraftPayload() {
        AiRecipeDraftIngredientDto ingredient = new AiRecipeDraftIngredientDto();
        ingredient.setIngredientId(UUID.fromString("11111111-1111-1111-1111-111111111111"));
        ingredient.setIngredientNameUk("Курка");
        ingredient.setQuantity(new BigDecimal("150"));
        ingredient.setUnit(MeasurementUnit.GRAM);

        AiRecipeDraftDto draft = new AiRecipeDraftDto();
        draft.setName("Курка з рисом");
        draft.setMealType(MealType.DINNER);
        draft.setMenuType(MenuType.BALANCED);
        draft.setTotalTimeMinutes(30);
        draft.setDefaultServings(2);
        draft.setComplexityRating(2);
        draft.setSteps(List.of("Крок 1"));
        draft.setIngredients(List.of(ingredient));
        return draft;
    }
}
