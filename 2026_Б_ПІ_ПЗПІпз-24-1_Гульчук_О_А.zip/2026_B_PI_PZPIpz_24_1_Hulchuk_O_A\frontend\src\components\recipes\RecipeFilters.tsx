'use client';

import * as React from 'react';

import {Input} from '@/components/ui/input';
import {Select} from '@/components/ui/select';
import {Button} from '@/components/ui/button';

import type {RecipeFiltersProps, RecipeFiltersValue} from './types';
import {
    MEAL_TYPE_OPTIONS,
    RECIPE_SOURCE_OPTIONS,
    RECIPE_STATUS_OPTIONS,
} from '@/lib/constants/enums';

export function RecipeFilters({
                                  value,
                                  onChange,
                                  onReset,
                              }: RecipeFiltersProps) {

    return (
        <>
            <div id="recipe-filters-panel">
                <div className="grid grid-cols-1 gap-2 md:grid-cols-12 md:items-end">
                    {/* Search */}
                    <div className="md:col-span-3">
                        <label className="mb-1 block text-[11px] font-medium text-text-muted">
                            Пошук
                        </label>
                        <Input
                            value={value.search}
                            onChange={(e) => onChange({...value, search: e.target.value})}
                            placeholder="Напр. “суп”, “паста”…"
                            className="h-9"
                        />
                    </div>

                    {/* Meal type */}
                    <div className="md:col-span-2">
                        <label className="mb-1 block text-[11px] font-medium text-text-muted">
                            Прийом їжі
                        </label>
                        <Select
                            value={value.mealType}
                            onChange={(e) =>
                                onChange({
                                    ...value,
                                    mealType: e.target.value as RecipeFiltersValue['mealType'],
                                })
                            }
                            className="h-9"
                        >
                            <option value="">Усі</option>
                            {MEAL_TYPE_OPTIONS.map((option) => (
                                <option key={option.value} value={option.value}>
                                    {option.label}
                                </option>
                            ))}
                        </Select>
                    </div>

                    {/* Max time */}
                    <div className="md:col-span-2">
                        <label className="mb-1 block text-[11px] font-medium text-text-muted">
                            Час
                        </label>
                        <Select
                            value={String(value.maxTime)}
                            onChange={(e) =>
                                onChange({
                                    ...value,
                                    maxTime: e.target.value ? Number(e.target.value) : '',
                                })
                            }
                            className="h-9"
                        >
                            <option value="">Будь-який</option>
                            <option value="15">до 15 хв</option>
                            <option value="30">до 30 хв</option>
                            <option value="45">до 45 хв</option>
                            <option value="60">до 60 хв</option>
                            <option value="90">до 90 хв</option>
                        </Select>
                    </div>

                    {/* Status */}
                    <div className="md:col-span-2">
                        <label className="mb-1 block text-[11px] font-medium text-text-muted">
                            Статус
                        </label>
                        <Select
                            value={value.status}
                            onChange={(e) =>
                                onChange({
                                    ...value,
                                    status: e.target.value as RecipeFiltersValue['status'],
                                })
                            }
                            className="h-9"
                        >
                            <option value="">Усі</option>
                            {RECIPE_STATUS_OPTIONS.map((option) => (
                                <option key={option.value} value={option.value}>
                                    {option.label}
                                </option>
                            ))}
                        </Select>
                    </div>

                    {/* Source type */}
                    <div className="md:col-span-2">
                        <label className="mb-1 block text-[11px] font-medium text-text-muted">
                            Тип
                        </label>
                        <Select
                            value={value.sourceType}
                            onChange={(e) =>
                                onChange({
                                    ...value,
                                    sourceType: e.target.value as RecipeFiltersValue['sourceType'],
                                })
                            }
                            className="h-9"
                        >
                            <option value="">Усі</option>
                            {RECIPE_SOURCE_OPTIONS.map((option) => (
                                <option key={option.value} value={option.value}>
                                    {option.label}
                                </option>
                            ))}
                        </Select>
                    </div>
                    <div className="md:col-span-1">
                        <Button
                            variant="secondary"
                            size="sm"
                            onClick={onReset}
                            className="h-8 px-3"
                        >
                            Скинути
                        </Button>
                    </div>
                </div>
            </div>
        </>
    );
}
