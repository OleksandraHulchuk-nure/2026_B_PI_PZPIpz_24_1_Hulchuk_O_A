import type {MealType, MeasurementUnit, ProductCategory, RecipeSourceType, RecipeStatus} from '@/lib/api/recipeApi';

export interface RecipeFiltersValue {
    status: '' | RecipeStatus;
    sourceType: '' | RecipeSourceType;
    mealType: '' | MealType;
    maxTime: '' | number;
    search: string; // client-side
}

export interface RecipeFiltersProps {
    value: RecipeFiltersValue;
    onChange: (next: RecipeFiltersValue) => void;
    onReset: () => void;
    defaultOpen?: boolean;
}

export type RecipeIngredientLine = {
    id: string;
    ingredientId: string | null;
    ingredientName: string;
    ingredientNameUk?: string | null;
    ingredientNameEn?: string | null;
    category?: ProductCategory | null;
    defaultUnit?: MeasurementUnit | null;
    quantity: string;
    unit: MeasurementUnit | '';
    optional: boolean;
};

export type IngredientLine = {
    id: string;
    ingredientId: string | null;
    ingredientName: string;
    ingredientNameUk?: string | null;
    ingredientNameEn?: string | null;
    category?: ProductCategory | null;
    defaultUnit?: MeasurementUnit | null;
    quantity: string;
    unit: MeasurementUnit | '';
    optional: boolean;
};
