package com.nure.whatwecook.service;

import com.nure.whatwecook.domain.entity.recipe.RecipeImage;

import java.util.UUID;

public interface RecipeImageService {

    RecipeImage saveOrUpdatePrimaryImage(UUID userId,
                                         UUID recipeId,
                                         byte[] data,
                                         String contentType,
                                         String fileName);

    RecipeImage getPrimaryImage(UUID userId, UUID recipeId);
}
