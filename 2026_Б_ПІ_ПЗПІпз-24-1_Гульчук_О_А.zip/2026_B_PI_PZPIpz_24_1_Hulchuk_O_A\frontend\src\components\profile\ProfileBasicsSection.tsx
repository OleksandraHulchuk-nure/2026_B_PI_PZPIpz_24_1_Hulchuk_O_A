import {Card} from '@/components/ui/card';
import {Input} from '@/components/ui/input';
import {Select} from '@/components/ui/select';

import type {MenuType} from '@/lib/api/profileApi';
import type {ProfileBasicsSectionProps} from './profile.types';

export function ProfileBasicsSection({
                                         name,
                                         familySize,
                                         menuType,
                                         onNameChange,
                                         onFamilySizeChange,
                                         onMenuTypeChange,
                                     }: ProfileBasicsSectionProps) {
    const handleFamilySizeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const value = event.target.value;
        onFamilySizeChange(value === '' ? '' : Number(value));
    };

    const handleMenuTypeChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        const value = event.target.value as MenuType;
        onMenuTypeChange?.(value);
    };

    return (
        <Card className="space-y-4">
            <div className="grid gap-4 md:grid-cols-[2fr_1fr_1fr]">
                <div className="space-y-1">
                    <label htmlFor="profileName" className="label">
                        Назва профілю
                    </label>
                    <Input
                        id="profileName"
                        placeholder="Наприклад, Родина Коваленко"
                        value={name}
                        onChange={(e) => onNameChange(e.target.value)}
                    />
                </div>

                <div className="space-y-1">
                    <label htmlFor="familySize" className="label">
                        Кількість людей у сім’ї
                    </label>
                    <Input
                        id="familySize"
                        type="number"
                        min={1}
                        value={familySize}
                        onChange={handleFamilySizeChange}
                    />
                </div>

                <div className="space-y-1">
                    <label htmlFor="menuType" className="label">
                        Тип меню
                    </label>
                    <Select
                        id="menuType"
                        value={menuType}
                        onChange={handleMenuTypeChange}
                    >
                        <option value="BALANCED">Збалансоване</option>
                        <option value="MORE_MEAT">Більше м’яса</option>
                        <option value="MORE_FISH">Більше риби</option>
                        <option value="MORE_VEGGIES">Більше овочів</option>
                        <option value="VEGETARIAN">Вегетаріанське</option>
                    </Select>
                </div>
            </div>
        </Card>
    );
}
