package com.nure.whatwecook.config.ai;

import org.springframework.boot.EnvironmentPostProcessor;
import org.springframework.boot.SpringApplication;
import org.springframework.core.Ordered;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class AiEnvironmentPostProcessor implements EnvironmentPostProcessor, Ordered {

    private static final String PROPERTY_SOURCE_NAME = "whatwecookAiDerivedProperties";

    @Override
    public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
        Map<String, Object> properties = new LinkedHashMap<>();

        boolean enabled = environment.getProperty("whatwecook.ai.enabled", Boolean.class, true);
        if (!enabled) {
            properties.put("spring.ai.model.chat", "none");
            properties.put("spring.ai.chat.client.enabled", "false");
            replacePropertySource(environment, properties);
            return;
        }

        String provider = environment.getProperty("whatwecook.ai.provider", "openai")
                .trim()
                .toLowerCase(Locale.ROOT);
        String model = environment.getProperty("whatwecook.ai.model");
        Double temperature = environment.getProperty("whatwecook.ai.temperature", Double.class);
        Integer maxTokens = environment.getProperty("whatwecook.ai.max-tokens", Integer.class);

        switch (provider) {
            case "openai" -> {
                properties.put("spring.ai.model.chat", "openai");
                putIfNotNull(properties, "spring.ai.openai.chat.options.model", model);
                putIfNotNull(properties, "spring.ai.openai.chat.options.temperature", temperature);
                putIfNotNull(properties, "spring.ai.openai.chat.options.maxTokens", maxTokens);
            }
            case "gemini" -> {
                properties.put("spring.ai.model.chat", "google-genai");
                putIfNotNull(properties, "spring.ai.google.genai.chat.options.model", model);
                putIfNotNull(properties, "spring.ai.google.genai.chat.options.temperature", temperature);
                putIfNotNull(properties, "spring.ai.google.genai.chat.options.max-output-tokens", maxTokens);
                properties.put("spring.ai.google.genai.chat.options.response-mime-type", "application/json");
            }
            case "ollama" -> {
                properties.put("spring.ai.model.chat", "ollama");
                putIfNotNull(properties, "spring.ai.ollama.chat.options.model", model);
                putIfNotNull(properties, "spring.ai.ollama.chat.options.temperature", temperature);
                putIfNotNull(properties, "spring.ai.ollama.chat.options.num-predict", maxTokens);
                properties.put("spring.ai.ollama.chat.options.format", "json");
            }
            default -> throw new IllegalStateException("Unsupported AI provider: " + provider);
        }

        replacePropertySource(environment, properties);
    }

    private void putIfNotNull(Map<String, Object> properties, String key, Object value) {
        if (value != null) {
            properties.put(key, value);
        }
    }

    private void replacePropertySource(ConfigurableEnvironment environment, Map<String, Object> properties) {
        MapPropertySource propertySource = new MapPropertySource(PROPERTY_SOURCE_NAME, properties);
        if (environment.getPropertySources().contains(PROPERTY_SOURCE_NAME)) {
            environment.getPropertySources().replace(PROPERTY_SOURCE_NAME, propertySource);
            return;
        }
        environment.getPropertySources().addFirst(propertySource);
    }

    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }
}
