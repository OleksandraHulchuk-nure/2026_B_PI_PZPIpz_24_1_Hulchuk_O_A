import { useState } from 'react';

import { searchIngredients, type Ingredient } from '@/lib/api/ingredientApi';

import type { IngredientSearchHandlers, IngredientSearchState } from '../profile.types';

type UseIngredientSearchResult = IngredientSearchState & IngredientSearchHandlers;

export function useIngredientSearch(
    onSelect: (ingredient: Ingredient) => void,
): UseIngredientSearchResult {
    const [query, setQuery] = useState('');
    const [suggestions, setSuggestions] = useState<Ingredient[]>([]);
    const [searching, setSearching] = useState(false);

    const handleQueryChange: IngredientSearchHandlers['handleQueryChange'] = async (
        event,
    ) => {
        const value = event.target.value;
        setQuery(value);

        if (!value || value.length < 2) {
            setSuggestions([]);
            return;
        }

        setSearching(true);
        try {
            const results = await searchIngredients(value);
            setSuggestions(results);
        } catch {
        } finally {
            setSearching(false);
        }
    };

    const handleSelectSuggestion = (ingredient: Ingredient) => {
        onSelect(ingredient);
        setQuery('');
        setSuggestions([]);
    };

    return {
        query,
        suggestions,
        searching,
        handleQueryChange,
        handleSelectSuggestion,
    };
}
