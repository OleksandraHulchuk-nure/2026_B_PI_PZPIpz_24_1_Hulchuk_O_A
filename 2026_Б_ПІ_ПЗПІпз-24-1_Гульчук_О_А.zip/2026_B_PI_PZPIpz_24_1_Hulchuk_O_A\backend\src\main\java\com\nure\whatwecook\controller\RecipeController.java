package com.nure.whatwecook.controller;


import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.entity.recipe.RecipeImage;
import com.nure.whatwecook.domain.entity.recipe.RecipeIngredient;
import com.nure.whatwecook.dto.PaginationDto;
import com.nure.whatwecook.dto.recipe.*;
import com.nure.whatwecook.mapper.RecipeIngredientMapper;
import com.nure.whatwecook.mapper.RecipeMapper;
import com.nure.whatwecook.repository.IngredientRepository;
import com.nure.whatwecook.service.RecipeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.stream.Collectors;

@Tag(name = "Recipes", description = "User recipes CRUD and rating")
@RestController
@RequestMapping("/api/recipes")
@RequiredArgsConstructor
public class RecipeController {

    private final CurrentUserProvider currentUserProvider;
    private final RecipeService recipeService;
    private final RecipeMapper recipeMapper;
    private final RecipeIngredientMapper recipeIngredientMapper;
    private final IngredientRepository ingredientRepository;

    @Operation(summary = "Get list of user's recipes with filters")
    @PostMapping
    public ResponseEntity<RecipeSearchPageDto> getRecipes(
            @RequestBody(required = false) RecipeSearchRequestDto request
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        RecipeSearchRequestDto searchRequest = request != null ? request : new RecipeSearchRequestDto();

        Sort sort = resolveSort(searchRequest.getSort());
        PaginationDto pagination = searchRequest.getPagination();
        Pageable pageable = pagination != null && pagination.isValid()
                ? PageRequest.of(pagination.getPage(), pagination.getSize(), sort)
                : PageRequest.of(0, Integer.MAX_VALUE, sort);

        Page<Recipe> recipes = recipeService.getUserRecipes(
                userId,
                searchRequest.getSearch(),
                searchRequest.getStatus(),
                searchRequest.getSourceType(),
                searchRequest.getMealType(),
                searchRequest.getMaxTotalTimeMinutes(),
                pageable
        );
        RecipeSearchPageDto response = new RecipeSearchPageDto(
                recipes.getTotalElements(),
                recipes.getNumber(),
                recipes.getSize(),
                recipes.hasNext(),
                recipeMapper.toListItemDtoList(recipes.getContent())
        );
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Create manual recipe")
    @PostMapping("/manual")
    public ResponseEntity<RecipeDetailsDto> createManualRecipe(
            @RequestBody RecipeCreateRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();

        Recipe recipeEntity = recipeMapper.fromCreateDto(requestDto);
        recipeEntity.setSteps(requireSteps(requestDto.getSteps()));
        recipeEntity.setComplexityRating(
                requestDto.getComplexityRating() != null ? requestDto.getComplexityRating() : 1
        );

        List<RecipeIngredient> ingredients = toIngredientEntities(requestDto.getIngredients());

        Recipe saved = recipeService.createManualRecipe(userId, recipeEntity, ingredients);
        return ResponseEntity.ok(enrichDetails(saved));
    }

    @Operation(summary = "Get recipe details by id")
    @GetMapping("/{id}")
    public ResponseEntity<RecipeDetailsDto> getRecipe(@PathVariable("id") UUID id) {
        UUID userId = currentUserProvider.getCurrentUserId();
        Recipe recipe = recipeService.getRecipeById(userId, id);
        return ResponseEntity.ok(enrichDetails(recipe));
    }

    @Operation(summary = "Update manual recipe (name, description, times, servings, ingredients)")
    @PutMapping("/{id}")
    public ResponseEntity<RecipeDetailsDto> updateRecipe(
            @PathVariable("id") UUID id,
            @RequestBody RecipeUpdateRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();

        Recipe existing = recipeService.getRecipeById(userId, id);
        recipeMapper.updateEntityFromDto(requestDto, existing);
        existing.setSteps(requireSteps(requestDto.getSteps()));
        if (requestDto.getComplexityRating() != null) {
            existing.setComplexityRating(requestDto.getComplexityRating());
        }

        List<RecipeIngredient> ingredients = toIngredientEntities(requestDto.getIngredients());

        Recipe updated = recipeService.updateManualRecipe(userId, id, existing, ingredients);
        return ResponseEntity.ok(enrichDetails(updated));
    }

    @Operation(summary = "Delete recipe")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecipe(@PathVariable("id") UUID id) {
        UUID userId = currentUserProvider.getCurrentUserId();
        recipeService.deleteRecipe(userId, id);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Update recipe rating (complexity, taste, comment)")
    @PostMapping("/{id}/rating")
    public ResponseEntity<RecipeDetailsDto> updateRating(
            @PathVariable("id") UUID id,
            @RequestBody RecipeRatingUpdateRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        Recipe updated = recipeService.updateRecipeRating(
                userId,
                id,
                requestDto.getComplexityRating(),
                requestDto.getTasteRating(),
                requestDto.getRatingComment(),
                requestDto.getStatus()
        );
        return ResponseEntity.ok(enrichDetails(updated));
    }

    @Operation(summary = "Update recipe status (TO_VERIFY / VERIFIED / REJECTED)")
    @PutMapping("/{id}/status")
    public ResponseEntity<RecipeDetailsDto> updateStatus(
            @PathVariable("id") UUID id,
            @RequestBody RecipeStatusUpdateRequestDto requestDto
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        Recipe updated = recipeService.updateRecipeStatus(userId, id, requestDto.getStatus());
        return ResponseEntity.ok(enrichDetails(updated));
    }

    private Sort resolveSort(RecipeSortDto sortDto) {
        Sort defaultSort = Sort.by(Sort.Direction.DESC, RecipeSortField.CREATED_AT.getProperty());
        if (sortDto != null && sortDto.isValid()) {
            return Sort.by(sortDto.getDirection(), sortDto.getField().getProperty())
                    .and(Sort.by(sortDto.getDirection(), "id"));
        }
        return defaultSort.and(Sort.by(Sort.Direction.DESC, "id"));
    }

    private List<RecipeIngredient> toIngredientEntities(List<RecipeIngredientDto> dtos) {
        if (dtos == null || dtos.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Recipe ingredients are required");
        }
        Set<UUID> ingredientIds = dtos.stream()
                .map(RecipeIngredientDto::getIngredientId)
                .collect(Collectors.toSet());

        List<Ingredient> ingredients = ingredientRepository.findByIdIn(ingredientIds);
        if (ingredients.size() != ingredientIds.size()) {
            throw new EntityNotFoundException("Some ingredient IDs were not found");
        }

        Map<String, Ingredient> ingredientMap = ingredients.stream()
                .collect(Collectors.toMap(i -> i.getId().toString(), i -> i));

        List<RecipeIngredient> result = new ArrayList<>();
        for (RecipeIngredientDto dto : dtos) {
            RecipeIngredient entity = recipeIngredientMapper.toEntity(dto, ingredientMap);
            result.add(entity);
        }
        return result;
    }

    private List<String> requireSteps(List<String> steps) {
        if (steps == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Recipe steps are required");
        }
        List<String> cleaned = steps.stream()
                .map(s -> s == null ? null : s.trim())
                .filter(s -> s != null && !s.isEmpty())
                .toList();
        if (cleaned.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Recipe steps cannot be empty");
        }
        return cleaned;
    }

    private RecipeDetailsDto enrichDetails(Recipe recipe) {
        RecipeDetailsDto dto = recipeMapper.toDetailsDto(recipe);
        if (dto != null && recipe.getImages() != null) {
            boolean hasImage = recipe.getImages().stream().anyMatch(RecipeImage::isPrimary);
            if (hasImage) {
                dto.setImageUrl("/api/recipes/" + recipe.getId() + "/image");
            }
        }
        return dto;
    }
}
