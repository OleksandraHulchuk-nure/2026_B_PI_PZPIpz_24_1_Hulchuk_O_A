import {cn} from '@/lib/utils';
import React from 'react';

type ColumnAlign = 'left' | 'right' | 'center';

export interface TableColumn {
    key: string;
    header: React.ReactNode;
    align?: ColumnAlign;
}

export interface TableProps {
    columns: TableColumn[];
    rows: Array<Record<string, React.ReactNode>>;
    caption?: string;
    className?: string;
}

export function Table({columns, rows, caption, className}: TableProps) {
    return (
        <div
            className={cn(
                'max-w-full overflow-x-auto rounded-2xl border border-border bg-surface',
                className,
            )}
        >
            <table className="w-full min-w-[840px] border-collapse text-xs">
                {caption && (
                    <caption className="px-3 pb-2.5 pt-3 text-left text-[11px] text-text-muted">
                        {caption}
                    </caption>
                )}

                <thead>
                <tr className="bg-primary-soft/60 text-xs uppercase tracking-[0.08em] text-text-muted">
                    {columns.map((col) => (
                        <th
                            key={col.key}
                            className={cn(
                                'whitespace-nowrap px-3 py-2 text-left font-semibold first:rounded-tl-2xl last:rounded-tr-2xl',
                                col.align === 'right' && 'text-right',
                                col.align === 'center' && 'text-center',
                            )}
                        >
                            {col.header}
                        </th>
                    ))}
                </tr>
                </thead>

                <tbody>
                {rows.length === 0 ? (
                    <tr>
                        <td
                            colSpan={columns.length}
                            className="px-3 py-3 text-center text-xs text-text-muted"
                        >
                            Немає даних для відображення
                        </td>
                    </tr>
                ) : (
                    rows.map((row, idx) => (
                        <tr
                            key={idx}
                            className={cn(
                                'border-t border-border/60 text-xs transition-colors',
                                'hover:bg-background/70',
                            )}
                        >
                            {columns.map((col) => (
                                <td
                                    key={col.key}
                                    className={cn(
                                        'px-3 py-2 align-middle',
                                        col.align === 'right' && 'text-right',
                                        col.align === 'center' && 'text-center',
                                    )}
                                >
                                    {row[col.key]}
                                </td>
                            ))}
                        </tr>
                    ))
                )}
                </tbody>
            </table>
        </div>
    );
}
