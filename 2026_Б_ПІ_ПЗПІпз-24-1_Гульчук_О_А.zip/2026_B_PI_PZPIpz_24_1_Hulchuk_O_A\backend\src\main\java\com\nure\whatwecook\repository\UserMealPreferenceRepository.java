package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.profile.UserMealPreference;
import com.nure.whatwecook.domain.enums.MealType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserMealPreferenceRepository extends JpaRepository<UserMealPreference, UUID> {

    List<UserMealPreference> findByUserId(UUID userId);

    Optional<UserMealPreference> findByUserIdAndMealType(UUID userId, MealType mealType);

    void deleteByUserId(UUID userId);
}
