package com.nure.whatwecook.dto.ai;

import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MenuType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class AiRecipeDraftDto {

    @NotBlank
    private String name;

    private String description;

    private MenuType menuType;

    @NotNull
    private MealType mealType;

    @Min(1)
    private Integer activeCookingTimeMinutes;

    @NotNull
    @Min(1)
    private Integer totalTimeMinutes;

    @NotNull
    @Min(1)
    private Integer defaultServings;

    @NotNull
    @Min(1)
    private Integer complexityRating;

    @NotEmpty
    private List<@NotBlank String> steps;

    @Valid
    @NotEmpty
    private List<AiRecipeDraftIngredientDto> ingredients;
}
