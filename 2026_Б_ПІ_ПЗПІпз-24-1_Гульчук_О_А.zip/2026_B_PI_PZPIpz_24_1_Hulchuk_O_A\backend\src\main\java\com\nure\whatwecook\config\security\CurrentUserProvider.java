package com.nure.whatwecook.config.security;

import java.util.UUID;

public interface CurrentUserProvider {

    UUID getCurrentUserId();
}