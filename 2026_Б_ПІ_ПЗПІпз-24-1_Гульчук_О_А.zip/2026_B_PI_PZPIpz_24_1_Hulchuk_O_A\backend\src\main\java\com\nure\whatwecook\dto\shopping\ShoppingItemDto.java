package com.nure.whatwecook.dto.shopping;

import com.nure.whatwecook.domain.enums.MeasurementUnit;
import com.nure.whatwecook.domain.enums.ProductCategory;
import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
public class ShoppingItemDto {

    private UUID id;
    private UUID ingredientId;
    private String ingredientNameUk;
    private ProductCategory category;
    private MeasurementUnit unit;
    private BigDecimal neededQuantity;
    private BigDecimal haveQuantity;
}
