package com.nure.whatwecook.config.exception;

public class AiFeatureDisabledException extends RuntimeException {

    public AiFeatureDisabledException(String message) {
        super(message);
    }
}
