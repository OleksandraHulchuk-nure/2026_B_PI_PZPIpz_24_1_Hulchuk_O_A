package com.nure.whatwecook.dto.ai;

import lombok.Data;

import java.util.List;

@Data
public class AiRecipeLlmDraftDto {

    private String name;

    private String description;

    private String menuType;

    private String mealType;

    private Integer activeCookingTimeMinutes;

    private Integer totalTimeMinutes;

    private Integer defaultServings;

    private Integer complexityRating;

    private List<String> steps;

    private List<AiRecipeLlmDraftIngredientDto> ingredients;
}
