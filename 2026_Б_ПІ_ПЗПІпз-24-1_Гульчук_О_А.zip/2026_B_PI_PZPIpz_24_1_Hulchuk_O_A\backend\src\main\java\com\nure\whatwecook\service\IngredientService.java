package com.nure.whatwecook.service;

import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.enums.ProductCategory;
import com.nure.whatwecook.dto.ingredient.AggregatedIngredientDto;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public interface IngredientService {

    List<Ingredient> searchIngredients(String search, ProductCategory category);

    Ingredient getIngredientById(UUID id);

    List<AggregatedIngredientDto> getAggregatedIngredientsByDate(UUID userId, LocalDate date);
}
