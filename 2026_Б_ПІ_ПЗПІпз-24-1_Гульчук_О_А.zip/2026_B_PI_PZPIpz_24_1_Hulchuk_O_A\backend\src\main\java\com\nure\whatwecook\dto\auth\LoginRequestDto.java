package com.nure.whatwecook.dto.auth;

import lombok.Data;

@Data
public class LoginRequestDto {

    private String email;
    private String password;
}
