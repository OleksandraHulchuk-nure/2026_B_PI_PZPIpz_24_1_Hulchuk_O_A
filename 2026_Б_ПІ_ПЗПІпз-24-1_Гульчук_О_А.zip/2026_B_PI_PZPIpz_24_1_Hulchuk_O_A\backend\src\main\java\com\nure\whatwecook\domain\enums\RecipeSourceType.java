package com.nure.whatwecook.domain.enums;

import lombok.Getter;

@Getter
public enum RecipeSourceType {

    MANUAL("Мій рецепт"),
    AI("AI рецепт");

    private final String ukrainianName;

    RecipeSourceType(String ukrainianName) {
        this.ukrainianName = ukrainianName;
    }

}
