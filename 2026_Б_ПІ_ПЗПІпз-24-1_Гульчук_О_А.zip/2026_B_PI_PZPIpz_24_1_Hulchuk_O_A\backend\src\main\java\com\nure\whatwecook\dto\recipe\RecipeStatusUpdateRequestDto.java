package com.nure.whatwecook.dto.recipe;

import com.nure.whatwecook.domain.enums.RecipeStatus;
import lombok.Data;

@Data
public class RecipeStatusUpdateRequestDto {

    private RecipeStatus status;
}
