package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.shopping.ShoppingList;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ShoppingListRepository extends JpaRepository<ShoppingList, UUID> {

    Optional<ShoppingList> findByWeeklyMenuId(UUID weeklyMenuId);

}
