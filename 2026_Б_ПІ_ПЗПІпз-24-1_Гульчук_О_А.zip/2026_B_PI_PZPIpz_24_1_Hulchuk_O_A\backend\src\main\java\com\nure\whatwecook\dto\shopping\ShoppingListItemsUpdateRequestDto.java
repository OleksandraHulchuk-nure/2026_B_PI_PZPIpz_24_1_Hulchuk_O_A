package com.nure.whatwecook.dto.shopping;

import lombok.Data;

import java.util.List;

@Data
public class ShoppingListItemsUpdateRequestDto {

    private List<ShoppingItemUpdateDto> items;
}
