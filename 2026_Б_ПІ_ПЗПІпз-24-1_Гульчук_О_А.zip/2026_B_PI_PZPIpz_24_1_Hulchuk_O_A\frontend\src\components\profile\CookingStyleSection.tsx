import { Card } from '@/components/ui/card';
import { MaterialIcon } from '@/components/ui/materialIcon';
import { Range } from '@/components/ui/range';

import type { CookingStyleSectionProps } from './profile.types';

const SIMPLICITY_LEVELS: Record<number, { label: string; helper: string }> = {
    1: {
        label: 'Дуже просто',
        helper: 'Менше кроків і прості інгредієнти.',
    },
    2: {
        label: 'Переважно легко',
        helper: 'Легкі рецепти на щодень.',
    },
    3: {
        label: 'Збалансовано',
        helper: 'Баланс простих і трохи цікавіших страв.',
    },
    4: {
        label: 'Можна складніше',
        helper: 'Трохи більше етапів і підготовки.',
    },
    5: {
        label: 'Люблю готувати',
        helper: 'Можна складніші та насиченіші рецепти.',
    },
};

function getRecipeBalanceMeta(existingRecipeRatio: number): { label: string; helper: string } {
    if (existingRecipeRatio >= 80) {
        return {
            label: 'Переважно свої рецепти',
            helper: 'Основа меню буде зі збережених страв.',
        };
    }

    if (existingRecipeRatio >= 60) {
        return {
            label: 'Більше знайомих страв',
            helper: 'Ваші рецепти переважають, але нові ідеї теж будуть.',
        };
    }

    if (existingRecipeRatio >= 40) {
        return {
            label: 'Рівний баланс',
            helper: 'Знайомі страви й нові ідеї приблизно порівну.',
        };
    }

    if (existingRecipeRatio >= 20) {
        return {
            label: 'Більше нових ідей',
            helper: 'AI частіше пропонуватиме нові страви.',
        };
    }

    return {
        label: 'Максимум новизни',
        helper: 'Меню буде більше експериментувати з новими рецептами.',
    };
}

export function CookingStyleSection({
    simplicity,
    existingRecipeRatio,
    onSimplicityChange,
    onExistingRecipeRatioChange,
}: CookingStyleSectionProps) {
    const aiRecipeRatio = 100 - existingRecipeRatio;
    const simplicityMeta = SIMPLICITY_LEVELS[simplicity] ?? SIMPLICITY_LEVELS[3];
    const balanceMeta = getRecipeBalanceMeta(existingRecipeRatio);

    const handleSimplicityChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        onSimplicityChange(Number(event.target.value));
    };

    const handleExistingRatioChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        onExistingRecipeRatioChange(Number(event.target.value));
    };

    return (
        <Card className="flex h-full flex-col gap-4">
            <div className="space-y-1">
                <h3 className="section-title">Стиль приготування</h3>
                <p className="section-subtitle">
                    Вкажіть бажану простоту страв і баланс між AI-ідеями та збереженими рецептами.
                </p>
            </div>

            <div className="grid flex-1 gap-3 lg:grid-cols-2">
                <div className="grid h-full grid-rows-[auto_2rem_auto_auto_auto] gap-3 rounded-2xl border border-border bg-background/70 p-4">
                    <div className="space-y-0.5">
                        <h3 className="text-sm font-semibold text-text-primary">Складність рецептів</h3>
                    </div>

                    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
                        <span
                            className="truncate rounded-full bg-primary-soft px-3 py-1 text-xs font-semibold text-primary whitespace-nowrap"
                            title={simplicityMeta.helper}
                        >
                            {simplicityMeta.label}
                        </span>
                        <MaterialIcon
                            name="info"
                            className="shrink-0 text-[16px] text-text-muted"
                            title={simplicityMeta.helper}
                            label={`Пояснення: ${simplicityMeta.helper}`}
                        />
                    </div>

                    <Range
                        min={1}
                        max={5}
                        step={1}
                        value={simplicity}
                        onChange={handleSimplicityChange}
                        className="w-full"
                    />

                    <div className="flex items-center justify-between gap-3 text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted">
                        <span>Простіше</span>
                        <span>Складніше</span>
                    </div>

                    <div className="text-xs text-text-muted">
                        {simplicity} з 5
                    </div>
                </div>

                <div className="grid h-full grid-rows-[auto_2rem_auto_auto_auto] gap-3 rounded-2xl border border-border bg-background/70 p-4">
                    <div className="space-y-0.5">
                        <h3 className="text-sm font-semibold text-text-primary">Баланс рецептів</h3>
                    </div>

                    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
                        <span
                            className="truncate rounded-full bg-accent-soft-ai px-3 py-1 text-xs font-semibold text-accent-ai whitespace-nowrap"
                            title={balanceMeta.helper}
                        >
                            {balanceMeta.label}
                        </span>
                        <MaterialIcon
                            name="info"
                            className="shrink-0 text-[16px] text-text-muted"
                            title={balanceMeta.helper}
                            label={`Пояснення: ${balanceMeta.helper}`}
                        />
                    </div>

                    <Range
                        tone="ai"
                        min={0}
                        max={100}
                        step={10}
                        value={existingRecipeRatio}
                        onChange={handleExistingRatioChange}
                        className="w-full"
                    />

                    <div className="flex items-center justify-between gap-3 text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted">
                        <span>Більше AI</span>
                        <span>Більше своїх</span>
                    </div>

                    <div className="text-xs text-text-muted">
                        {aiRecipeRatio}% AI • {existingRecipeRatio}% свої рецепти
                    </div>
                </div>
            </div>
        </Card>
    );
}
