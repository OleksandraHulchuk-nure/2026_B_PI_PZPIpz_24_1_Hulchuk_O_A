'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';

export type SelectProps = React.SelectHTMLAttributes<HTMLSelectElement>;

export const Select = React.forwardRef<HTMLSelectElement, SelectProps>(
    ({ className, ...props }, ref) => {
        return (
            <select
                ref={ref}
                className={cn(
                    'block w-full rounded-lg border border-border bg-surface px-3 py-2',
                    'shadow-sm transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-soft',
                    'disabled:cursor-not-allowed disabled:opacity-60',
                    className,
                )}
                {...props}
            />
        );
    },
);

Select.displayName = 'Select';
