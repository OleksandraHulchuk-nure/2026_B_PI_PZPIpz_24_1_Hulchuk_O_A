'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';

type ButtonVariant =
    | 'primary'
    | 'secondary'
    | 'ghost'
    | 'ai'
    | 'accentWarm'
    | 'danger'
    | 'icon'
    | 'iconDanger';

type ButtonSize = 'sm' | 'md' | 'icon';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    variant?: ButtonVariant;
    size?: ButtonSize;
}

const variants: Record<ButtonVariant, string> = {
    primary:
        'bg-primary text-text-inverted px-4 py-2 hover:brightness-95 hover:-translate-y-0.5 focus-visible:ring-primary-soft',
    secondary:
        'border border-border bg-surface px-4 py-2 text-text-primary hover:bg-primary-soft focus-visible:ring-primary-soft',
    ghost:
        'border border-dashed border-border bg-transparent px-4 py-2 text-text-muted hover:bg-primary-soft focus-visible:ring-primary-soft',
    ai:
        'bg-accent-ai text-text-inverted px-4 py-2 hover:brightness-95 hover:-translate-y-0.5 focus-visible:ring-accent-soft-ai',
    accentWarm:
        'bg-accent-warm text-text-inverted px-4 py-2 hover:brightness-95 hover:-translate-y-0.5 focus-visible:ring-accent-soft-warm',
    danger:
        'bg-error text-text-inverted px-4 py-2 hover:brightness-95 hover:-translate-y-0.5 focus-visible:ring-error/40',

    icon:
        'bg-transparent p-0 text-text-muted shadow-none hover:bg-background hover:text-text-primary focus-visible:ring-primary-soft',

    iconDanger:
        'bg-transparent p-0 text-text-muted shadow-none hover:bg-error/10 hover:text-error focus-visible:ring-error/40',
};

const sizes: Record<ButtonSize, string> = {
    sm: 'text-xs px-3 py-1.5',
    md: '',
    icon: 'h-7 w-7 text-sm',
};

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
    ({ className, variant = 'primary', size = 'md', ...props }, ref) => {
        return (
            <button
                type={props.type ?? 'button'}
                ref={ref}
                className={cn(
                    'inline-flex cursor-pointer items-center justify-center gap-2 rounded-full text-sm font-semibold shadow-sm transition ' +
                    'focus-visible:outline-none focus-visible:ring-2 disabled:cursor-not-allowed disabled:opacity-60',
                    variants[variant],
                    sizes[size],
                    className,
                )}
                {...props}
            />
        );
    },
);

Button.displayName = 'Button';
