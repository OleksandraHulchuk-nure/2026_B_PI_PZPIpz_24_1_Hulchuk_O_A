'use client';

import React from 'react';
import {cn} from '@/lib/utils';

type ChipVariant = 'default' | 'ai' | 'warm' | 'outline';

export interface ChipProps extends React.HTMLAttributes<HTMLSpanElement> {
    children: React.ReactNode;
    onRemove?: () => void;
    variant?: ChipVariant;
    className?: string;
}

const chipVariants: Record<ChipVariant, string> = {
    default: 'bg-primary-soft text-text-primary',
    ai: 'bg-accent-soft-ai text-accent-ai border border-accent-ai/20',
    warm: 'bg-accent-soft-warm text-accent-warm border border-accent-warm/25',
    outline: 'bg-surface text-text-muted border border-border',
};

export function Chip({
                         children,
                         onRemove,
                         variant = 'default',
                         className,
                         ...props
                     }: ChipProps) {
    return (
        <span
            className={cn(
                'inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs',
                chipVariants[variant],
                className,
            )}
            {...props}
        >
            {children}
            {onRemove && (
                <button
                    type="button"
                    className="ml-1 text-[10px] text-text-muted hover:text-text-primary"
                    onClick={onRemove}
                >
                    ×
                </button>
            )}
        </span>
    );
}
