import { PRODUCT_CATEGORY_ORDER, ProductCategory } from '@/lib/constants/enums';
import type { ShoppingListCategoryTotalsStatDto } from '@/lib/api/statsApi';

function categoryOrderIndex(category: string) {
    const idx = PRODUCT_CATEGORY_ORDER.indexOf(category as ProductCategory);
    return idx === -1 ? 999 : idx;
}

export type ShoppingCategoryAgg = {
    category: string;
    itemsCnt: number;
    fullyCoveredItemsCnt: number;
};

export function aggregateCategoryTotals(rows: ShoppingListCategoryTotalsStatDto[]): ShoppingCategoryAgg[] {
    const map = new Map<string, ShoppingCategoryAgg>();

    for (const r of rows ?? []) {
        const cat = String(r.category ?? 'OTHER');
        const prev = map.get(cat);

        const itemsCnt = Number(r.itemsCnt ?? 0);
        const fully = Number(r.fullyCoveredItemsCnt ?? 0);

        if (!prev) {
            map.set(cat, { category: cat, itemsCnt, fullyCoveredItemsCnt: fully });
            continue;
        }

        map.set(cat, {
            category: cat,
            itemsCnt: prev.itemsCnt + itemsCnt,
            fullyCoveredItemsCnt: prev.fullyCoveredItemsCnt + fully,
        });
    }

    return Array.from(map.values()).sort(
        (a, b) => categoryOrderIndex(a.category) - categoryOrderIndex(b.category),
    );
}
