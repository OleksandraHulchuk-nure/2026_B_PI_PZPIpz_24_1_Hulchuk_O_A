package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.domain.entity.profile.User;
import com.nure.whatwecook.domain.entity.profile.UserProfile;
import com.nure.whatwecook.repository.UserProfileRepository;
import com.nure.whatwecook.repository.UserRepository;
import com.nure.whatwecook.service.UserProfileService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserProfileServiceImpl implements UserProfileService {

    private final UserRepository userRepository;
    private final UserProfileRepository userProfileRepository;

    @Override
    public UserProfile getCurrentUserProfile(UUID userId) {
        return userProfileRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User profile not found"));
    }

    @Override
    public UserProfile upsertUserProfile(UUID userId, UserProfile updatedProfile) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));

        UserProfile profile = userProfileRepository.findById(userId)
                .orElseGet(() -> {
                    UserProfile p = new UserProfile();
                    p.setUserId(userId);
                    p.setUser(user);
                    return p;
                });

        profile.setName(updatedProfile.getName());
        profile.setFamilySize(updatedProfile.getFamilySize());
        profile.setSimplicity(updatedProfile.getSimplicity());
        profile.setMenuType(updatedProfile.getMenuType());
        profile.setExistingRecipeRatio(updatedProfile.getExistingRecipeRatio());

        return userProfileRepository.save(profile);
    }
}
