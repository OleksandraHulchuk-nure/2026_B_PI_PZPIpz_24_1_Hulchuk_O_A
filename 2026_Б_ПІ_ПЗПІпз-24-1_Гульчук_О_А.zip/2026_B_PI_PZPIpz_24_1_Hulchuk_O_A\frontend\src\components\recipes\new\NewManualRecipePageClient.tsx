'use client';

import {RecipeEditorPageClient} from '@/components/recipes/editor/RecipeEditorPageClient';

export function NewManualRecipePageClient() {
    return <RecipeEditorPageClient mode="create"/>;
}

