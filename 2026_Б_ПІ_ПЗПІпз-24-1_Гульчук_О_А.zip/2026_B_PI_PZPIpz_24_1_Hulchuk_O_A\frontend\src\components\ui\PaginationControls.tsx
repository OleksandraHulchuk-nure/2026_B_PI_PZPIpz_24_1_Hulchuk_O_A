'use client';

import * as React from 'react';
import {Button} from '@/components/ui/button';
import {buildPaginationRange} from '@/lib/utils/pagination';

type PaginationItem = number | 'ellipsis';

export function PaginationControls({
                                       page,
                                       totalPages,
                                       hasNext,
                                       disabled,
                                       onPageChange,
                                   }: {
    page: number; // 0-based
    totalPages: number; // >= 1
    hasNext?: boolean;
    disabled?: boolean;
    onPageChange: (page: number) => void;
}) {
    const safeTotalPages = Math.max(1, totalPages);
    const range = buildPaginationRange({currentPage: page, totalPages: safeTotalPages}) as PaginationItem[];

    const canGoPrev = page > 0;
    const canGoNext = typeof hasNext === 'boolean' ? hasNext : page < safeTotalPages - 1;

    return (
        <div className="flex items-center justify-center gap-2">
            <Button
                variant="secondary"
                size="sm"
                disabled={disabled || !canGoPrev}
                onClick={() => onPageChange(Math.max(page - 1, 0))}
            >
                Назад
            </Button>

            <div className="flex items-center gap-1">
                {range.map((item, idx) =>
                        item === 'ellipsis' ? (
                            <span key={`ellipsis-${idx}`} className="px-2 text-xs text-text-muted">
              …
            </span>
                        ) : (
                            <Button
                                key={item}
                                variant={page === item ? 'primary' : 'secondary'}
                                size="sm"
                                disabled={disabled || page === item}
                                onClick={() => onPageChange(item)}
                                title={`Сторінка ${item + 1}`}
                            >
                                {item + 1}
                            </Button>
                        ),
                )}
            </div>

            <Button
                variant="secondary"
                size="sm"
                disabled={disabled || !canGoNext}
                onClick={() => onPageChange(page + 1)}
            >
                Далі
            </Button>
        </div>
    );
}
