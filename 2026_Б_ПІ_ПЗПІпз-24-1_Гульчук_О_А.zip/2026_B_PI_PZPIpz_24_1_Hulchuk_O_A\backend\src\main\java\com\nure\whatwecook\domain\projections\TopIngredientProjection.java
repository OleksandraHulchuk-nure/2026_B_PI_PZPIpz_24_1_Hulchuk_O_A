package com.nure.whatwecook.domain.projections;

import java.math.BigDecimal;
import java.util.UUID;

public interface TopIngredientProjection {
    UUID getIngredientId();

    String getIngredientNameUk();

    String getRiUnit();

    BigDecimal getTotalQuantity();
}
