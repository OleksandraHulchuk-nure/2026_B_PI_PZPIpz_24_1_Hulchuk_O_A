package com.nure.whatwecook.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaginationDto {

    @Schema(description = "Page number (0-based)", example = "0", minimum = "0")
    private Integer page;

    @Schema(description = "Page size", example = "20", minimum = "1")
    private Integer size;

    /**
     * @return true if both page >= 0 and size > 0
     */
    @JsonIgnore
    public boolean isValid() {
        return page != null && size != null && page >= 0 && size > 0;
    }
}