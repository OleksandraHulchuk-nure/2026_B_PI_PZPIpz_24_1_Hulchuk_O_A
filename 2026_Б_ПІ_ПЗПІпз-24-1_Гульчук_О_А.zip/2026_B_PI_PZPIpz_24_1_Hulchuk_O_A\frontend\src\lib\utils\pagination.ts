export type PaginationItem = number | 'ellipsis';

interface PaginationConfig {
    currentPage: number;
    totalPages: number;
    maxLength?: number;
}

/**
 * Returns a pagination range with optional ellipsis to keep the list compact.
 * Pages are zero-based to match API expectations; UI can render them as 1-based.
 */
export function buildPaginationRange({currentPage, totalPages, maxLength = 7}: PaginationConfig): PaginationItem[] {
    if (totalPages <= 0) return [];

    const visiblePages: PaginationItem[] = [];
    const safeMax = Math.max(3, maxLength);

    if (totalPages <= safeMax) {
        for (let i = 0; i < totalPages; i++) {
            visiblePages.push(i);
        }
        return visiblePages;
    }

    const firstPage = 0;
    const lastPage = totalPages - 1;
    const interiorSlots = safeMax - 2; // space between first and last
    const half = Math.floor(interiorSlots / 2);

    let start = Math.max(firstPage + 1, currentPage - half);
    let end = Math.min(lastPage - 1, currentPage + half);

    const actualInterior = end - start + 1;
    if (actualInterior < interiorSlots) {
        const deficit = interiorSlots - actualInterior;
        start = Math.max(firstPage + 1, start - deficit);
        end = Math.min(lastPage - 1, end + deficit);
    }

    visiblePages.push(firstPage);
    if (start > firstPage + 1) {
        visiblePages.push('ellipsis');
    }

    for (let i = start; i <= end; i++) {
        visiblePages.push(i);
    }

    if (end < lastPage - 1) {
        visiblePages.push('ellipsis');
    }
    visiblePages.push(lastPage);

    return visiblePages;
}
