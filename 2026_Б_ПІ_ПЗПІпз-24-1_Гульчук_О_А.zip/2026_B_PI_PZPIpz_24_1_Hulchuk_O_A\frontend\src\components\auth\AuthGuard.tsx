'use client';

import {usePathname, useRouter} from 'next/navigation';
import {useEffect, useState} from 'react';
import {getAuthToken} from '@/lib/auth/tokenStorage';

const PUBLIC_PATHS = ['/login', '/register'];

interface AuthGuardProps {
    children: React.ReactNode;
}

export function AuthGuard({children}: AuthGuardProps) {
    const router = useRouter();
    const pathname = usePathname();
    const [checking, setChecking] = useState(true);

    useEffect(() => {
        const isPublic = PUBLIC_PATHS.some(
            (p) => pathname === p || pathname?.startsWith(`${p}/`),
        );

        const {accessToken} = getAuthToken();

        if (!isPublic && !accessToken) {
            router.replace('/login');
            return;
        }

        if (isPublic && accessToken) {
            router.replace('/');
            return;
        }

        // eslint-disable-next-line react-hooks/set-state-in-effect
        setChecking(false);
    }, [pathname, router]);

    if (checking) {
        return (
            <div className="flex min-h-screen items-center justify-center bg-background text-text-muted">
                Перевіряємо авторизацію…
            </div>
        );
    }

    return <>{children}</>;
}
