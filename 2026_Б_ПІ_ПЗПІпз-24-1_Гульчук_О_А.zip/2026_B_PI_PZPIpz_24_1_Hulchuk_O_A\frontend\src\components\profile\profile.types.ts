import type {
    DayOfWeek,
    IngredientPreference,
    IngredientPreferenceKind,
    MealTimePreference,
    MealType,
    MenuType,
} from '@/lib/api/profileApi';
import type { Ingredient } from '@/lib/api/ingredientApi';

type ProfileName = string;

type FamilySize = number | '';

export type CookingStyleSectionProps = {
    simplicity: number;
    existingRecipeRatio: number;
    onSimplicityChange: (value: number) => void;
    onExistingRecipeRatioChange: (value: number) => void;
};

export type ProfileBasicsSectionProps = {
    name: ProfileName;
    familySize: FamilySize;
    menuType: MenuType;
    onNameChange: (value: ProfileName) => void;
    onFamilySizeChange: (value: FamilySize) => void;
    onMenuTypeChange?: (value: MenuType) => void;
};

export type MealTimePreferencesSectionProps = {
    mealTimePrefs: MealTimePreference[];
    onMealTimeChange: (mealType: MealType, minutes: number) => void;
};

export type MealScheduleSectionProps = {
    familySize?: number | null;
};

export type CellKey = `${DayOfWeek}-${MealType}`;

export type MealScheduleCellMap = Partial<Record<CellKey, string>>;

export type MealScheduleHandlers = {
    handleChange: (day: DayOfWeek, mealType: MealType, value: string) => void;
    handleSave: () => Promise<void>;
};

export type MealScheduleState = {
    cells: MealScheduleCellMap;
    loading: boolean;
    saving: boolean;
    error: string | null;
    success: string | null;
};

export type PreferencesByKind = Record<IngredientPreferenceKind, IngredientPreference[]>;

export type IngredientPreferencesSectionProps = {
    onPreferencesChange?: (prefs: IngredientPreference[]) => void;
    initialPreferences?: IngredientPreference[];
};

export type IngredientPreferenceCardProps = {
    kind: IngredientPreferenceKind;
    title: string;
    description: string;
    items: IngredientPreference[];
    onRemove: (kind: IngredientPreferenceKind, ingredientId: string) => void;
    onAdd: (kind: IngredientPreferenceKind, ingredient: Ingredient) => void;
};

export type IngredientSearchHandlers = {
    handleQueryChange: (event: React.ChangeEvent<HTMLInputElement>) => Promise<void> | void;
    handleSelectSuggestion: (ingredient: Ingredient) => void;
};

export type IngredientSearchState = {
    query: string;
    suggestions: Ingredient[];
    searching: boolean;
};
