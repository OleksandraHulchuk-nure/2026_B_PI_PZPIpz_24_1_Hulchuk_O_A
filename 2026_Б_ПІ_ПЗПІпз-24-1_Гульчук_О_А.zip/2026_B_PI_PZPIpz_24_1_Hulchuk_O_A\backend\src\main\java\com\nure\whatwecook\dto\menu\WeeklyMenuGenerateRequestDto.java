package com.nure.whatwecook.dto.menu;

import com.nure.whatwecook.domain.enums.MealType;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class WeeklyMenuGenerateRequestDto {

    /**
     * Опційно: стартова дата тижня (наприклад, понеділок).
     * Якщо не задана — бекенд візьме поточний тиждень.
     */
    private LocalDate startDate;

    private Integer days;
    private List<MealType> mealsPerDay;
    private Boolean useProfilePreferences;
}
