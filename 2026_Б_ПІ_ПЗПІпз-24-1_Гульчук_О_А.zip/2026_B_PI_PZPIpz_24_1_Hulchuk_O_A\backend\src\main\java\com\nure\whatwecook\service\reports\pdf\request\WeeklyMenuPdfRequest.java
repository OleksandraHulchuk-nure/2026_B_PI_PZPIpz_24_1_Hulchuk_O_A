package com.nure.whatwecook.service.reports.pdf.request;

import java.util.UUID;

public record WeeklyMenuPdfRequest(UUID userId, UUID weeklyMenuId) {}
