import { API_BASE_URL } from './config';
import { API_ROUTES } from './endpoints';

export interface AuthResponse {
    accessToken: string;
    tokenType: string;
}

export interface RegisterRequest {
    email: string;
    password: string;
}

export interface LoginRequest {
    email: string;
    password: string;
}

async function handleAuthResponse(response: Response): Promise<AuthResponse> {
    if (!response.ok) {
        let message = 'Помилка запиту до сервера. Спробуйте ще раз.';

        try {
            const data = (await response.json()) as {
                message?: string;
                error?: string;
            };

            if (data?.message) message = data.message;
            else if (data?.error) message = data.error;
        } catch {
        }

        throw new Error(message);
    }

    return (await response.json()) as AuthResponse;
}

export async function registerUser(
    payload: RegisterRequest,
): Promise<AuthResponse> {
    const response = await fetch(
        `${API_BASE_URL}${API_ROUTES.auth.register}`,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'include',
            body: JSON.stringify(payload),
        },
    );

    return handleAuthResponse(response);
}

export async function loginUser(
    payload: LoginRequest,
): Promise<AuthResponse> {
    const response = await fetch(`${API_BASE_URL}${API_ROUTES.auth.login}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(payload),
    });

    return handleAuthResponse(response);
}

export async function logoutUser(): Promise<void> {
    await fetch(`${API_BASE_URL}${API_ROUTES.auth.logout}`, {
        method: 'POST',
        credentials: 'include',
    });
}
