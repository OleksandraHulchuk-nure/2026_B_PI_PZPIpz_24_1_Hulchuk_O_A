package com.nure.whatwecook.config.ai;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class AiStartupLogger {

    private final AiProperties aiProperties;
    private final Environment environment;
    private final ObjectProvider<ChatModel> chatModelProvider;

    @EventListener(ApplicationReadyEvent.class)
    public void logResolvedAiConfiguration() {
        if (!aiProperties.isEnabled()) {
            log.info("AI recipes are disabled via whatwecook.ai.enabled=false");
            return;
        }

        ChatModel chatModel = chatModelProvider.getIfAvailable();
        String baseUrl = switch (aiProperties.getProvider()) {
            case OLLAMA -> environment.getProperty("spring.ai.ollama.base-url");
            case OPENAI -> environment.getProperty("spring.ai.openai.base-url", "https://api.openai.com");
            case GEMINI -> environment.getProperty("spring.ai.google.genai.base-url");
        };

        if (chatModel == null) {
            log.warn(
                    "AI recipes are enabled but no ChatModel bean was resolved. provider={}, model={}, baseUrl={}",
                    aiProperties.getProvider(),
                    aiProperties.getModel(),
                    baseUrl
            );
            return;
        }

        log.info(
                "AI recipes configured. provider={}, model={}, baseUrl={}, chatModelBean={}",
                aiProperties.getProvider(),
                aiProperties.getModel(),
                baseUrl,
                chatModel.getClass().getName()
        );
    }
}
