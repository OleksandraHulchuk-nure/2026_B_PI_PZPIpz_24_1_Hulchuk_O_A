package com.nure.whatwecook.service.helper.pdf;

import java.util.Locale;
import java.util.Map;

public record PdfRenderRequest(
        String templateName,
        Map<String, Object> model,
        Locale locale,
        String baseUri
) {
    public static PdfRenderRequest of(String templateName, Map<String, Object> model) {
        return new PdfRenderRequest(templateName, model, Locale.forLanguageTag("uk"), null);
    }
}
