package com.nure.whatwecook.dto.menu;

import com.nure.whatwecook.domain.enums.MenuStatus;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Data
public class WeeklyMenuResponseDto {

    private UUID id;
    private LocalDate startDate;
    private MenuStatus status;
    private List<MenuDayPlanDto> days;
}
