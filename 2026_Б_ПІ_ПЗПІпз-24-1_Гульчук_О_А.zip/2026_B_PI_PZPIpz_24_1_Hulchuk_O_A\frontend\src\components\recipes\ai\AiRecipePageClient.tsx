'use client';

import Link from 'next/link';
import {useRouter} from 'next/navigation';
import * as React from 'react';

import {IngredientAutocomplete} from '@/components/recipes/form/IngredientAutocomplete';
import {RecipeIngredientsStepsCard} from '@/components/recipes/form/RecipeIngredientsStepsCard';
import {useRecipeIngredientsSteps} from '@/components/recipes/form/useRecipeIngredientsSteps';
import type {RecipeIngredientLine} from '@/components/recipes/types';
import {Alert} from '@/components/ui/alert';
import {Badge} from '@/components/ui/badge';
import {Button} from '@/components/ui/button';
import {Card} from '@/components/ui/card';
import {Chip} from '@/components/ui/chip';
import {Input} from '@/components/ui/input';
import {MaterialIcon} from '@/components/ui/materialIcon';
import {Select} from '@/components/ui/select';
import StarRating from '@/components/ui/star-rating';
import {Textarea} from '@/components/ui/textarea';
import {PageSection} from '@/components/page-section';

import {ApiError} from '@/lib/api/apiClient';
import {type Ingredient} from '@/lib/api/ingredientApi';
import {getUserProfile} from '@/lib/api/profileApi';
import {
    generateAiRecipeDraft,
    MEAL_TYPE_OPTIONS,
    type AiRecipeDraftDto,
    type MeasurementUnit,
    MENU_TYPE_OPTIONS,
    type MealType,
    type MenuType,
    saveAiRecipeDraft,
} from '@/lib/api/recipeApi';
import {createRowId, DEFAULT_STEPS} from '@/lib/recipes/formDefaults';
import {normalizeSteps} from '@/lib/recipes/format';

const DEFAULT_SERVINGS = 4;
const NOTES_LIMIT = 350;

type AlertState = {
    message: string;
    status?: number;
};

function toAlertMessage(error: unknown): AlertState {
    if (error instanceof ApiError) {
        return {message: error.message, status: error.status};
    }

    if (error instanceof Error) {
        return {message: error.message};
    }

    return {message: 'Сталася помилка. Спробуйте ще раз.'};
}

function toPositiveNumber(value: string): number | null {
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed <= 0) {
        return null;
    }
    return parsed;
}

function toPositiveInteger(value: string): number | null {
    const parsed = toPositiveNumber(value);
    if (parsed === null || !Number.isInteger(parsed)) {
        return null;
    }
    return parsed;
}

function toIngredientLines(draft: AiRecipeDraftDto): RecipeIngredientLine[] {
    if (!draft.ingredients.length) {
        return [
            {
                id: createRowId(),
                ingredientId: null,
                ingredientName: '',
                quantity: '',
                unit: '',
                optional: false,
            },
        ];
    }

    return draft.ingredients.map((ingredient) => ({
        id: createRowId(),
        ingredientId: ingredient.ingredientId ?? null,
        ingredientName: ingredient.ingredientNameUk || ingredient.ingredientNameEn || '',
        ingredientNameUk: ingredient.ingredientNameUk,
        ingredientNameEn: ingredient.ingredientNameEn ?? null,
        category: ingredient.category ?? null,
        defaultUnit: ingredient.defaultUnit ?? null,
        quantity: String(ingredient.quantity ?? ''),
        unit: (ingredient.unit ?? ingredient.defaultUnit ?? '') as MeasurementUnit | '',
        optional: Boolean(ingredient.optional),
    }));
}

function hasIngredientData(line: RecipeIngredientLine) {
    return Boolean(
        line.ingredientId ||
        line.ingredientName.trim() ||
        String(line.quantity).trim() ||
        line.unit,
    );
}

function AiGenerationLoading() {
    return (
        <Card variant="ai" className="overflow-hidden">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="flex items-center gap-4">
                    <div className="grid h-14 w-14 place-items-center rounded-full bg-surface/80">
                        <div className="h-9 w-9 animate-spin rounded-full border-4 border-accent-ai/20 border-t-accent-ai"/>
                    </div>

                    <div>
                        <h2 className="text-base font-semibold text-text-primary">Генеруємо рецепт</h2>
                        <p className="mt-1 text-sm text-text-muted">
                            Підбираємо інгредієнти, час та кроки приготування під ваш профіль.
                        </p>
                    </div>
                </div>

                <div className="grid gap-2 text-xs text-text-muted sm:grid-cols-3 md:w-[440px]">
                    {['Профіль', 'Інгредієнти', 'Чернетка'].map((label) => (
                        <div key={label} className="flex items-center gap-2 rounded-lg border border-accent-ai/20 bg-surface/70 px-3 py-2">
                            <span className="h-2 w-2 animate-pulse rounded-full bg-accent-ai"/>
                            {label}
                        </div>
                    ))}
                </div>
            </div>

            <div className="mt-5 h-2 overflow-hidden rounded-full bg-surface/70">
                <div className="h-full w-2/3 animate-pulse rounded-full bg-accent-ai"/>
            </div>
        </Card>
    );
}

export function AiRecipePageClient() {
    const router = useRouter();
    const generateFormId = 'ai-recipe-generate-form';
    const saveFormId = 'ai-recipe-save-form';

    const {
        ingredients,
        steps,
        addIngredient,
        removeIngredient,
        updateIngredient,
        addStep,
        updateStep,
        clearOrRemoveStep,
        reset,
    } = useRecipeIngredientsSteps({minSteps: DEFAULT_STEPS});

    const [profileLoading, setProfileLoading] = React.useState(true);
    const [profileNotice, setProfileNotice] = React.useState<string | null>(null);

    const [mealType, setMealType] = React.useState<MealType | ''>('');
    const [menuType, setMenuType] = React.useState<MenuType>('BALANCED');
    const [servings, setServings] = React.useState(String(DEFAULT_SERVINGS));
    const [additionalNotes, setAdditionalNotes] = React.useState('');

    const [preferredQuery, setPreferredQuery] = React.useState('');
    const [preferredIngredients, setPreferredIngredients] = React.useState<Ingredient[]>([]);

    const [draft, setDraft] = React.useState<AiRecipeDraftDto | null>(null);
    const [name, setName] = React.useState('');
    const [description, setDescription] = React.useState('');
    const [activeTime, setActiveTime] = React.useState('');
    const [totalTime, setTotalTime] = React.useState('');
    const [complexityRating, setComplexityRating] = React.useState(3);

    const [generating, setGenerating] = React.useState(false);
    const [saving, setSaving] = React.useState(false);
    const [error, setError] = React.useState<AlertState | null>(null);
    const [formError, setFormError] = React.useState<string | null>(null);

    React.useEffect(() => {
        let cancelled = false;

        const loadProfileDefaults = async () => {
            try {
                const profile = await getUserProfile();
                if (cancelled) return;

                setMenuType((profile.menuType ?? 'BALANCED') as MenuType);
                setServings(String(profile.familySize && profile.familySize > 0 ? profile.familySize : DEFAULT_SERVINGS));
            } catch {
                if (!cancelled) {
                    setProfileNotice('Не вдалося завантажити профіль, використано стандартні значення.');
                }
            } finally {
                if (!cancelled) {
                    setProfileLoading(false);
                }
            }
        };

        void loadProfileDefaults();

        return () => {
            cancelled = true;
        };
    }, []);

    const addPreferredIngredient = (ingredient: Ingredient) => {
        setPreferredIngredients((prev) => {
            if (prev.some((item) => item.id === ingredient.id)) {
                return prev;
            }
            return [...prev, ingredient];
        });
        setPreferredQuery('');
    };

    const removePreferredIngredient = (ingredientId: string) => {
        setPreferredIngredients((prev) => prev.filter((item) => item.id !== ingredientId));
    };

    const populateDraft = React.useCallback((nextDraft: AiRecipeDraftDto) => {
        setDraft(nextDraft);
        setName(nextDraft.name ?? '');
        setDescription(nextDraft.description ?? '');
        setMenuType((nextDraft.menuType ?? 'BALANCED') as MenuType);
        setMealType(nextDraft.mealType);
        setActiveTime(nextDraft.activeCookingTimeMinutes ? String(nextDraft.activeCookingTimeMinutes) : '');
        setTotalTime(nextDraft.totalTimeMinutes ? String(nextDraft.totalTimeMinutes) : '');
        setServings(nextDraft.defaultServings ? String(nextDraft.defaultServings) : String(DEFAULT_SERVINGS));
        setComplexityRating(nextDraft.complexityRating ?? 3);
        reset({
            ingredients: toIngredientLines(nextDraft),
            steps: normalizeSteps(nextDraft.steps, nextDraft.description),
        });

        window.setTimeout(() => {
            document.getElementById('ai-draft-editor')?.scrollIntoView({behavior: 'smooth', block: 'start'});
        }, 100);
    }, [reset]);

    const validateGeneration = () => {
        if (!mealType) {
            return 'Оберіть прийом їжі.';
        }

        const servingsValue = toPositiveInteger(servings);
        if (!servingsValue) {
            return 'Кількість порцій має бути цілим числом більшим за 0.';
        }

        if (additionalNotes.length > NOTES_LIMIT) {
            return `Нотатки мають містити не більше ${NOTES_LIMIT} символів.`;
        }

        return null;
    };

    const validateDraft = () => {
        if (!name.trim()) {
            return 'Вкажіть назву рецепта.';
        }
        if (!mealType) {
            return 'Оберіть прийом їжі.';
        }
        if (!Number.isFinite(complexityRating) || complexityRating < 1 || complexityRating > 5) {
            return 'Складність має бути в межах 1-5.';
        }

        const total = toPositiveInteger(totalTime);
        if (!total) {
            return 'Загальний час має бути цілим числом більшим за 0.';
        }

        if (activeTime.trim()) {
            const active = toPositiveInteger(activeTime);
            if (!active) {
                return 'Активний час має бути цілим числом більшим за 0.';
            }
            if (active > total) {
                return 'Активний час не може бути більшим за загальний.';
            }
        }

        if (!toPositiveInteger(servings)) {
            return 'Кількість порцій має бути цілим числом більшим за 0.';
        }

        const cleanedIngredients = ingredients.filter(hasIngredientData);
        if (!cleanedIngredients.length) {
            return 'Додайте хоча б один інгредієнт.';
        }

        for (const ingredient of cleanedIngredients) {
            if (!ingredient.ingredientName.trim()) {
                return 'Вкажіть назву для кожного інгредієнта.';
            }
            if (!ingredient.unit) {
                return 'Оберіть одиницю виміру для всіх інгредієнтів.';
            }
            if (!toPositiveNumber(ingredient.quantity)) {
                return 'Кількість кожного інгредієнта має бути більшою за 0.';
            }
        }

        if (!normalizeSteps(steps, description).length) {
            return 'Додайте хоча б один крок приготування.';
        }

        return null;
    };

    const buildDraftPayload = (): AiRecipeDraftDto => {
        const cleanedIngredients = ingredients.filter(hasIngredientData);

        return {
            name: name.trim(),
            description: description.trim() || undefined,
            menuType,
            mealType: mealType as MealType,
            activeCookingTimeMinutes: activeTime.trim() ? Number(activeTime) : undefined,
            totalTimeMinutes: Number(totalTime),
            defaultServings: Number(servings),
            complexityRating,
            steps: normalizeSteps(steps, description),
            ingredients: cleanedIngredients.map((ingredient) => ({
                ingredientId: ingredient.ingredientId,
                ingredientNameUk: ingredient.ingredientName.trim(),
                ingredientNameEn: ingredient.ingredientNameEn ?? undefined,
                category: ingredient.category ?? undefined,
                defaultUnit: ingredient.defaultUnit ?? (ingredient.unit as MeasurementUnit),
                quantity: Number(ingredient.quantity),
                unit: ingredient.unit as MeasurementUnit,
                optional: ingredient.optional,
            })),
        };
    };

    const handleGenerate = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        setError(null);
        setFormError(null);

        const validationError = validateGeneration();
        if (validationError) {
            setFormError(validationError);
            return;
        }

        setGenerating(true);

        try {
            const nextDraft = await generateAiRecipeDraft({
                mealType: mealType as MealType,
                menuType,
                servings: Number(servings),
                preferredIngredientIds: preferredIngredients.map((ingredient) => ingredient.id),
                additionalNotes: additionalNotes.trim() || undefined,
            });

            populateDraft(nextDraft);
        } catch (nextError) {
            setError(toAlertMessage(nextError));
        } finally {
            setGenerating(false);
        }
    };

    const handleSave = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        setError(null);
        setFormError(null);

        if (!draft) {
            return;
        }

        const validationError = validateDraft();
        if (validationError) {
            setFormError(validationError);
            return;
        }

        setSaving(true);

        try {
            const saved = await saveAiRecipeDraft(buildDraftPayload());
            router.replace(`/recipes/${saved.id}?created=ai`);
        } catch (nextError) {
            setError(toAlertMessage(nextError));
        } finally {
            setSaving(false);
        }
    };

    const busy = generating || saving;
    const generationDisabled = busy || profileLoading;
    const notesLeft = NOTES_LIMIT - additionalNotes.length;

    return (
        <div className="flex flex-col gap-6">
            <PageSection
                titleAs="h2"
                title="AI-рецепт"
                subtitle="Згенеруйте чернетку, відредагуйте назву, час, інгредієнти та кроки, а потім збережіть у книгу рецептів."
                titleAddon={<Badge variant="ai">AI</Badge>}
                actions={
                    <>
                        <Link href="/recipes">
                            <Button variant="secondary" disabled={busy}>До рецептів</Button>
                        </Link>
                        {draft ? (
                            <Button type="submit" form={saveFormId} disabled={busy}>
                                {saving ? 'Збереження...' : 'Зберегти рецепт'}
                            </Button>
                        ) : null}
                    </>
                }
            />

            {error ? (
                <Alert variant="error" title="Не вдалося виконати дію">
                    {error.message}
                    {typeof error.status === 'number' ? ` (HTTP ${error.status})` : null}
                </Alert>
            ) : null}

            {formError ? (
                <Alert variant="warning" title="Перевірте форму">
                    {formError}
                </Alert>
            ) : null}

            {profileNotice ? (
                <Alert variant="info">{profileNotice}</Alert>
            ) : null}

            <form id={generateFormId} className="space-y-4" onSubmit={handleGenerate} noValidate>
                <Card className="space-y-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                            <h2 className="section-title">Параметри генерації</h2>
                            <p className="section-subtitle">
                                Тип меню та порції підтягнуться з профілю, якщо профіль доступний.
                            </p>
                        </div>
                        <Button type="submit" variant="ai" disabled={generationDisabled}>
                            {generating ? 'Генерація...' : draft ? 'Згенерувати заново' : 'Згенерувати'}
                        </Button>
                    </div>

                    <div className="grid gap-3 md:grid-cols-3">
                        <div className="space-y-1">
                            <label>Прийом їжі *</label>
                            <Select
                                value={mealType}
                                disabled={generationDisabled}
                                onChange={(event) => setMealType(event.target.value as MealType | '')}
                            >
                                <option value="">Оберіть...</option>
                                {MEAL_TYPE_OPTIONS.map((option) => (
                                    <option key={option.value} value={option.value}>
                                        {option.label}
                                    </option>
                                ))}
                            </Select>
                        </div>

                        <div className="space-y-1">
                            <label>Тип меню</label>
                            <Select
                                value={menuType}
                                disabled={generationDisabled}
                                onChange={(event) => setMenuType(event.target.value as MenuType)}
                            >
                                {MENU_TYPE_OPTIONS.map((option) => (
                                    <option key={option.value} value={option.value}>
                                        {option.label}
                                    </option>
                                ))}
                            </Select>
                        </div>

                        <div className="space-y-1">
                            <label>Порції *</label>
                            <Input
                                inputMode="numeric"
                                value={servings}
                                disabled={generationDisabled}
                                onChange={(event) => setServings(event.target.value)}
                            />
                        </div>
                    </div>

                    <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_minmax(260px,0.8fr)]">
                        <div className="space-y-1">
                            <label>Бажані інгредієнти</label>
                            <IngredientAutocomplete
                                value={preferredQuery}
                                disabled={generationDisabled}
                                placeholder="Почніть вводити назву інгредієнта"
                                onValueChange={setPreferredQuery}
                                onPick={addPreferredIngredient}
                            />
                        </div>

                        <div className="space-y-2">
                            <label>Обрано</label>
                            {preferredIngredients.length ? (
                                <div className="flex flex-wrap gap-2">
                                    {preferredIngredients.map((ingredient) => (
                                        <Chip
                                            key={ingredient.id}
                                            variant="ai"
                                            onRemove={generationDisabled ? undefined : () => removePreferredIngredient(ingredient.id)}
                                        >
                                            {ingredient.name}
                                        </Chip>
                                    ))}
                                </div>
                            ) : (
                                <p className="text-sm text-text-muted">Можна залишити порожнім.</p>
                            )}
                        </div>
                    </div>

                    <div className="space-y-1">
                        <div className="flex items-center justify-between gap-3">
                            <label>Додаткові нотатки</label>
                            <span className={notesLeft < 0 ? 'text-xs font-semibold text-error' : 'text-xs text-text-muted'}>
                                {additionalNotes.length}/{NOTES_LIMIT}
                            </span>
                        </div>
                        <Textarea
                            rows={3}
                            maxLength={NOTES_LIMIT}
                            value={additionalNotes}
                            disabled={generationDisabled}
                            placeholder="Наприклад: без гострого, більше білка, прості інгредієнти"
                            onChange={(event) => setAdditionalNotes(event.target.value)}
                        />
                    </div>
                </Card>
            </form>

            {generating ? <AiGenerationLoading/> : null}

            {draft ? (
                <section id="ai-draft-editor" className="space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                            <MaterialIcon name="edit_note" variant="ai" className="text-2xl"/>
                            <div>
                                <h2 className="section-title">Чернетка рецепта</h2>
                                <p className="section-subtitle">Перевірте й відредагуйте результат перед збереженням.</p>
                            </div>
                        </div>

                        <Button type="submit" form={saveFormId} disabled={busy}>
                            {saving ? 'Збереження...' : 'Зберегти рецепт'}
                        </Button>
                    </div>

                    <form id={saveFormId} className="space-y-4" onSubmit={handleSave} noValidate>
                        <Card className="grid gap-4 md:grid-cols-12">
                            <div className="space-y-4 md:col-span-8">
                                <div className="space-y-1">
                                    <label>Назва *</label>
                                    <Input
                                        value={name}
                                        disabled={busy}
                                        onChange={(event) => setName(event.target.value)}
                                    />
                                </div>

                                <div className="space-y-1">
                                    <label>Опис</label>
                                    <Textarea
                                        rows={4}
                                        value={description}
                                        disabled={busy}
                                        onChange={(event) => setDescription(event.target.value)}
                                    />
                                </div>
                            </div>

                            <div className="space-y-4 md:col-span-4">
                                <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-1">
                                    <div className="space-y-1">
                                        <label>Тип меню</label>
                                        <Select
                                            value={menuType}
                                            disabled={busy}
                                            onChange={(event) => setMenuType(event.target.value as MenuType)}
                                        >
                                            {MENU_TYPE_OPTIONS.map((option) => (
                                                <option key={option.value} value={option.value}>
                                                    {option.label}
                                                </option>
                                            ))}
                                        </Select>
                                    </div>

                                    <div className="space-y-1">
                                        <label>Прийом їжі *</label>
                                        <Select
                                            value={mealType}
                                            disabled={busy}
                                            onChange={(event) => setMealType(event.target.value as MealType | '')}
                                        >
                                            {MEAL_TYPE_OPTIONS.map((option) => (
                                                <option key={option.value} value={option.value}>
                                                    {option.label}
                                                </option>
                                            ))}
                                        </Select>
                                    </div>
                                </div>

                                <div className="grid gap-3 sm:grid-cols-2">
                                    <div className="space-y-1">
                                        <label>Активний час, хв</label>
                                        <Input
                                            inputMode="numeric"
                                            value={activeTime}
                                            disabled={busy}
                                            onChange={(event) => setActiveTime(event.target.value)}
                                        />
                                    </div>

                                    <div className="space-y-1">
                                        <label>Загальний час, хв *</label>
                                        <Input
                                            inputMode="numeric"
                                            value={totalTime}
                                            disabled={busy}
                                            onChange={(event) => setTotalTime(event.target.value)}
                                        />
                                    </div>
                                </div>

                                <div className="space-y-1">
                                    <label>Складність *</label>
                                    <div className="flex items-center justify-between gap-3">
                                        <StarRating
                                            value={complexityRating}
                                            disabled={busy}
                                            onChange={setComplexityRating}
                                        />
                                        <span className="w-10 text-right text-sm font-semibold">{complexityRating}/5</span>
                                    </div>
                                </div>
                            </div>
                        </Card>

                        <RecipeIngredientsStepsCard
                            ingredients={ingredients}
                            steps={steps}
                            disabled={busy}
                            minSteps={DEFAULT_STEPS}
                            servings={servings}
                            onServingsChange={setServings}
                            onAddIngredient={addIngredient}
                            onRemoveIngredient={removeIngredient}
                            onUpdateIngredient={updateIngredient}
                            onAddStep={addStep}
                            onUpdateStep={updateStep}
                            onClearOrRemoveStep={clearOrRemoveStep}
                        />
                    </form>
                </section>
            ) : null}
        </div>
    );
}
