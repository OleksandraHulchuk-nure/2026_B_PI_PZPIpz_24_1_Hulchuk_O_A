package com.nure.whatwecook.service;

import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.dto.ai.AiRecipeDraftDto;
import com.nure.whatwecook.dto.ai.AiRecipeGenerateRequestDto;

import java.util.UUID;

public interface AiRecipeService {

    AiRecipeDraftDto generateRecipeDraft(UUID userId, AiRecipeGenerateRequestDto request);

    Recipe saveGeneratedRecipe(UUID userId, AiRecipeDraftDto draft);

    Recipe generateRecipeForMenuSlot(UUID userId,
                                     MealType mealType,
                                     Integer maxTimeMinutes,
                                     String extraNotes);
}
