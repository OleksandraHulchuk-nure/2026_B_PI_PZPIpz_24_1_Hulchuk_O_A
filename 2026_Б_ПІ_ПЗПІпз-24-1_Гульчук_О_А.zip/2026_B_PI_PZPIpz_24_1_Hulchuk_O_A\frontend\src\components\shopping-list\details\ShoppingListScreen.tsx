'use client';

import {useEffect, useMemo, useState} from 'react';

import {Card, CardContent, CardHeader} from '@/components/ui/card';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Badge} from '@/components/ui/badge';

import type {ShoppingItemDto, ShoppingListResponseDto} from '@/lib/api/shoppingListApi';
import {getShoppingList, updateHaveQuantities} from '@/lib/api/shoppingListApi';
import {
    MEASUREMENT_UNIT_LABELS,
    PRODUCT_CATEGORY_LABELS,
    PRODUCT_CATEGORY_ORDER,
    ProductCategory,
} from '@/lib/constants/enums';
import {PageSection} from '@/components/page-section';
import {MaterialIcon} from '@/components/ui/materialIcon';
import {Alert} from "@/components/ui/alert";
import {downloadShoppingListReport} from "@/lib/api/reportsApi";
import {downloadBlob} from "@/lib/utils/download";

type LoadState = 'loading' | 'error' | 'ready';
type Notice = { type: 'success' | 'error' | 'info'; message: string } | null;

function clampNumber(n: number) {
    if (!Number.isFinite(n)) return 0;
    return Math.max(0, n);
}

function formatQty(n: number) {
    return Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100);
}

function groupByCategory(items: ShoppingItemDto[]) {
    const map = new Map<ProductCategory, ShoppingItemDto[]>();
    items.forEach((it) => {
        const arr = map.get(it.category) ?? [];
        arr.push(it);
        map.set(it.category, arr);
    });
    return map;
}

function lsKey(listId: string) {
    return `whatwecook:shopping:${listId}:have`;
}

export default function ShoppingListScreen({shoppingListId}: { shoppingListId: string }) {
    const [state, setState] = useState<LoadState>('loading');
    const [error, setError] = useState<string>('');

    const [list, setList] = useState<ShoppingListResponseDto | null>(null);

    const [haveById, setHaveById] = useState<Record<string, number>>({});
    const [baselineHaveById, setBaselineHaveById] = useState<Record<string, number>>({});

    const [saving, setSaving] = useState(false);
    const [notice, setNotice] = useState<Notice>(null);

    const [query, setQuery] = useState('');
    const [onlyToBuy, setOnlyToBuy] = useState(false);

    const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
    const [reportLoading, setReportLoading] = useState(false);

    useEffect(() => {
        if (!shoppingListId) return;

        let cancelled = false;

        (async () => {
            try {
                setState('loading');
                setError('');
                setNotice(null);

                const data = await getShoppingList(shoppingListId);
                if (cancelled) return;

                setList(data);

                const fromLs: Record<string, number> = (() => {
                    try {
                        const raw = localStorage.getItem(lsKey(shoppingListId));
                        if (!raw) return {};
                        const parsed = JSON.parse(raw) as Record<string, number>;
                        return parsed && typeof parsed === 'object' ? parsed : {};
                    } catch {
                        return {};
                    }
                })();

                const initialHave: Record<string, number> = {};
                data.items.forEach((it) => {
                    const apiHave = typeof it.haveQuantity === 'number' ? it.haveQuantity : undefined;
                    const lsHave = typeof fromLs[it.id] === 'number' ? fromLs[it.id] : undefined;
                    initialHave[it.id] = clampNumber(apiHave ?? lsHave ?? 0);
                });

                setHaveById(initialHave);
                setBaselineHaveById(initialHave);

                setState('ready');
            } catch (e) {
                if (cancelled) return;
                setState('error');
                setError(e instanceof Error ? e.message : 'Сталася помилка. Спробуйте ще раз.');
            }
        })();

        return () => {
            cancelled = true;
        };
    }, [shoppingListId]);

    useEffect(() => {
        if (!shoppingListId) return;
        try {
            localStorage.setItem(lsKey(shoppingListId), JSON.stringify(haveById));
        } catch {
        }
    }, [shoppingListId, haveById]);

    const filteredItems = useMemo(() => {
        const items = list?.items ?? [];
        const q = query.trim().toLowerCase();

        return items
            .filter((it) => {
                if (q && !it.ingredientNameUk.toLowerCase().includes(q)) return false;

                const have = clampNumber(haveById[it.id] ?? 0);
                const needed = clampNumber(it.neededQuantity ?? 0);
                const toBuy = clampNumber(needed - have);

                if (onlyToBuy && toBuy <= 0) return false;
                return true;
            })
            .sort((a, b) => a.ingredientNameUk.localeCompare(b.ingredientNameUk, 'uk'));
    }, [list, query, onlyToBuy, haveById]);

    const grouped = useMemo(() => groupByCategory(filteredItems), [filteredItems]);

    const dirtyCount = useMemo(() => {
        const ids = Object.keys(haveById);
        let cnt = 0;
        ids.forEach((id) => {
            const a = clampNumber(haveById[id] ?? 0);
            const b = clampNumber(baselineHaveById[id] ?? 0);
            if (a !== b) cnt += 1;
        });
        return cnt;
    }, [haveById, baselineHaveById]);

    const summary = useMemo(() => {
        const items = list?.items ?? [];
        let toBuyTotal = 0;
        items.forEach((it) => {
            const have = clampNumber(haveById[it.id] ?? 0);
            const needed = clampNumber(it.neededQuantity ?? 0);
            if (needed - have > 0) toBuyTotal += 1;
        });
        return {total: items.length, toBuyTotal};
    }, [list, haveById]);

    async function onRetry() {
        if (!shoppingListId) return;
        try {
            setState('loading');
            setError('');
            setNotice(null)
            const data = await getShoppingList(shoppingListId);
            setList(data);
            setState('ready');
        } catch (e) {
            setState('error');
            setError(e instanceof Error ? e.message : 'Сталася помилка. Спробуйте ще раз.');
        }
    }

    function setHave(itemId: string, value: string) {
        const num = clampNumber(Number(value));
        setHaveById((prev) => ({...prev, [itemId]: num}));
        setNotice(null);
    }

    function setHaveAllInCategory(category: ProductCategory) {
        const items = grouped.get(category) ?? [];
        setHaveById((prev) => {
            const next = {...prev};
            items.forEach((it) => {
                next[it.id] = clampNumber(it.neededQuantity ?? 0);
            });
            return next;
        });
        setNotice(null);
    }

    function clearHaveInCategory(category: ProductCategory) {
        const items = grouped.get(category) ?? [];
        setHaveById((prev) => {
            const next = {...prev};
            items.forEach((it) => {
                next[it.id] = 0;
            });
            return next;
        });
        setNotice(null);
    }

    function setHaveAllForItem(itemId: string, needed: number, checked: boolean) {
        setHaveById((prev) => ({
            ...prev,
            [itemId]: checked ? clampNumber(needed) : 0,
        }));
        setNotice(null);
    }

    function toggleCategory(cat: ProductCategory) {
        setCollapsed((prev) => ({...prev, [cat]: !prev[cat]}));
    }

    async function onSave() {
        if (!list) return;

        const updates: Array<{ itemId: string; haveQuantity: number }> = [];
        list.items.forEach((it) => {
            const a = clampNumber(haveById[it.id] ?? 0);
            const b = clampNumber(baselineHaveById[it.id] ?? 0);
            if (a !== b) updates.push({itemId: it.id, haveQuantity: a});
        });

        if (updates.length === 0) {
            setNotice({type: 'info', message: 'Немає змін для збереження.'});
            return;
        }

        try {
            setSaving(true);
            setNotice(null);
            const updated = await updateHaveQuantities(list.id, updates);

            setList(updated);
            setBaselineHaveById(haveById);
            setNotice({type: 'success', message: 'Зміни збережено.'});
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Не вдалося зберегти. Спробуйте ще раз.');
            setState('error');
        } finally {
            setSaving(false);
        }
    }

    async function onDownloadPdf() {
        if (!list) return;

        try {
            setReportLoading(true);
            setNotice(null);

            const blob = await downloadShoppingListReport(list.id);

            downloadBlob(blob, `shopping-list-${list.weekStart}.pdf`);
            setNotice({type: 'success', message: 'PDF список продуктів готовий для друку.'});
        } catch (e) {
            setNotice({
                type: 'error',
                message: e instanceof Error ? e.message : 'Не вдалося згенерувати PDF список продуктів.',
            });
        } finally {
            setReportLoading(false);
        }
    }

    if (!shoppingListId) {
        return (
            <div className="mx-auto max-w-5xl space-y-4 p-4 md:p-6">
                <Card className="p-4">
                    <div className="text-sm text-text-muted">Невірний ідентифікатор списку покупок.</div>
                </Card>
            </div>
        );
    }

    return (
        <div className="flex flex-col gap-6">
            <PageSection
                titleAs="h2"
                title="Список продуктів"
                subtitle="Вкажіть “є вдома” — ми порахуємо “купити”."
                titleAddon={
                    summary.total > 0 ? (
                        <div className="flex flex-wrap items-center gap-2">
                            <Badge variant="info">Позицій: {summary.total}</Badge>
                            <Badge variant="soft">Купити: {summary.toBuyTotal}</Badge>
                        </div>
                    ) : null
                }
                actions={
                    <div className="flex flex-wrap items-center gap-2">
                        <Button onClick={onSave} disabled={state !== 'ready' || saving || dirtyCount === 0}>
                            {saving ? 'Збереження…' : `Зберегти зміни${dirtyCount ? ` (${dirtyCount})` : ''}`}
                        </Button>
                        <Button
                            variant="secondary"
                            onClick={onDownloadPdf}
                            disabled={state !== 'ready' || !list || reportLoading}
                            title="Завантажити список продуктів у PDF"
                        >
                            {reportLoading ? 'Генеруємо PDF…' : 'Завантажити PDF'}
                        </Button>
                    </div>
                }
            />

            {notice && (
                <Alert
                    variant={notice.type === 'error' ? 'error' : notice.type === 'success' ? 'success' : 'info'}
                    title={notice.type === 'error' ? 'Помилка' : notice.type === 'success' ? 'Готово' : 'Нагадування'}
                >
                    {notice.message}
                </Alert>
            )}

            <Card className="space-y-3 p-4">
                <div className="grid gap-3 md:grid-cols-3 md:items-end">
                    <div className="space-y-1 md:col-span-2">
                        <label className="text-xs text-text-muted">Пошук</label>
                        <Input
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            placeholder="Наприклад: молоко, помідори…"
                            disabled={state === 'loading'}
                        />
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs text-text-muted">Фільтр</label>
                        <button
                            type="button"
                            className="flex w-full items-center justify-between rounded-lg border border-border bg-surface px-3 py-2 text-sm text-text-primary"
                            onClick={() => setOnlyToBuy((v) => !v)}
                            disabled={state === 'loading'}
                            aria-pressed={onlyToBuy}
                        >
                            <span>Показувати тільки “купити”</span>
                            <span className="text-text-muted">{onlyToBuy ? 'Так' : 'Ні'}</span>
                        </button>
                    </div>
                </div>

            </Card>

            {state === 'loading' && (
                <Card className="p-4">
                    <div className="text-sm text-text-muted">Завантаження списку…</div>
                </Card>
            )}

            {state === 'error' && (
                <Card className="space-y-3 p-4">
                    <div className="rounded-xl border border-error/30 bg-error/10 px-3 py-2 text-sm text-error">
                        {error || 'Сталася помилка. Спробуйте ще раз.'}
                    </div>
                    <div className="flex gap-2">
                        <Button onClick={onRetry}>Спробувати ще раз</Button>
                    </div>
                </Card>
            )}

            {state === 'ready' && (list?.items?.length ?? 0) === 0 && (
                <Card className="p-4">
                    <div className="text-sm text-text-muted">Список продуктів порожній.</div>
                </Card>
            )}

            {state === 'ready' && (list?.items?.length ?? 0) > 0 && (
                <div className="space-y-3">
                    {PRODUCT_CATEGORY_ORDER.map((cat) => {
                        const items = grouped.get(cat);
                        if (!items || items.length === 0) return null;

                        const isCollapsed = Boolean(collapsed[cat]);

                        const toBuyCount = items.reduce((acc, it) => {
                            const have = clampNumber(haveById[it.id] ?? 0);
                            const needed = clampNumber(it.neededQuantity ?? 0);
                            return acc + (needed - have > 0 ? 1 : 0);
                        }, 0);

                        const categoryHaveAll =
                            items.length > 0 &&
                            items.every((it) => {
                                const needed = clampNumber(it.neededQuantity ?? 0);
                                const have = clampNumber(haveById[it.id] ?? 0);
                                return needed === 0 || have >= needed;
                            });

                        return (
                            <Card key={cat} className="p-0">
                                <CardHeader
                                    className="px-4 py-2 flex flex-wrap items-center justify-between gap-2 cursor-pointer select-none"
                                    role="button"
                                    tabIndex={0}
                                    aria-expanded={!isCollapsed}
                                    onClick={() => toggleCategory(cat)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            e.preventDefault();
                                            toggleCategory(cat);
                                        }
                                    }}
                                >
                                    <div className="flex min-w-0 items-center gap-2">
                                        <MaterialIcon
                                            name={isCollapsed ? 'expand_circle_right' : 'expand_circle_down'}
                                            className="text-[20px] text-text-muted"
                                        />

                                        <h2 className="truncate text-sm font-semibold text-text-primary">
                                            {PRODUCT_CATEGORY_LABELS[cat]}
                                        </h2>

                                        <div className="hidden sm:flex flex-wrap items-center gap-2">
                                            <Badge variant="info">Позицій: {items.length}</Badge>
                                            <Badge variant="soft">Купити: {toBuyCount}</Badge>
                                        </div>
                                    </div>

                                    <div
                                        className="flex items-center gap-3"
                                        onClick={(e) => e.stopPropagation()}
                                        onKeyDown={(e) => e.stopPropagation()}
                                    >
                                        <div className="flex sm:hidden flex-wrap items-center gap-2">
                                            <Badge variant="info">Позицій: {items.length}</Badge>
                                            <Badge variant="soft">Купити: {toBuyCount}</Badge>
                                        </div>

                                        <label className="inline-flex items-center gap-2 text-xs text-text-muted">
                                            <input
                                                type="checkbox"
                                                className="h-4 w-4 accent-primary"
                                                checked={categoryHaveAll}
                                                onChange={(e) => {
                                                    const checked = e.target.checked;
                                                    if (checked) setHaveAllInCategory(cat);
                                                    else clearHaveInCategory(cat);
                                                }}
                                                disabled={saving}
                                                aria-label="Є все вдома (для категорії)"
                                                title={categoryHaveAll ? 'Усе є вдома' : 'Позначити, що все є вдома'}
                                            />
                                            <span className="whitespace-nowrap">Є все</span>
                                        </label>
                                    </div>
                                </CardHeader>

                                {!isCollapsed && (
                                    <CardContent className="p-0">
                                        <div className="max-w-full overflow-x-auto">
                                            <table className="w-full min-w-[700px] border-collapse text-xs">
                                                <thead className="hidden md:table-header-group">
                                                <tr className="bg-primary-soft/60 text-[11px] uppercase tracking-[0.08em] text-text-muted">
                                                    <th className="px-2.5 py-1.5 text-left font-semibold">Продукт</th>
                                                    <th className="px-2.5 py-1.5 text-right font-semibold">Потрібно</th>
                                                    <th className="px-2.5 py-1.5 text-right font-semibold">Є вдома
                                                        (кільк.)
                                                    </th>
                                                    <th className="px-2.5 py-1.5 text-right font-semibold">Купити</th>
                                                    <th className="px-2.5 py-1.5 text-center font-semibold">Є все</th>
                                                </tr>
                                                </thead>

                                                <tbody className="divide-y divide-border">
                                                {items.map((it) => {
                                                    const have = clampNumber(haveById[it.id] ?? 0);
                                                    const needed = clampNumber(it.neededQuantity ?? 0);
                                                    const toBuy = clampNumber(needed - have);
                                                    const unitLabel = MEASUREMENT_UNIT_LABELS[it.unit] ?? it.unit;

                                                    const haveAll = needed > 0 && have >= needed;

                                                    return (
                                                        <tr key={it.id} className="hover:bg-background/70">
                                                            <td className="px-2.5 py-1.5">
                                                                <div className="min-w-0">
                                                                    <div
                                                                        className="truncate text-sm font-medium text-text-primary">
                                                                        {it.ingredientNameUk}
                                                                    </div>

                                                                    <div
                                                                        className="mt-0.5 text-[11px] text-text-muted md:hidden">
                                                                        Потрібно {formatQty(needed)} {unitLabel}
                                                                        <span className="px-1">•</span>
                                                                        <span
                                                                            className={toBuy > 0 ? 'font-semibold text-text-primary' : ''}>
                                                                                Купити {formatQty(toBuy)} {unitLabel}
                                                                            </span>
                                                                    </div>
                                                                </div>
                                                            </td>

                                                            <td className="hidden px-2.5 py-1.5 text-right md:table-cell">
                                                                {formatQty(needed)}{' '}
                                                                <span className="text-text-muted">{unitLabel}</span>
                                                            </td>

                                                            <td className="px-2.5 py-1.5">
                                                                <div className="flex items-center justify-end gap-2">
                                                                    <Input
                                                                        type="number"
                                                                        inputMode="decimal"
                                                                        value={String(have)}
                                                                        onChange={(e) => setHave(it.id, e.target.value)}
                                                                        className="h-7 w-[68px] text-xs"
                                                                        disabled={saving}
                                                                        aria-label="Є вдома (кількість)"
                                                                    />
                                                                    <span
                                                                        className="text-[11px] text-text-muted">{unitLabel}</span>
                                                                </div>
                                                            </td>

                                                            <td className="px-2.5 py-1.5 text-right">
                                                                    <span
                                                                        className={
                                                                            toBuy > 0 ? 'font-semibold text-text-primary' : 'text-text-muted'
                                                                        }
                                                                    >
                                                                        {formatQty(toBuy)}
                                                                    </span>{' '}
                                                                <span className="text-text-muted">{unitLabel}</span>
                                                            </td>

                                                            <td className="px-2.5 py-1.5 text-center">
                                                                <label
                                                                    className="inline-flex items-center justify-center">
                                                                    <input
                                                                        type="checkbox"
                                                                        className="h-4 w-4 accent-primary"
                                                                        checked={haveAll}
                                                                        onChange={(e) => setHaveAllForItem(it.id, needed, e.target.checked)}
                                                                        disabled={saving || needed === 0}
                                                                        aria-label="Є все вдома (для продукту)"
                                                                        title={haveAll ? 'Усе є вдома' : 'Позначити, що усе є вдома'}
                                                                    />
                                                                </label>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                                </tbody>
                                            </table>
                                        </div>
                                    </CardContent>
                                )}
                            </Card>
                        );
                    })}
                </div>
            )}
        </div>
    );
}

