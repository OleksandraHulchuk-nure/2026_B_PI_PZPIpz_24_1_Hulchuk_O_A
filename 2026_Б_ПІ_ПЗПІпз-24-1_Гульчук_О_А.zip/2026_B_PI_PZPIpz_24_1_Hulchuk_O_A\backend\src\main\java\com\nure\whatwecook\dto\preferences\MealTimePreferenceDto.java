package com.nure.whatwecook.dto.preferences;

import com.nure.whatwecook.domain.enums.MealType;
import lombok.Data;

@Data
public class MealTimePreferenceDto {

    private MealType mealType;
    private Integer maxCookingTimeMinutes;
}
