package com.nure.whatwecook.dto.recipe;

import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MenuType;
import com.nure.whatwecook.domain.enums.RecipeSourceType;
import com.nure.whatwecook.domain.enums.RecipeStatus;
import lombok.Data;

import java.util.UUID;

@Data
public class RecipeListItemDto {

    private UUID id;
    private String name;
    private RecipeSourceType sourceType;
    private RecipeStatus status;
    private MenuType menuType;
    private MealType mealType;
    private Integer totalTimeMinutes;
    private Integer activeCookingTimeMinutes;
    private Integer defaultServings;
    private Integer complexityRating;
    private Integer tasteRating;
}
