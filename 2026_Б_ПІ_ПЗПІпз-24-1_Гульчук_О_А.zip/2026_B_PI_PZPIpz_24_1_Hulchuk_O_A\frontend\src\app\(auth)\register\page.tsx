'use client';

import {useState, type FormEvent} from 'react';
import Link from 'next/link';
import {useRouter} from 'next/navigation';

import {registerUser} from '@/lib/api/authApi';
import {saveAuthToken} from '@/lib/auth/tokenStorage';
import {Card} from '@/components/ui/card';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Alert} from "@/components/ui/alert";

export default function RegisterPage() {
    const router = useRouter();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        setError(null);

        if (!email || !email.includes('@')) {
            setError('Будь ласка, введіть коректний email.');
            return;
        }

        if (!password || password.length < 6) {
            setError('Пароль має містити щонайменше 6 символів.');
            return;
        }

        if (password !== confirmPassword) {
            setError('Паролі не співпадають.');
            return;
        }

        setIsSubmitting(true);

        try {
            const auth = await registerUser({email, password});
            saveAuthToken(auth);

            router.push('/');
        } catch (err) {
            const message =
                err instanceof Error
                    ? err.message
                    : 'Сталася помилка під час реєстрації. Спробуйте ще раз.';
            setError(message);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <Card className="w-full max-w-md">
            <h1 className="mb-1 text-2xl font-bold">Створити акаунт</h1>
            <p className="mb-6 text-sm text-text-muted">
                Введіть email і пароль, щоб розпочати планувати сімейні страви.
            </p>

            <form className="space-y-4" onSubmit={handleSubmit} noValidate>
                <div>
                    <label
                        htmlFor="email"
                        className="mb-1 block text-xs font-semibold uppercase tracking-[0.08em] text-text-muted"
                    >
                        Email
                    </label>
                    <Input
                        id="email"
                        type="email"
                        autoComplete="email"
                        placeholder="family@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </div>

                <div>
                    <label
                        htmlFor="password"
                        className="mb-1 block text-xs font-semibold uppercase tracking-[0.08em] text-text-muted"
                    >
                        Пароль
                    </label>
                    <Input
                        id="password"
                        type="password"
                        autoComplete="new-password"
                        placeholder="Мінімум 6 символів"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </div>

                <div>
                    <label
                        htmlFor="confirmPassword"
                        className="mb-1 block text-xs font-semibold uppercase tracking-[0.08em] text-text-muted"
                    >
                        Підтвердження пароля
                    </label>
                    <Input
                        id="confirmPassword"
                        type="password"
                        autoComplete="new-password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                </div>

                {error && (
                    <Alert variant="error">
                        {error}
                    </Alert>
                )}

                <Button
                    type="submit"
                    className="w-full justify-center"
                    disabled={isSubmitting}
                >
                    {isSubmitting ? 'Реєстрація...' : 'Зареєструватися'}
                </Button>
            </form>

            <p className="mt-4 text-center text-sm text-text-muted">
                Вже маєте акаунт?{' '}
                <Link href="/login" className="font-medium text-primary hover:underline">
                    Увійти
                </Link>
            </p>
        </Card>
    );
}
