package com.nure.whatwecook.service.reports;

import com.nure.whatwecook.domain.enums.MenuStatus;
import com.nure.whatwecook.domain.enums.RecipeSourceType;
import com.nure.whatwecook.domain.enums.RecipeStatus;
import com.nure.whatwecook.dto.stats.StatPeriodAiMetricsDto;
import com.nure.whatwecook.dto.stats.StatPeriodMenuMetricsDto;
import com.nure.whatwecook.dto.stats.StatPeriodTopCategoriesDto;
import com.nure.whatwecook.dto.stats.StatPeriodTopIngredientsDto;
import com.nure.whatwecook.repository.statistics.StatsPeriodRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.UUID;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class StatsPeriodService {

    private static final int DEFAULT_LIMIT = 10;
    private static final int PCT_SCALE = 4;

    private final StatsPeriodRepository repository;

    public StatPeriodAiMetricsDto getAiMetrics(LocalDate from, LocalDate to, UUID userId) {
        validatePeriod(from, to);

        String approvedStatus = MenuStatus.APPROVED.name();
        String aiSourceType = RecipeSourceType.AI.name();
        String verifiedStatus = RecipeStatus.VERIFIED.name();
        String rejectedStatus = RecipeStatus.REJECTED.name();

        var aiAgg = repository.getAiAggregate(userId, approvedStatus, from, to, aiSourceType, verifiedStatus, rejectedStatus);

        Integer allMeals = nz(aiAgg.getAllMeals());
        Integer aiMeals = nz(aiAgg.getAiMeals());
        Integer verifiedCnt = nz(aiAgg.getVerifiedCnt());
        Integer rejectedCnt = nz(aiAgg.getRejectedCnt());
        Integer ratedCnt = nz(aiAgg.getRatedCnt());

        BigDecimal aiSharePct = ratio(aiMeals, allMeals);
        BigDecimal successPct = ratio(verifiedCnt, verifiedCnt + rejectedCnt);
        BigDecimal ratedPct = ratio(ratedCnt, aiMeals);

        var aiPeriod = new StatPeriodAiMetricsDto.AiPeriodStatsDto(
                allMeals,
                aiMeals,
                aiSharePct,
                verifiedCnt,
                rejectedCnt,
                successPct,
                ratedCnt,
                ratedPct,
                aiAgg.getAvgTaste()
        );
        return new StatPeriodAiMetricsDto(from, to, aiPeriod);
    }

    public StatPeriodMenuMetricsDto getMenuMetrics(LocalDate from, LocalDate to, UUID userId) {
        validatePeriod(from, to);

        String approvedStatus = MenuStatus.APPROVED.name();

        Integer streakWeeksMax = nz(repository.getMaxStreakWeeksInPeriod(userId, approvedStatus, from, to));

        BigDecimal avgCookingTimePerDay = repository.getAvgCookingTimePerDay(userId, approvedStatus, from, to);

        var timeCounts = repository.getTimeAdherenceCounts(userId, approvedStatus, from, to);
        var timeAdherence = new StatPeriodMenuMetricsDto.RatioDto(
                nz(timeCounts.getTimeConstraintsCnt()),
                nz(timeCounts.getWithinTimeCnt()),
                ratio(timeCounts.getWithinTimeCnt(), timeCounts.getTimeConstraintsCnt())
        );

        BigDecimal avgComplexity = repository.getAvgComplexity(userId, approvedStatus, from, to);

        var complexityCounts = repository.getComplexityAdherenceCounts(userId, approvedStatus, from, to);
        var complexityAdherence = new StatPeriodMenuMetricsDto.RatioDto(
                nz(complexityCounts.getComplexityConstraintsCnt()),
                nz(complexityCounts.getWithinComplexityCnt()),
                ratio(complexityCounts.getWithinComplexityCnt(), complexityCounts.getComplexityConstraintsCnt())
        );

        BigDecimal approvalSpeedMinutesAvg = repository.getApprovalSpeedMinutesAvg(userId, approvedStatus, from, to);

        return new StatPeriodMenuMetricsDto(
                from,
                to,
                streakWeeksMax,
                avgCookingTimePerDay,
                timeAdherence,
                avgComplexity,
                complexityAdherence,
                approvalSpeedMinutesAvg
        );
    }

    public StatPeriodTopCategoriesDto getTopCategories(LocalDate from, LocalDate to, Integer limit, boolean includeOptional, UUID userId) {
        validatePeriod(from, to);

        int topLimit = normalizeLimit(limit);
        String approvedStatus = MenuStatus.APPROVED.name();

        var items = repository.getTopIngredientCategories(userId, approvedStatus, from, to, topLimit, includeOptional)
                .stream()
                .map(p -> new StatPeriodTopCategoriesDto.ItemDto(p.getIngredientCategory(), p.getItemsCnt()))
                .toList();

        return new StatPeriodTopCategoriesDto(from, to, topLimit, includeOptional, items);
    }

    public StatPeriodTopIngredientsDto getTopIngredients(LocalDate from, LocalDate to, Integer limit, boolean includeOptional, UUID userId) {
        validatePeriod(from, to);

        int topLimit = normalizeLimit(limit);
        String approvedStatus = MenuStatus.APPROVED.name();

        var items = repository.getTopIngredients(userId, approvedStatus, from, to, topLimit, includeOptional)
                .stream()
                .map(p -> new StatPeriodTopIngredientsDto.ItemDto(
                        p.getIngredientId(),
                        p.getIngredientNameUk(),
                        p.getRiUnit(),
                        p.getTotalQuantity()
                ))
                .toList();

        return new StatPeriodTopIngredientsDto(from, to, topLimit, includeOptional, items);
    }

    private static void validatePeriod(LocalDate from, LocalDate to) {
        if (from == null || to == null) {
            throw new ResponseStatusException(BAD_REQUEST, "from/to are required");
        }
        if (from.isAfter(to)) {
            throw new ResponseStatusException(BAD_REQUEST, "from must be <= to");
        }
    }

    private static int normalizeLimit(Integer limit) {
        if (limit == null || limit <= 0) return DEFAULT_LIMIT;
        return limit;
    }

    private static int nz(Integer v) {
        return v == null ? 0 : v;
    }

    private static BigDecimal ratio(Integer num, Integer denom) {
        if (num == null || denom == null || denom <= 0) return null;
        return BigDecimal.valueOf(num)
                .divide(BigDecimal.valueOf(denom), PCT_SCALE, RoundingMode.HALF_UP);
    }
}
