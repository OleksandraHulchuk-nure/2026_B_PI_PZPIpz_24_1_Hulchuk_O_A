'use client';

import React from 'react';
import {Select} from '@/components/ui/select';
import {Input} from '@/components/ui/input';

export type Preset = 'WEEK' | 'MONTH' | 'HALF_YEAR' | 'YEAR' | 'CUSTOM';

function parseDate(value: string): Date | null {
    if (!value) return null;
    const d = new Date(`${value}T00:00:00`);
    return Number.isNaN(d.getTime()) ? null : d;
}

function formatDate(d: Date): string {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
}

function todayLocal(): Date {
    const t = new Date();
    t.setHours(0, 0, 0, 0);
    return t;
}

function addDays(d: Date, days: number): Date {
    const x = new Date(d);
    x.setDate(x.getDate() + days);
    return x;
}

function addMonths(d: Date, months: number): Date {
    const x = new Date(d);
    const day = x.getDate();
    x.setMonth(x.getMonth() + months);
    if (x.getDate() < day) x.setDate(0);
    return x;
}

function addYears(d: Date, years: number): Date {
    const x = new Date(d);
    x.setFullYear(x.getFullYear() + years);
    return x;
}

function calcEndDate(start: string, preset: Preset): string {
    const s = parseDate(start);
    if (!s) return start;

    let end: Date;
    switch (preset) {
        case 'WEEK':
            end = addDays(s, 6);
            break;
        case 'MONTH':
            end = addDays(addMonths(s, 1), -1);
            break;
        case 'HALF_YEAR':
            end = addDays(addMonths(s, 6), -1);
            break;
        case 'YEAR':
            end = addDays(addYears(s, 1), -1);
            break;
        default:
            end = s;
    }
    return formatDate(end);
}

function calcRangeFromToday(preset: Preset): { start: string; end: string } {
    const end = todayLocal();
    const endIso = formatDate(end);

    let start: Date;
    switch (preset) {
        case 'WEEK':
            start = addDays(end, -6);
            break;
        case 'MONTH':
            // start = (today - 1 month) + 1 day
            start = addDays(addMonths(end, -1), 1);
            break;
        case 'HALF_YEAR':
            start = addDays(addMonths(end, -6), 1);
            break;
        case 'YEAR':
            start = addDays(addYears(end, -1), 1);
            break;
        default:
            start = end;
    }

    return {start: formatDate(start), end: endIso};
}

export function StatsFilters(props: {
    preset: Preset;
    startDate: string;
    endDate: string;
    loading: boolean;
    onPresetChange: (p: Preset) => void;
    onStartDateChange: (v: string) => void;
    onEndDateChange: (v: string) => void;
    onReload: () => void;
}) {
    const {preset, startDate} = props;

    const onPresetSelect = (p: Preset) => {
        props.onPresetChange(p);

        if (p === 'CUSTOM') return;

        const range = calcRangeFromToday(p);
        props.onStartDateChange(range.start);
        props.onEndDateChange(range.end);
    };

    const onStartChange = (v: string) => {
        props.onStartDateChange(v);

        if (preset !== 'CUSTOM') {
            props.onEndDateChange(calcEndDate(v, preset));
        }
    };

    const onEndChange = (v: string) => {
        props.onPresetChange('CUSTOM');
        props.onEndDateChange(v);
    };

    return (
        <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
                <div className="text-[18px] font-bold">Статистика</div>
                <div className="text-xs text-text-muted">Оберіть період — KPI та графіки перерахуються</div>
            </div>

            <div className="flex flex-wrap items-end gap-2">
                <div className="w-[170px]">
                    <div className="mb-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted">Період
                    </div>
                    <Select value={preset} onChange={(e) => onPresetSelect(e.target.value as Preset)}>
                        <option value="WEEK">Тиждень</option>
                        <option value="MONTH">Місяць</option>
                        <option value="HALF_YEAR">Півроку</option>
                        <option value="YEAR">Рік</option>
                        <option value="CUSTOM">Свій</option>
                    </Select>
                </div>

                <div className="w-[150px]">
                    <div className="mb-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted">Від
                    </div>
                    <Input type="date" value={startDate} onChange={(e) => onStartChange(e.target.value)}/>
                </div>

                <div className="w-[150px]">
                    <div className="mb-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted">До</div>
                    <Input
                        type="date"
                        value={props.endDate}
                        onChange={(e) => onEndChange(e.target.value)}
                        disabled={preset !== 'CUSTOM'}
                    />
                </div>
            </div>
        </div>
    );
}
