package com.nure.whatwecook.dto.shopping;

import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
public class ShoppingItemUpdateDto {

    private UUID itemId;
    private BigDecimal haveQuantity;
}
