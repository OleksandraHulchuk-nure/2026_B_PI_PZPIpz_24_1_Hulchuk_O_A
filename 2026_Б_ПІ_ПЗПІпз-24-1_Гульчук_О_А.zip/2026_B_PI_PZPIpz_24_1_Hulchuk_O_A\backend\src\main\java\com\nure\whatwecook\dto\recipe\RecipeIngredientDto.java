package com.nure.whatwecook.dto.recipe;

import com.nure.whatwecook.domain.enums.MeasurementUnit;
import com.nure.whatwecook.domain.enums.ProductCategory;
import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
public class RecipeIngredientDto {

    private UUID ingredientId;
    private String ingredientNameUk;
    private ProductCategory category;
    private MeasurementUnit defaultUnit;
    private BigDecimal quantity;
    private MeasurementUnit unit;
    private boolean optional;
}
