package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.enums.ProductCategory;
import com.nure.whatwecook.repository.projection.IngredientMatchProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface IngredientRepository extends JpaRepository<Ingredient, UUID> {

    List<Ingredient> findByNameUkContainingIgnoreCase(String search);

    List<Ingredient> findByCategory(ProductCategory category);

    List<Ingredient> findByCategoryAndNameUkContainingIgnoreCase(ProductCategory category, String search);

    List<Ingredient> findByIdIn(Collection<UUID> ids);

    Optional<Ingredient> findFirstByNameUkIgnoreCase(String nameUk);

    Optional<Ingredient> findFirstByNameEnIgnoreCase(String nameEn);

    @Query(value = """
            select
                i.id as id,
                i.name_uk as nameUk,
                i.name_en as nameEn,
                i.category as category,
                i.default_unit as defaultUnit,
                greatest(
                    similarity(lower(i.name_uk), lower(:search)),
                    similarity(lower(coalesce(i.name_en, '')), lower(:search))
                ) as matchScore
            from ingredient i
            where (:category is null or i.category = :category)
              and greatest(
                    similarity(lower(i.name_uk), lower(:search)),
                    similarity(lower(coalesce(i.name_en, '')), lower(:search))
                ) >= :threshold
            order by matchScore desc, i.name_uk asc
            limit 5
            """, nativeQuery = true)
    List<IngredientMatchProjection> searchIngredientMatches(@Param("search") String search,
                                                            @Param("category") String category,
                                                            @Param("threshold") double threshold);
}
