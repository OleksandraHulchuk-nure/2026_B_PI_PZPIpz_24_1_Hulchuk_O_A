'use client';

import * as React from 'react';
import { Input } from '@/components/ui/input';
import { searchIngredients, type Ingredient } from '@/lib/api/ingredientApi';
import { UNIT_OPTIONS } from '@/lib/api/recipeApi';

function unitLabel(u?: string) {
    const hit = UNIT_OPTIONS.find((x) => x.value === u);
    return hit?.label ?? u ?? '';
}

export function IngredientAutocomplete({
                                           value,
                                           onValueChange,
                                           onPick,
                                           placeholder,
                                           disabled,
                                       }: {
    value: string;
    onValueChange: (v: string) => void;
    onPick: (i: Ingredient) => void;
    placeholder?: string;
    disabled?: boolean;
}) {
    const [open, setOpen] = React.useState(false);
    const [loading, setLoading] = React.useState(false);
    const [items, setItems] = React.useState<Ingredient[]>([]);
    const [err, setErr] = React.useState<string | null>(null);

    React.useEffect(() => {
        const q = value.trim();
        setErr(null);

        if (q.length < 2) {
            setItems([]);
            setLoading(false);
            return;
        }

        const t = window.setTimeout(async () => {
            try {
                setLoading(true);
                const data = await searchIngredients(q);
                setItems(data);
            } catch {
                setErr('Не вдалося завантажити підказки.');
            } finally {
                setLoading(false);
            }
        }, 250);

        return () => window.clearTimeout(t);
    }, [value]);

    const handlePick = (i: Ingredient) => {
        onPick(i);
        setOpen(false);
        setItems([]);
    };

    return (
        <div className="relative">
            <Input
                value={value}
                placeholder={placeholder}
                disabled={disabled}
                onFocus={() => setOpen(true)}
                onBlur={() => window.setTimeout(() => setOpen(false), 120)}
                onChange={(e) => {
                    onValueChange(e.target.value);
                    setOpen(true);
                }}
            />

            {open && (loading || err || items.length > 0) && (
                <div className="absolute z-10 mt-1 w-full overflow-hidden rounded-xl border border-border bg-surface shadow-sm">
                    {loading && <div className="px-3 py-2 text-xs text-text-muted">Пошук…</div>}
                    {!loading && err && <div className="px-3 py-2 text-xs text-error">{err}</div>}
                    {!loading && !err && items.length === 0 && value.trim().length >= 2 && (
                        <div className="px-3 py-2 text-xs text-text-muted">Нічого не знайдено</div>
                    )}

                    {!loading &&
                        !err &&
                        items.map((i) => (
                            <button
                                key={i.id}
                                type="button"
                                className="flex w-full items-center justify-between gap-3 px-3 py-2 text-left text-sm hover:bg-background"
                                onMouseDown={(e) => e.preventDefault()}
                                onClick={() => handlePick(i)}
                            >
                                <span className="truncate">{i.name}</span>
                                <span className="shrink-0 text-[11px] text-text-muted">
                  {i.defaultUnit ? `од.: ${unitLabel(i.defaultUnit)}` : ''}
                </span>
                            </button>
                        ))}
                </div>
            )}
        </div>
    );
}
