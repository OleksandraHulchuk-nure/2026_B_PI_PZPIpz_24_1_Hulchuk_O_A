import WeeklyMenuPageClient from '@/components/weekly-menu/WeeklyMenuPageClient';

export default function WeeklyMenuPage() {

    return <WeeklyMenuPageClient/>;
}
