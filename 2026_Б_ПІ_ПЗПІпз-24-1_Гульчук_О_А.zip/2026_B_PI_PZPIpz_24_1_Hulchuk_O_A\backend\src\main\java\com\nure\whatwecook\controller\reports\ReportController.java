package com.nure.whatwecook.controller.reports;

import com.nure.whatwecook.config.security.CurrentUserProvider;
import com.nure.whatwecook.service.helper.pdf.PdfDocument;
import com.nure.whatwecook.service.reports.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@Tag(name = "Reports", description = "Get pdf reports")
@Slf4j
@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final CurrentUserProvider currentUserProvider;
    private final ReportService reportService;


    @Operation(summary = "Generate weekly menu PDF by weekly menu ID")
    @GetMapping(value = "/weekly-menu/{weeklyMenuId}", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> weeklyMenu(
            @PathVariable UUID weeklyMenuId
    ) {
        UUID userId = currentUserProvider.getCurrentUserId();
        PdfDocument report = reportService.generateWeeklyMenuPdf(userId, weeklyMenuId);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=" + report.filename())
                .contentType(MediaType.APPLICATION_PDF)
                .body(report.content());
    }

    @Operation(summary = "Export shopping list as PDF by shopping list ID")
    @GetMapping(value = "/shopping-list/{shoppingListId}", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> exportShoppingList(@PathVariable UUID shoppingListId) {
        UUID userId = currentUserProvider.getCurrentUserId();
        PdfDocument report = reportService.generateWeeklyShoppingListPdf(userId, shoppingListId);

        log.info("Generated shopping list PDF report for user {} and shopping list {} with filename {}",
                userId, shoppingListId, report.filename());

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=" + report.filename())
                .contentType(MediaType.APPLICATION_PDF)
                .body(report.content());
    }
}
