package com.nure.whatwecook.service.reports.pdf.generator;

import com.nure.whatwecook.repository.reports.WeeklyMenuReportQueryRepository;
import com.nure.whatwecook.service.helper.pdf.PdfDocument;
import com.nure.whatwecook.service.helper.pdf.PdfRenderService;
import com.nure.whatwecook.service.reports.pdf.PdfReportGenerator;
import com.nure.whatwecook.service.reports.pdf.PdfReportType;
import com.nure.whatwecook.service.reports.pdf.request.WeeklyMenuPdfRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@RequiredArgsConstructor
public class WeeklyMenuPdfGenerator implements PdfReportGenerator<WeeklyMenuPdfRequest> {

    private final WeeklyMenuReportQueryRepository repo;
    private final PdfRenderService pdf;

    @Override
    public PdfReportType type() {
        return PdfReportType.WEEKLY_MENU;
    }

    @Override
    public Class<WeeklyMenuPdfRequest> requestType() {
        return WeeklyMenuPdfRequest.class;
    }

    @Override
    public PdfDocument generate(WeeklyMenuPdfRequest rq) {
        var dto = repo.loadWeeklyMenuReport(rq.userId(), rq.weeklyMenuId());
        String filename = "weekly-menu-" + dto.startDate() + ".pdf";
        byte[] content = pdf.render("reports/weekly-menu", Map.of("menu", dto));
        return new PdfDocument(filename, content);
    }
}
