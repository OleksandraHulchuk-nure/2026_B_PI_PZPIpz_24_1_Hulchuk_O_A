package com.nure.whatwecook.service.reports.pdf;

import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MeasurementUnit;
import com.nure.whatwecook.domain.enums.MenuStatus;
import com.nure.whatwecook.domain.enums.ProductCategory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.function.Function;

@Slf4j
@Component("labels")
public class ReportLabels {

    private static final Locale UK = Locale.forLanguageTag("uk");
    private static final DateTimeFormatter DATE_UA = DateTimeFormatter.ofPattern("dd.MM.yyyy", UK);

    public String menuStatus(String code) {
        return mapEnum(code, MenuStatus.class, MenuStatus::getUkrainianName);
    }

    public String mealType(String code) {
        return mapEnum(code, MealType.class, MealType::getUkrainianName);
    }

    public String unit(String code) {
        return mapEnum(code, MeasurementUnit.class, MeasurementUnit::getUkrainianName);
    }

    public String productCategory(String code) {
        return mapEnum(code, ProductCategory.class, ProductCategory::getUkrainianName);
    }

    public String qty(double value) {
        return qty(BigDecimal.valueOf(value));
    }

    public String qty(BigDecimal value) {
        if (value == null) return "—";
        BigDecimal bd = value.stripTrailingZeros();
        if (bd.scale() < 0) bd = bd.setScale(0);
        return bd.toPlainString();
    }

    public String pct(BigDecimal value) {
        if (value == null) return "0";
        return formatNumber(value);
    }

    public String date(LocalDate date) {
        if (date == null) return "—";
        return DATE_UA.format(date);
    }

    private String formatNumber(BigDecimal value) {
        BigDecimal bd = value.stripTrailingZeros();
        if (bd.scale() < 0) bd = bd.setScale(0);
        return bd.toPlainString();
    }

    private <E extends Enum<E>> String mapEnum(String code, Class<E> type, Function<E, String> label) {
        if (code == null || code.isBlank()) return "—";
        try {
            return label.apply(Enum.valueOf(type, code));
        } catch (IllegalArgumentException ex) {
            log.warn("Unknown enum value for {}: {}", type.getSimpleName(), code);
            return code;
        }
    }
}
