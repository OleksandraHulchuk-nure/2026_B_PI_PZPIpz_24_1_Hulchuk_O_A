package com.nure.whatwecook.domain.entity.profile;

import com.nure.whatwecook.domain.enums.MealType;
import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Table(
        name = "user_meal_preference",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_user_meal_pref_user_meal_type",
                        columnNames = {"user_id", "meal_type"}
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserMealPreference {

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(name = "meal_type", nullable = false, length = 50)
    private MealType mealType;

    @Column(name = "max_cooking_time_minutes", nullable = false)
    private Integer maxCookingTimeMinutes;

    @PrePersist
    public void prePersist() {
        if (id == null) {
            id = UUID.randomUUID();
        }
    }
}
