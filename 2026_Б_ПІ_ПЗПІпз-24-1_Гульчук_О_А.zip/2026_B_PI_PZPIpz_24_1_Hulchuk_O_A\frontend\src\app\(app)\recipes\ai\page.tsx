import {AiRecipePageClient} from '@/components/recipes/ai/AiRecipePageClient';

export default function AiRecipePage() {
    return <AiRecipePageClient/>;
}
