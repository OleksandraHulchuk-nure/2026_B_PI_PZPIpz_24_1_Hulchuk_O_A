import { apiFetch } from '@/lib/api/apiClient';
import { API_ROUTES } from '@/lib/api/endpoints';
import type { MealType, MenuType } from '@/lib/constants/enums';

export type { MealType, MenuType } from '@/lib/constants/enums';

export interface UserProfile {
    id: string;
    email: string;
    name: string | null;
    familySize: number | null;
    simplicity: number | null;
    menuType: MenuType | null;
    existingRecipeRatio: number | null;
}

export interface UpdateUserProfilePayload {
    name: string;
    familySize: number;
    simplicity: number;
    menuType: MenuType;
    existingRecipeRatio: number;
}

export interface MealTimePreference {
    mealType: MealType;
    maxCookingTimeMinutes: number;
}

export async function getUserProfile(): Promise<UserProfile> {
    return apiFetch<UserProfile>(API_ROUTES.profile);
}

export async function updateUserProfile(
    payload: UpdateUserProfilePayload,
): Promise<UserProfile> {
    return apiFetch<UserProfile>(API_ROUTES.profile, {
        method: 'PUT',
        body: JSON.stringify(payload),
    });
}

export async function getMealTimePreferences(): Promise<MealTimePreference[]> {
    return apiFetch<MealTimePreference[]>(API_ROUTES.preferences.mealTimes);
}

export async function updateMealTimePreferences(
    prefs: MealTimePreference[],
): Promise<MealTimePreference[]> {
    return apiFetch<MealTimePreference[]>(
        API_ROUTES.preferences.mealTimes,
        {
            method: 'PUT',
            body: JSON.stringify(prefs),
        },
    );
}

export type IngredientPreferenceKind =
    | 'FAVORITE'
    | 'DISLIKED'
    | 'ALLERGY'
    | 'EXCLUDED';

export interface IngredientPreference {
    ingredientId: string;
    ingredientName: string;
    kind: IngredientPreferenceKind;
}

type IngredientShortDto = {
    id: string;
    nameUk: string;
    nameEn: string;
    category: string;
    defaultUnit: 'GRAM' | 'MILLILITER' | 'PIECE';
};

type IngredientPreferencesDto = {
    favorites: IngredientShortDto[];
    disliked: IngredientShortDto[];
    allergies: IngredientShortDto[];
    exclusions: IngredientShortDto[];
};

type IngredientPreferencesUpdateRequest = {
    favoriteIngredientIds: string[];
    dislikedIngredientIds: string[];
    allergyIngredientIds: string[];
    exclusionIngredientIds: string[];
};

function mapIngredientPreferencesDto(
    dto: IngredientPreferencesDto | null | undefined,
): IngredientPreference[] {
    if (!dto) return [];

    const result: IngredientPreference[] = [];

    for (const item of dto.favorites ?? []) {
        result.push({
            ingredientId: item.id,
            ingredientName: item.nameUk || item.nameEn,
            kind: 'FAVORITE',
        });
    }

    for (const item of dto.disliked ?? []) {
        result.push({
            ingredientId: item.id,
            ingredientName: item.nameUk || item.nameEn,
            kind: 'DISLIKED',
        });
    }

    for (const item of dto.allergies ?? []) {
        result.push({
            ingredientId: item.id,
            ingredientName: item.nameUk || item.nameEn,
            kind: 'ALLERGY',
        });
    }

    for (const item of dto.exclusions ?? []) {
        result.push({
            ingredientId: item.id,
            ingredientName: item.nameUk || item.nameEn,
            kind: 'EXCLUDED',
        });
    }

    return result;
}

export async function getIngredientPreferences(): Promise<IngredientPreference[]> {
    const dto = await apiFetch<IngredientPreferencesDto | null>(
        API_ROUTES.preferences.ingredients,
    );

    return mapIngredientPreferencesDto(dto);
}

export async function updateIngredientPreferences(
    prefs: IngredientPreference[],
): Promise<IngredientPreference[]> {
    const favoriteIngredientIds = prefs
        .filter((p) => p.kind === 'FAVORITE')
        .map((p) => p.ingredientId);

    const dislikedIngredientIds = prefs
        .filter((p) => p.kind === 'DISLIKED')
        .map((p) => p.ingredientId);

    const allergyIngredientIds = prefs
        .filter((p) => p.kind === 'ALLERGY')
        .map((p) => p.ingredientId);

    const exclusionIngredientIds = prefs
        .filter((p) => p.kind === 'EXCLUDED')
        .map((p) => p.ingredientId);

    const payload: IngredientPreferencesUpdateRequest = {
        favoriteIngredientIds,
        dislikedIngredientIds,
        allergyIngredientIds,
        exclusionIngredientIds,
    };

    const dto = await apiFetch<IngredientPreferencesDto>(
        API_ROUTES.preferences.ingredients,
        {
            method: 'PUT',
            body: JSON.stringify(payload),
        },
    );

    return mapIngredientPreferencesDto(dto);
}

export type DayOfWeek =
    | 'MONDAY'
    | 'TUESDAY'
    | 'WEDNESDAY'
    | 'THURSDAY'
    | 'FRIDAY'
    | 'SATURDAY'
    | 'SUNDAY';

export interface MealScheduleEntry {
    dayOfWeek: DayOfWeek;
    mealType: MealType;
    servingsOverride: number | null;
}

export async function getMealSchedule(): Promise<MealScheduleEntry[]> {
    return apiFetch<MealScheduleEntry[]>(
        API_ROUTES.preferences.mealSchedule,
    );
}

export async function updateMealSchedule(
    entries: MealScheduleEntry[],
): Promise<MealScheduleEntry[]> {
    return apiFetch<MealScheduleEntry[]>(
        API_ROUTES.preferences.mealSchedule,
        {
            method: 'PUT',
            body: JSON.stringify(entries),
        },
    );
}
