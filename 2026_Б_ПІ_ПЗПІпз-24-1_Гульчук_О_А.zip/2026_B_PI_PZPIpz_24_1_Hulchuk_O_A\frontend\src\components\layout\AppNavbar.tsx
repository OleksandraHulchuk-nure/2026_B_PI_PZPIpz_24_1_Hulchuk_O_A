﻿'use client';

import Link from 'next/link';
import {usePathname} from 'next/navigation';
import * as React from 'react';

import {ThemeToggle} from '@/components/layout/ThemeToggle';
import {Button} from '@/components/ui/button';
import {useLogout} from '@/lib/auth/useLogout';
import {cn} from '@/lib/utils';

const navItems = [
    {href: '/', label: 'Головна', icon: 'dashboard_2'},
    {href: '/recipes', label: 'Рецепти', icon: 'book_4'},
    {href: '/weekly-menu', label: 'План на тиждень', icon: 'calendar_month'},
    {href: '/shopping-list', label: 'Продукти', icon: 'shopping_cart'},
    {href: '/stats', label: 'Статистика', icon: 'query_stats'},
    {href: '/profile', label: 'Профіль', icon: 'manage_accounts'},
] as const;

function isActivePath(pathname: string, href: string) {
    return href === '/' ? pathname === '/' : pathname.startsWith(href);
}

interface BrandLinkProps {
    onClick?: () => void;
    className?: string;
    showSubtitle?: boolean;
}

function BrandLink({onClick, className, showSubtitle = true}: BrandLinkProps) {
    return (
        <Link href="/" onClick={onClick} className={cn('flex min-w-0 items-center gap-3', className)}>
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[18px] bg-primary text-text-inverted shadow-[0_18px_34px_-24px_rgba(16,22,27,0.66)]">
                <span className="material-symbols-outlined text-[22px] leading-none">skillet_cooktop</span>
            </span>

            <div className="min-w-0">
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-primary">WhatWeCook</p>
                {showSubtitle ? (
                    <p className="mt-1 truncate text-sm text-text-muted">Планування меню</p>
                ) : null}
            </div>
        </Link>
    );
}

interface NavigationLinksProps {
    pathname: string;
    onNavigate?: () => void;
}

function NavigationLinks({pathname, onNavigate}: NavigationLinksProps) {
    return (
        <nav className="space-y-1.5">
            {navItems.map((item) => {
                const active = isActivePath(pathname, item.href);

                return (
                    <Link
                        key={item.href}
                        href={item.href}
                        onClick={onNavigate}
                        aria-current={active ? 'page' : undefined}
                        className={cn(
                            'group flex items-center gap-3 rounded-[20px] px-3 py-3 transition duration-200',
                            active
                                ? 'bg-primary text-text-inverted shadow-[0_18px_36px_-24px_rgba(16,22,27,0.72)]'
                                : 'text-text-muted hover:bg-background/80 hover:text-text-primary',
                        )}
                    >
                        <span
                            className={cn(
                                'flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border transition',
                                active
                                    ? 'border-white/15 bg-white/12 text-text-inverted'
                                    : 'border-border/70 bg-surface text-primary group-hover:border-primary/20 group-hover:bg-primary-soft',
                            )}
                        >
                            <span className="material-symbols-outlined text-[20px] leading-none">{item.icon}</span>
                        </span>

                        <span className={cn('text-sm font-semibold', active ? 'text-text-inverted' : 'text-text-primary')}>
                            {item.label}
                        </span>
                    </Link>
                );
            })}
        </nav>
    );
}

interface SidebarContentProps {
    pathname: string;
    isLoggingOut: boolean;
    logout: () => void;
    onNavigate?: () => void;
}

function SidebarContent({pathname, isLoggingOut, logout, onNavigate}: SidebarContentProps) {
    return (
        <>
            <div className="min-h-0 flex-1 overflow-y-auto pr-1">
                <NavigationLinks pathname={pathname} onNavigate={onNavigate}/>
            </div>

            <div className="mt-4 border-t border-border/70 pt-4">
                <div className="flex items-center gap-2">
                    <ThemeToggle/>
                    <Button
                        variant="accentWarm"
                        size="sm"
                        onClick={logout}
                        disabled={isLoggingOut}
                        className="flex-1 justify-center rounded-2xl py-2.5"
                    >
                        {isLoggingOut ? 'Вихід…' : 'Вийти'}
                        <span className="material-symbols-outlined text-[18px] leading-none">logout</span>
                    </Button>
                </div>
            </div>
        </>
    );
}

export function AppNavbar() {
    const pathname = usePathname();
    const {logout, isLoggingOut} = useLogout();
    const [mobileOpen, setMobileOpen] = React.useState(false);

    React.useEffect(() => {
        setMobileOpen(false);
    }, [pathname]);

    React.useEffect(() => {
        if (!mobileOpen) return;

        const previousOverflow = document.body.style.overflow;
        const handleEscape = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                setMobileOpen(false);
            }
        };

        document.body.style.overflow = 'hidden';
        window.addEventListener('keydown', handleEscape);

        return () => {
            document.body.style.overflow = previousOverflow;
            window.removeEventListener('keydown', handleEscape);
        };
    }, [mobileOpen]);

    return (
        <>
            <div className="lg:hidden">
                <div className="sticky top-0 z-30 rounded-[24px] border border-border/70 bg-surface/85 p-3 shadow-[0_24px_80px_-40px_rgba(15,23,42,0.55)] backdrop-blur-xl">
                    <div className="flex items-center justify-between gap-3">
                        <BrandLink showSubtitle={false} className="flex-1"/>

                        <div className="flex items-center gap-2">
                            <ThemeToggle/>
                            <button
                                type="button"
                                aria-label="Відкрити навігацію"
                                onClick={() => setMobileOpen(true)}
                                className="flex h-11 w-11 items-center justify-center rounded-2xl border border-border bg-background/80 text-text-primary transition hover:border-primary/30 hover:bg-primary-soft"
                            >
                                <span className="material-symbols-outlined text-[22px] leading-none">menu</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <aside className="hidden w-[252px] shrink-0 xl:w-[256px] lg:flex">
                <div className="sticky top-6 flex h-[calc(100vh-3rem)] w-full flex-col overflow-hidden rounded-[32px] border border-border/70 bg-surface/80 p-4 shadow-[0_32px_90px_-48px_rgba(15,23,42,0.65)] backdrop-blur-xl">
                    <BrandLink className="px-2 py-1"/>
                    <div className="mt-6 flex min-h-0 flex-1 flex-col">
                        <SidebarContent pathname={pathname} logout={logout} isLoggingOut={isLoggingOut}/>
                    </div>
                </div>
            </aside>

            {mobileOpen ? (
                <div className="lg:hidden">
                    <button
                        type="button"
                        aria-label="Закрити навігацію"
                        onClick={() => setMobileOpen(false)}
                        className="fixed inset-0 z-40 bg-slate-950/45 backdrop-blur-[2px]"
                    />

                    <aside className="fixed inset-y-3 left-3 z-50 flex w-[min(22rem,calc(100vw-1.5rem))] flex-col rounded-[30px] border border-border/70 bg-surface/92 p-4 shadow-[0_30px_90px_-42px_rgba(15,23,42,0.7)] backdrop-blur-xl">
                        <div className="mb-5 flex items-center justify-between gap-3">
                            <BrandLink onClick={() => setMobileOpen(false)} className="flex-1"/>
                            <button
                                type="button"
                                aria-label="Закрити навігацію"
                                onClick={() => setMobileOpen(false)}
                                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-border bg-background/80 text-text-primary transition hover:border-primary/30 hover:bg-primary-soft"
                            >
                                <span className="material-symbols-outlined text-[22px] leading-none">close</span>
                            </button>
                        </div>

                        <SidebarContent
                            pathname={pathname}
                            logout={logout}
                            isLoggingOut={isLoggingOut}
                            onNavigate={() => setMobileOpen(false)}
                        />
                    </aside>
                </div>
            ) : null}
        </>
    );
}
