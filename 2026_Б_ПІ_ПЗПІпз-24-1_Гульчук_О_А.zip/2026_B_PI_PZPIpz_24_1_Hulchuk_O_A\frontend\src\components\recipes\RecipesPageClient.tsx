'use client';

import Link from 'next/link';
import * as React from 'react';

import {PageSection} from '@/components/page-section';
import {Card} from '@/components/ui/card';
import {Button} from '@/components/ui/button';
import {Alert} from '@/components/ui/alert';
import {Badge} from '@/components/ui/badge';
import {PaginationControls} from '@/components/ui/PaginationControls';

import {getRecipes, type RecipeListFilters, type RecipeSearchPage, type RecipeSortDto} from '@/lib/api/recipeApi';
import {ApiError} from '@/lib/api/apiClient';
import {useDebouncedValue} from '@/lib/hooks/useDebouncedValue';
import {RecipeFilters} from '@/components/recipes/RecipeFilters';
import {RecipeTable} from '@/components/recipes/RecipeTable';
import type {RecipeFiltersValue} from '@/components/recipes/types';
import {hasAnyFilters} from '@/components/recipes/utils';

const PAGE_SIZE = 10;
const DEFAULT_SORT: RecipeSortDto = {field: 'CREATED_AT', direction: 'DESC'};

export function RecipesPageClient() {
    const [filtersUi, setFiltersUi] = React.useState<RecipeFiltersValue>({
        status: '',
        sourceType: '',
        mealType: '',
        maxTime: '',
        search: '',
    });

    const debouncedSearch = useDebouncedValue(filtersUi.search.trim(), 350);

    const baseFilters = React.useMemo<Omit<RecipeListFilters, 'page' | 'size' | 'sort'>>(() => {
        return {
            status: filtersUi.status || undefined,
            sourceType: filtersUi.sourceType || undefined,
            mealType: filtersUi.mealType || undefined,
            maxTime: typeof filtersUi.maxTime === 'number' ? filtersUi.maxTime : undefined,
            search: debouncedSearch ? debouncedSearch : undefined,
        };
    }, [filtersUi.status, filtersUi.sourceType, filtersUi.mealType, filtersUi.maxTime, debouncedSearch]);

    const [page, setPage] = React.useState(0);
    const [sort, setSort] = React.useState<RecipeSortDto>(DEFAULT_SORT);

    const [data, setData] = React.useState<RecipeSearchPage | null>(null);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState<{ message: string; status?: number } | null>(null);

    React.useEffect(() => {
        setPage(0);
    }, [baseFilters.status, baseFilters.sourceType, baseFilters.mealType, baseFilters.maxTime, baseFilters.search]);

    const fetchRecipes = React.useCallback(async () => {
        setLoading(true);
        setError(null);

        try {
            const resp = await getRecipes({
                ...baseFilters,
                page,
                size: PAGE_SIZE,
                sort,
            });
            setData(resp);
        } catch (e) {
            const err = e as unknown;
            if (err instanceof ApiError) setError({message: err.message, status: err.status});
            else setError({message: 'Сталася помилка. Спробуйте ще раз.'});
        } finally {
            setLoading(false);
        }
    }, [baseFilters, page, sort]);

    React.useEffect(() => {
        void fetchRecipes();
    }, [fetchRecipes]);

    const resetFilters = () => {
        setFiltersUi({status: '', sourceType: '', mealType: '', maxTime: '', search: ''});
        setPage(0);
        setSort(DEFAULT_SORT);
    };

    const anyFilters = hasAnyFilters(filtersUi);

    const totalCount = data?.totalCount ?? 0;
    const items = data?.items ?? [];
    const hasNext = data?.hasNext ?? false;

    const totalPages = totalCount ? Math.max(1, Math.ceil(totalCount / PAGE_SIZE)) : 1;

    const from = totalCount === 0 ? 0 : page * PAGE_SIZE + 1;
    const to = totalCount === 0 ? 0 : Math.min(totalCount, (page + 1) * PAGE_SIZE);

    return (
        <div className="flex flex-col gap-6">
            <PageSection
                titleAs="h2"
                title="Рецепти"
                subtitle="Керуйте власними та AI-рецептами, швидко знаходьте потрібні страви."
                titleAddon={<Badge variant="info">Знайдено: {totalCount}</Badge>}
                actions={
                    <>
                        <Link href="/recipes/new">
                            <Button variant="secondary">Додати рецепт</Button>
                        </Link>
                        <Link href="/recipes/ai">
                            <Button variant="ai">Згенерувати AI-рецепт</Button>
                        </Link>
                    </>
                }
            />

            <RecipeFilters value={filtersUi} onChange={setFiltersUi} onReset={resetFilters}/>

            {loading && <Card className="text-sm text-text-muted">Завантаження рецептів…</Card>}

            {!loading && error && (
                <div className="space-y-3">
                    <Alert variant="error" title="Не вдалося завантажити рецепти">
                        <div className="flex flex-col gap-2">
              <span>
                {error.message}
                  {typeof error.status === 'number' ? ` (HTTP ${error.status})` : null}
              </span>
                            <div>
                                <Button variant="secondary" onClick={fetchRecipes}>
                                    Спробувати ще раз
                                </Button>
                            </div>
                        </div>
                    </Alert>
                </div>
            )}

            {!loading && !error && totalCount === 0 && (
                <Card className="space-y-3">
                    {anyFilters ? (
                        <>
                            <div>
                                <h3 className="text-sm font-semibold">Нічого не знайдено</h3>
                                <p className="mt-1 text-xs text-text-muted">Змініть фільтри або скиньте їх і спробуйте
                                    ще раз.</p>
                            </div>
                            <div className="flex flex-wrap gap-2">
                                <Button variant="secondary" onClick={resetFilters}>
                                    Скинути фільтри
                                </Button>
                            </div>
                        </>
                    ) : (
                        <>
                            <div>
                                <h3 className="text-sm font-semibold">Ще немає рецептів</h3>
                                <p className="mt-1 text-xs text-text-muted">
                                    Додайте manual-рецепт або згенеруйте AI-рецепт — і вони зʼявляться тут.
                                </p>
                            </div>

                            <div className="flex flex-wrap gap-2">
                                <Link href="/recipes/new">
                                    <Button variant="secondary">Додати рецепт</Button>
                                </Link>
                                <Link href="/recipes/ai">
                                    <Button variant="ai">Згенерувати AI-рецепт</Button>
                                </Link>
                            </div>
                        </>
                    )}
                </Card>
            )}

            {!loading && !error && totalCount > 0 && (
                <>
                    <RecipeTable
                        recipes={items}
                        sort={sort}
                        onSortChange={(next) => {
                            setSort(next);
                            setPage(0);
                        }}
                    />

                    <div
                        className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-surface px-4 py-3 text-xs text-text-muted">
                        <div>
                            Показано <span className="font-semibold text-text-primary">{from}</span>–{' '}
                            <span className="font-semibold text-text-primary">{to}</span> із{' '}
                            <span className="font-semibold text-text-primary">{totalCount}</span>
                        </div>

                        <PaginationControls
                            page={page}
                            totalPages={totalPages}
                            hasNext={hasNext}
                            disabled={loading}
                            onPageChange={setPage}
                        />
                    </div>
                </>
            )}
        </div>
    );
}

