package com.nure.whatwecook.service.impl;

import com.nure.whatwecook.config.ai.AiProperties;
import com.nure.whatwecook.domain.entity.ingredient.Ingredient;
import com.nure.whatwecook.domain.entity.profile.User;
import com.nure.whatwecook.domain.entity.profile.UserIngredientPreference;
import com.nure.whatwecook.domain.entity.profile.UserMealPreference;
import com.nure.whatwecook.domain.entity.profile.UserProfile;
import com.nure.whatwecook.domain.entity.recipe.Recipe;
import com.nure.whatwecook.domain.entity.recipe.RecipeIngredient;
import com.nure.whatwecook.domain.enums.IngredientPreferenceType;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MeasurementUnit;
import com.nure.whatwecook.domain.enums.MenuType;
import com.nure.whatwecook.domain.enums.ProductCategory;
import com.nure.whatwecook.dto.ai.AiRecipeDraftDto;
import com.nure.whatwecook.dto.ai.AiRecipeDraftIngredientDto;
import com.nure.whatwecook.dto.ai.AiRecipeGenerateRequestDto;
import com.nure.whatwecook.repository.IngredientRepository;
import com.nure.whatwecook.repository.UserIngredientPreferenceRepository;
import com.nure.whatwecook.repository.UserMealPreferenceRepository;
import com.nure.whatwecook.repository.UserProfileRepository;
import com.nure.whatwecook.service.RecipeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AiRecipeServiceImplTest {

    @Mock
    private ChatModel chatModel;
    @Mock
    private IngredientRepository ingredientRepository;
    @Mock
    private UserProfileRepository userProfileRepository;
    @Mock
    private UserMealPreferenceRepository userMealPreferenceRepository;
    @Mock
    private UserIngredientPreferenceRepository userIngredientPreferenceRepository;
    @Mock
    private RecipeService recipeService;

    private AiRecipeServiceImpl aiRecipeService;

    private final UUID userId = UUID.fromString("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa");
    private final Ingredient potato = Ingredient.builder()
            .id(UUID.fromString("11111111-1111-1111-1111-111111111111"))
            .nameUk("Картопля")
            .category(ProductCategory.VEGETABLES)
            .defaultUnit(MeasurementUnit.GRAM)
            .build();
    private final Ingredient onion = Ingredient.builder()
            .id(UUID.fromString("22222222-2222-2222-2222-222222222222"))
            .nameUk("Цибуля")
            .category(ProductCategory.VEGETABLES)
            .defaultUnit(MeasurementUnit.GRAM)
            .build();

    @BeforeEach
    void setUp() {
        AiProperties aiProperties = new AiProperties();
        aiProperties.setEnabled(true);

        aiRecipeService = new AiRecipeServiceImpl(
                aiProperties,
                fixedProvider(chatModel),
                ingredientRepository,
                userProfileRepository,
                userMealPreferenceRepository,
                userIngredientPreferenceRepository,
                recipeService
        );
    }

    @Test
    void generateRecipeDraftUsesPreferredIngredientsAsSeedsAndResolvesSupportingIngredients() {
        AiRecipeGenerateRequestDto request = new AiRecipeGenerateRequestDto();
        request.setMealType(MealType.BREAKFAST);
        request.setMenuType(MenuType.BALANCED);
        request.setServings(4);
        request.setPreferredIngredientIds(List.of(potato.getId()));

        UserProfile userProfile = UserProfile.builder()
                .userId(userId)
                .familySize(4)
                .simplicity(4)
                .menuType(MenuType.BALANCED)
                .build();
        UserMealPreference mealPreference = UserMealPreference.builder()
                .mealType(MealType.BREAKFAST)
                .maxCookingTimeMinutes(20)
                .build();
        UserIngredientPreference favoritePreference = UserIngredientPreference.builder()
                .user(User.builder().id(userId).build())
                .ingredient(onion)
                .preferenceType(IngredientPreferenceType.FAVORITE)
                .build();

        when(userProfileRepository.findById(userId)).thenReturn(Optional.of(userProfile));
        when(userMealPreferenceRepository.findByUserIdAndMealType(userId, MealType.BREAKFAST))
                .thenReturn(Optional.of(mealPreference));
        when(userIngredientPreferenceRepository.findByUserId(userId)).thenReturn(List.of(favoritePreference));
        when(ingredientRepository.findByIdIn(List.of(potato.getId()))).thenReturn(List.of(potato));
        when(ingredientRepository.findAll(any(Pageable.class))).thenReturn(new PageImpl<>(List.of(potato, onion)));
        when(ingredientRepository.findFirstByNameUkIgnoreCase("Картопля")).thenReturn(Optional.of(potato));
        when(ingredientRepository.findFirstByNameUkIgnoreCase("Цибуля")).thenReturn(Optional.of(onion));

        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse("""
                {
                  "name": "Картопля з цибулею на сніданок",
                  "description": "Проста тепла страва для швидкого сніданку.",
                  "menuType": "BALANCED",
                  "mealType": "BREAKFAST",
                  "activeCookingTimeMinutes": 10,
                  "totalTimeMinutes": 15,
                  "defaultServings": 4,
                  "complexityRating": 1,
                  "steps": [
                    "Наріжте картоплю та цибулю.",
                    "Обсмажте картоплю до м'якості, додайте цибулю і готуйте до золотистості."
                  ],
                  "ingredients": [
                    {
                      "ingredientNameUk": "Картопля",
                      "category": "VEGETABLES",
                      "defaultUnit": "GRAM",
                      "quantity": 500,
                      "unit": "GRAM",
                      "optional": false
                    },
                    {
                      "ingredientNameUk": "Цибуля",
                      "category": "VEGETABLES",
                      "defaultUnit": "GRAM",
                      "quantity": 120,
                      "unit": "GRAM",
                      "optional": false
                    }
                  ]
                }
                """));

        AiRecipeDraftDto draft = aiRecipeService.generateRecipeDraft(userId, request);

        assertThat(draft.getMealType()).isEqualTo(MealType.BREAKFAST);
        assertThat(draft.getMenuType()).isEqualTo(MenuType.BALANCED);
        assertThat(draft.getDefaultServings()).isEqualTo(4);
        assertThat(draft.getIngredients()).hasSize(2);
        assertThat(draft.getIngredients())
                .extracting(AiRecipeDraftIngredientDto::getIngredientId)
                .containsExactlyInAnyOrder(potato.getId(), onion.getId());
        assertThat(draft.getIngredients())
                .extracting(AiRecipeDraftIngredientDto::getIngredientNameUk)
                .containsExactlyInAnyOrder("Картопля", "Цибуля");
    }

    @Test
    void saveGeneratedRecipeCreatesNewIngredientWhenNoDictionaryMatchExists() {
        AiRecipeDraftIngredientDto draftIngredient = new AiRecipeDraftIngredientDto();
        draftIngredient.setIngredientNameUk("Кріп свіжий");
        draftIngredient.setCategory(ProductCategory.OTHER);
        draftIngredient.setDefaultUnit(MeasurementUnit.GRAM);
        draftIngredient.setQuantity(new BigDecimal("20"));
        draftIngredient.setUnit(MeasurementUnit.GRAM);

        AiRecipeDraftDto draft = new AiRecipeDraftDto();
        draft.setName("Картопля з кропом");
        draft.setDescription("Проста страва з зеленню");
        draft.setMealType(MealType.DINNER);
        draft.setMenuType(MenuType.BALANCED);
        draft.setActiveCookingTimeMinutes(15);
        draft.setTotalTimeMinutes(20);
        draft.setDefaultServings(2);
        draft.setComplexityRating(1);
        draft.setSteps(List.of("Відваріть картоплю.", "Додайте кріп і перемішайте."));
        draft.setIngredients(List.of(draftIngredient));

        Ingredient createdIngredient = Ingredient.builder()
                .id(UUID.fromString("33333333-3333-3333-3333-333333333333"))
                .nameUk("Кріп свіжий")
                .category(ProductCategory.OTHER)
                .defaultUnit(MeasurementUnit.GRAM)
                .build();
        Recipe savedRecipe = Recipe.builder()
                .id(UUID.fromString("44444444-4444-4444-4444-444444444444"))
                .name(draft.getName())
                .build();

        when(ingredientRepository.findFirstByNameUkIgnoreCase("Кріп свіжий")).thenReturn(Optional.empty());
        when(ingredientRepository.searchIngredientMatches(anyString(), any(), anyDouble())).thenReturn(List.of());
        when(ingredientRepository.save(any(Ingredient.class))).thenReturn(createdIngredient);
        when(recipeService.createAiRecipe(any(UUID.class), any(Recipe.class), any(List.class))).thenReturn(savedRecipe);

        Recipe result = aiRecipeService.saveGeneratedRecipe(userId, draft);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<RecipeIngredient>> ingredientsCaptor = ArgumentCaptor.forClass(List.class);
        verify(recipeService).createAiRecipe(any(UUID.class), any(Recipe.class), ingredientsCaptor.capture());

        assertThat(result).isSameAs(savedRecipe);
        assertThat(ingredientsCaptor.getValue()).hasSize(1);
        assertThat(ingredientsCaptor.getValue().get(0).getIngredient().getId()).isEqualTo(createdIngredient.getId());
        assertThat(ingredientsCaptor.getValue().get(0).getUnit()).isEqualTo(MeasurementUnit.GRAM);
        assertThat(ingredientsCaptor.getValue().get(0).getQuantity()).isEqualByComparingTo("20");
        verify(ingredientRepository).save(any(Ingredient.class));
    }

    private ChatResponse chatResponse(String content) {
        return new ChatResponse(List.of(new Generation(new AssistantMessage(content))));
    }

    private ObjectProvider<ChatModel> fixedProvider(ChatModel chatModel) {
        return new ObjectProvider<>() {
            @Override
            public ChatModel getObject() {
                return chatModel;
            }

            @Override
            public ChatModel getIfAvailable() {
                return chatModel;
            }
        };
    }
}
