package com.nure.whatwecook.dto.reports;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

public record WeeklyMenuQualityStatDto(
        UUID weeklyMenuId,
        UUID userId,
        LocalDate startDate,
        String status,

        BigDecimal avgTotalTimeMinutes,
        BigDecimal avgTotalTimeMinutesPerDay,
        BigDecimal avgComplexityRating,

        Integer mealsWithRecipeCnt,

        Integer verifiedMealsCnt,
        Integer toVerifyMealsCnt,
        Integer rejectedMealsCnt,
        BigDecimal verifiedPct
) {}
