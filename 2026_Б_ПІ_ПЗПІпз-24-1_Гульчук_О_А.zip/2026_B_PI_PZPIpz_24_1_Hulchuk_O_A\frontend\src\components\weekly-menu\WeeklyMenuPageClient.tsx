'use client';

import {useEffect, useMemo, useState} from 'react';

import {Alert} from '@/components/ui/alert';
import {Badge} from '@/components/ui/badge';
import {Button} from '@/components/ui/button';
import {Card} from '@/components/ui/card';
import {PageSection} from '@/components/page-section';
import {WeekSelector} from "@/components/week-selector/WeekSelector";

import * as weeklyMenuApi from '@/lib/api/weeklyMenuApi';
import {ApiError} from '@/lib/api/apiClient';
import {formatWeekRange, startOfWeek, toIsoDate} from '@/lib/utils/date';
import {MEAL_TYPES, MENU_STATUS_LABELS, menuStatusBadgeVariant} from '@/lib/constants/enums';
import WeeklyMenuGrid, {SlotRef} from '@/components/weekly-menu/WeeklyMenuGrid';
import ReplaceRecipeDialog from '@/components/weekly-menu/ReplaceRecipeDialog';
import ConfirmApproveDialog from "@/components/ui/confirmDialog";
import {RecipeQuickViewDialog} from '@/components/weekly-menu/RecipeQuickViewDialog';
import {downloadWeeklyMenuReport} from "@/lib/api/reportsApi";
import {downloadBlob} from "@/lib/utils/download";

type UiStatus = 'idle' | 'loading' | 'error' | 'success';


export default function WeeklyMenuPageClient() {
    const currentWeekStart = useMemo(() => toIsoDate(startOfWeek(new Date())), []);
    const [weekStart, setWeekStart] = useState<string>(currentWeekStart);

    const [menuLoading, setMenuLoading] = useState<boolean>(false);

    const [menu, setMenu] = useState<weeklyMenuApi.WeeklyMenuResponseDto | null>(null);
    const [menuStatus, setMenuStatus] = useState<UiStatus>('idle');
    const [menuError, setMenuError] = useState<string>('');
    const [toast, setToast] = useState<string>('');

    const [replaceOpen, setReplaceOpen] = useState(false);
    const [activeSlot, setActiveSlot] = useState<SlotRef | null>(null);

    const [approveConfirmOpen, setApproveConfirmOpen] = useState(false);

    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewRecipeId, setPreviewRecipeId] = useState<string | null>(null);

    const [reportLoading, setReportLoading] = useState(false);

    const isReadOnly = menu?.status === 'APPROVED';
    const isPastWeek = weekStart < currentWeekStart;
    const isBusy = menuStatus === 'loading' || menuLoading || reportLoading;

    async function loadMenuByStartDate(startDate: string) {
        setMenuLoading(true);
        setMenu(null);
        setMenuError('');
        setToast('');
        try {
            const data = await weeklyMenuApi.getWeeklyMenuByStartDate(startDate);
            setMenu(data);
            setMenuLoading(false);
            return data;
        } catch (e) {
            if (e instanceof ApiError && e.status === 404) {
                setMenu(null);
                setMenuLoading(false);
                return null;
            }

            setMenuLoading(false);
            setMenuError(e instanceof Error ? e.message : 'Не вдалося завантажити меню цього тижня.');
            setMenu(null);
            return null;
        }
    }

    useEffect(() => {
        void loadMenuByStartDate(weekStart);
    }, [weekStart]);

    async function handleGenerate() {
        setMenuStatus('loading');
        setMenuError('');
        setToast('');
        try {
            const generated = await weeklyMenuApi.generateWeeklyMenu({
                startDate: weekStart,
                days: 7,
                mealsPerDay: MEAL_TYPES,
                useProfilePreferences: true,
            });

            setMenu(generated);
            setToast('Меню згенеровано.');
            setMenuStatus('success');
        } catch (e) {
            setMenuStatus('error');
            setMenuError(e instanceof Error ? e.message : 'Не вдалося згенерувати меню. Спробуйте ще раз.');
        }
    }

    function requestApprove() {
        if (!menu || isReadOnly || isBusy) return;
        setMenuError('');
        setToast('');
        setApproveConfirmOpen(true);
    }

    async function confirmApprove() {
        if (!menu) return;

        setApproveConfirmOpen(false);

        setMenuStatus('loading');
        setMenuError('');
        setToast('');
        try {
            const approved = await weeklyMenuApi.approveWeeklyMenu(menu.id);
            setMenu(approved);
            setToast('Меню підтверджено. Тепер його не можна редагувати.');
            setMenuStatus('success');
        } catch (e) {
            setMenuStatus('error');
            setMenuError(e instanceof Error ? e.message : 'Не вдалося підтвердити меню.');
        }
    }

    function openReplace(slot: SlotRef) {
        if (isReadOnly) return;
        setActiveSlot(slot);
        setReplaceOpen(true);
    }

    function openPreview(recipeId: string) {
        setPreviewRecipeId(recipeId);
        setPreviewOpen(true);
    }

    async function handleReplace(recipeId: string) {
        if (!menu || !activeSlot) return;
        setMenuStatus('loading');
        setMenuError('');
        setToast('');
        try {
            const updated = await weeklyMenuApi.replaceMenuMeal(menu.id, activeSlot.slotId, recipeId);
            setMenu(updated);
            setToast('Рецепт у слоті замінено.');
            setReplaceOpen(false);
            setActiveSlot(null);
            setMenuStatus('success');
        } catch (e) {
            setMenuStatus('error');
            setMenuError(e instanceof Error ? e.message : 'Не вдалося замінити рецепт.');
        }
    }

    async function handleDownloadPdf() {
        if (!menu) return;

        setReportLoading(true);
        setMenuError('');
        setToast('');

        try {
            const blob = await downloadWeeklyMenuReport(menu.id);
            downloadBlob(blob, `weekly-menu-${weekStart}.pdf`);
            setToast('PDF звіт з меню готовий для друку.');
        } catch (e) {
            setMenuError(e instanceof Error ? e.message : 'Не вдалося згенерувати PDF меню.');
        } finally {
            setReportLoading(false);
        }
    }

    async function handleAiGenerated() {
        if (!menu || !activeSlot) return;

        setMenuStatus('loading');
        setMenuError('');
        setToast('');

        try {
            await loadMenuByStartDate(weekStart);
            setToast('AI-рецепт згенеровано та підставлено у слот.');
            setMenuStatus('success');
        } catch (e) {
            setMenuStatus('error');
            setMenuError(e instanceof Error ? e.message : 'Не вдалося оновити меню після AI-генерації.');
        }
    }

    return (
        <div className="flex flex-col gap-6">
            <PageSection
                titleAs="h2"
                title={'План на тиждень'}
                subtitle={'Переглядайте весь тиждень одразу й швидко змінюйте окремі страви.'}
                actions={
                    <div className="flex flex-wrap items-center gap-2">
                        <Button
                            variant="primary"
                            onClick={handleGenerate}
                            disabled={isReadOnly || isBusy || isPastWeek}
                            title="Згенерувати меню для обраного тижня"
                        >
                            {menuStatus === 'loading' ? 'Генеруємо…' : 'Згенерувати меню'}
                        </Button>

                        <Button
                            variant="secondary"
                            onClick={requestApprove}
                            disabled={!menu || isReadOnly || isBusy}
                            title="Підтвердити меню (після цього редагування буде вимкнено)"
                        >
                            Підтвердити меню
                        </Button>
                    </div>
                }
            />


            {toast && (
                <Alert variant="success" title="Готово">
                    {toast}
                </Alert>
            )}

            {menuError && (
                <Alert variant="error" title="Помилка">
                    {menuError}{' '}
                    <button className="underline" type="button" onClick={() => void loadMenuByStartDate(weekStart)}>
                        Спробувати ще раз
                    </button>
                </Alert>
            )}

            <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-surface px-4 py-3">
                <div className="flex min-w-0 flex-wrap items-center gap-2">
                    <div className="text-sm font-semibold text-text-primary">Меню</div>
                    <Badge variant="info" className="normal-case tracking-normal">
                        {formatWeekRange(weekStart)}
                    </Badge>
                    {menu ? (
                        <Badge
                            variant={menuStatusBadgeVariant(menu.status)}
                            className="normal-case tracking-normal"
                        >
                            {MENU_STATUS_LABELS[menu.status]}
                        </Badge>
                    ) : null}
                    {menu && isReadOnly ? (
                        <div className="text-xs text-text-muted">
                            Меню підтверджено. Редагування вимкнено.
                        </div>
                    ) : null}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                    {menu ? (
                        <Button
                            variant="secondary"
                            size="sm"
                            onClick={handleDownloadPdf}
                            disabled={isBusy}
                            title="Завантажити PDF для друку"
                        >
                            {reportLoading ? 'Генеруємо PDF…' : 'Завантажити PDF'}
                        </Button>
                    ) : null}

                    <WeekSelector
                        weekStart={weekStart}
                        onChange={setWeekStart}
                        disabled={isBusy}
                        className="items-center gap-2"
                    />
                </div>
            </div>

            {menuLoading ? (
                <Card className="p-6">
                    <div className="text-sm text-text-muted">Завантажуємо меню для вибраного тижня…</div>
                </Card>
            ) : !menu ? (
                <Card className="p-6">
                    <div className="text-sm text-text-muted">
                        Ще немає меню для цього тижня. Згенеруйте план, щоб побачити тижневу матрицю страв.
                    </div>
                    <div className="mt-4">
                        <Button variant="primary" onClick={handleGenerate} disabled={isBusy || isPastWeek}>
                            Згенерувати меню
                        </Button>
                    </div>
                </Card>
            ) : (
                <WeeklyMenuGrid
                    menu={menu}
                    meals={MEAL_TYPES}
                    readOnly={isReadOnly}
                    onOpenReplace={openReplace}
                    onOpenPreview={openPreview}
                />
            )}


            <ReplaceRecipeDialog
                open={replaceOpen}
                slot={activeSlot}
                weeklyMenuId={menu?.id ?? null}
                onClose={() => {
                    setReplaceOpen(false);
                    setActiveSlot(null);
                }}
                onPickRecipe={handleReplace}
                onAiGenerated={handleAiGenerated}
            />

            <ConfirmApproveDialog
                open={approveConfirmOpen}
                weekLabel={formatWeekRange(weekStart)}
                loading={menuStatus === 'loading'}
                onCancel={() => setApproveConfirmOpen(false)}
                onConfirm={confirmApprove}
            />

            <RecipeQuickViewDialog
                open={previewOpen}
                recipeId={previewRecipeId}
                onClose={() => {
                    setPreviewOpen(false);
                    setPreviewRecipeId(null);
                }}
            />
        </div>
    );
}





