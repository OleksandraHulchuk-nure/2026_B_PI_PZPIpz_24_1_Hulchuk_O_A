package com.nure.whatwecook.dto.recipe;

import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MenuType;
import lombok.Data;

import java.util.List;

@Data
public class RecipeUpdateRequestDto {

    private String name;
    private String description;
    private MenuType menuType;
    private MealType mealType;
    private Integer activeCookingTimeMinutes;
    private Integer totalTimeMinutes;
    private Integer defaultServings;
    private List<RecipeIngredientDto> ingredients;
    private List<String> steps;
    private Integer complexityRating;
}
