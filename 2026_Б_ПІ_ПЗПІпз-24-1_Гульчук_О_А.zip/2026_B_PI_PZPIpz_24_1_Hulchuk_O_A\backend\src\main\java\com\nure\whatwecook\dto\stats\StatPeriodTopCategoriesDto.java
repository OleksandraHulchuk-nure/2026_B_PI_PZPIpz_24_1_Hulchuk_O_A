package com.nure.whatwecook.dto.stats;

import java.time.LocalDate;
import java.util.List;

public record StatPeriodTopCategoriesDto(
        LocalDate from,
        LocalDate to,
        Integer limit,
        boolean includeOptional,
        List<ItemDto> items
) {
    public record ItemDto(
            String category,
            Integer itemsCnt
    ) {}
}
