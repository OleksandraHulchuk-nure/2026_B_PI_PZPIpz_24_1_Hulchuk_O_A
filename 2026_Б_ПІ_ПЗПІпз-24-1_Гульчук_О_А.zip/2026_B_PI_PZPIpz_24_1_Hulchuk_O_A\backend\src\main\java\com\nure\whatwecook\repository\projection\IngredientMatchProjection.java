package com.nure.whatwecook.repository.projection;

import java.util.UUID;

public interface IngredientMatchProjection {

    UUID getId();

    String getNameUk();

    String getNameEn();

    String getCategory();

    String getDefaultUnit();

    Double getMatchScore();
}
