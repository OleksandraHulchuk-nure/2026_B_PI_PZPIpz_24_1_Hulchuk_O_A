import type {RecipeFiltersValue} from './types';
import {recipeStatusBadgeVariant} from "@/lib/constants/enums";

export function countActiveFilters(value: RecipeFiltersValue) {
    let n = 0;
    if (value.status) n++;
    if (value.sourceType) n++;
    if (value.mealType) n++;
    if (typeof value.maxTime === 'number') n++;
    if (value.search.trim()) n++;
    return n;
}

export function hasAnyFilters(value: RecipeFiltersValue) {
    return Boolean(
        value.search.trim() ||
        value.status ||
        value.sourceType ||
        value.mealType ||
        typeof value.maxTime === 'number'
    );
}

export const statusBadgeVariant = recipeStatusBadgeVariant;
