package com.nure.whatwecook.dto.shopping;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Data
public class ShoppingListResponseDto {

    private UUID id;
    private List<ShoppingItemDto> items;
    private LocalDate weekStart;
}
