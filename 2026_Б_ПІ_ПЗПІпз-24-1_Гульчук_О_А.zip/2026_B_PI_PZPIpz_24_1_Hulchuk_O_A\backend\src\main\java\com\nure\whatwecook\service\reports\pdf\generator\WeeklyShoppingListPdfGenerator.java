package com.nure.whatwecook.service.reports.pdf.generator;

import com.nure.whatwecook.repository.reports.ShoppingListPrintQueryRepository;
import com.nure.whatwecook.service.helper.pdf.PdfDocument;
import com.nure.whatwecook.service.helper.pdf.PdfRenderService;
import com.nure.whatwecook.service.reports.pdf.PdfReportGenerator;
import com.nure.whatwecook.service.reports.pdf.PdfReportType;
import com.nure.whatwecook.service.reports.pdf.request.WeeklyShoppingListPdfRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class WeeklyShoppingListPdfGenerator implements PdfReportGenerator<WeeklyShoppingListPdfRequest> {

    private final ShoppingListPrintQueryRepository repo;
    private final PdfRenderService pdf;

    @Override
    public PdfReportType type() {
        return PdfReportType.WEEKLY_SHOPPING_LIST;
    }

    @Override
    public Class<WeeklyShoppingListPdfRequest> requestType() {
        return WeeklyShoppingListPdfRequest.class;
    }

    @Override
    public PdfDocument generate(WeeklyShoppingListPdfRequest rq) {
        var dto = repo.loadWeeklyShoppingListReport(rq.userId(), rq.shoppingListId());
        String filename = "shopping-list-" + dto.weekStartDate() + ".pdf";
        byte[] content = pdf.render("reports/shopping-list-weekly", Map.of("model", dto));
        return new PdfDocument(filename, content);
    }
}
