'use client';

import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { BarList, type BarListItem } from '@/components/stats/BarList';
import type { StatPeriodTopCategoriesDto } from '@/lib/api/statsApi';
import { PRODUCT_CATEGORY_LABELS, type ProductCategory } from '@/lib/constants/enums';

function isProductCategory(x: unknown): x is ProductCategory {
    return typeof x === 'string' && x in PRODUCT_CATEGORY_LABELS;
}

export function ShoppingByCategoryCard({ data }: { data?: StatPeriodTopCategoriesDto }) {
    const items = useMemo<BarListItem[]>(() => {
        const rows = data?.items ?? [];

        return rows
            .map((r, idx) => {
                const raw = String(r.category ?? '').trim();
                const label = isProductCategory(raw) ? PRODUCT_CATEGORY_LABELS[raw] : raw || '—';

                const value = typeof r.itemsCnt === 'number' && Number.isFinite(r.itemsCnt) ? r.itemsCnt : 0;
                const sub = `${value} поз.`;

                return { key: `${raw}-${idx}`, label, value, sub };
            })
            .filter((x) => x.label !== '—' && x.value > 0)
            .sort((a, b) => b.value - a.value);
    }, [data]);

    return (
        <Card className="p-0">
            <CardHeader className="flex items-center justify-between">
                <div>
                    <div className="text-sm font-bold">Топ категорій</div>
                    <div className="text-xs text-text-muted">меню в обраному періоді</div>
                </div>
                <span className="material-symbols-outlined text-[18px] leading-none text-text-muted">category</span>
            </CardHeader>

            <CardContent>
                {items.length === 0 ? (
                    <div className="text-xs text-text-muted">Немає даних</div>
                ) : (
                    <BarList items={items} />
                )}
            </CardContent>
        </Card>
    );
}
