const ACCESS_TOKEN_KEY = 'wwc_access_token';
const TOKEN_TYPE_KEY = 'wwc_token_type';

export function saveAuthToken(auth: {
    accessToken: string;
    tokenType: string;
}) {
    if (typeof window === 'undefined') return;
    localStorage.setItem(ACCESS_TOKEN_KEY, auth.accessToken);
    localStorage.setItem(TOKEN_TYPE_KEY, auth.tokenType);
}

export function getAuthToken(): {
    accessToken: string | null;
    tokenType: string | null;
} {
    if (typeof window === 'undefined') {
        return { accessToken: null, tokenType: null };
    }

    return {
        accessToken: localStorage.getItem(ACCESS_TOKEN_KEY),
        tokenType: localStorage.getItem(TOKEN_TYPE_KEY),
    };
}

export function clearAuthToken() {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(ACCESS_TOKEN_KEY);
    localStorage.removeItem(TOKEN_TYPE_KEY);
}
