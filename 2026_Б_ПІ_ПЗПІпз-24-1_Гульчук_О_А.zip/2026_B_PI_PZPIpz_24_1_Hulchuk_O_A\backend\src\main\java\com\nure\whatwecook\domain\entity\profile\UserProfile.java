package com.nure.whatwecook.domain.entity.profile;

import com.nure.whatwecook.domain.enums.MenuType;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "user_profile")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserProfile {

    @Id
    @Column(name = "user_id", nullable = false, updatable = false)
    private UUID userId;

    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "name", length = 255)
    private String name;

    @Column(name = "family_size", nullable = false)
    private Integer familySize;

    @Column(name = "simplicity", nullable = false)
    private Integer simplicity;

    @Enumerated(EnumType.STRING)
    @Column(name = "menu_type", nullable = false, length = 50)
    private MenuType menuType;

    @Column(name = "existing_recipe_ratio", nullable = false)
    private Integer existingRecipeRatio;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    public void prePersist() {
        if (userId == null && user != null) {
            userId = user.getId();
        }

        if (familySize == null) {
            familySize = 1;
        }
        if (simplicity == null) {
            simplicity = 3;
        }
        if (menuType == null) {
            menuType = MenuType.BALANCED;
        }
        if (existingRecipeRatio == null) {
            existingRecipeRatio = 70;
        }

        Instant now = Instant.now();
        if (createdAt == null) {
            createdAt = now;
        }
        if (updatedAt == null) {
            updatedAt = now;
        }
    }

    @PreUpdate
    public void preUpdate() {
        updatedAt = Instant.now();
    }
}
