package com.nure.whatwecook.dto.recipe;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum RecipeSortField {

    CREATED_AT("createdAt"),
    NAME("name"),
    TOTAL_TIME_MINUTES("totalTimeMinutes"),
    TASTE_RATING("tasteRating"),
    COMPLEXITY_RATING("complexityRating");

    private final String property;
}
