package com.nure.whatwecook.dto.profile;

import com.nure.whatwecook.domain.enums.MenuType;
import lombok.Data;

import java.util.UUID;

@Data
public class UserProfileResponseDto {

    private UUID userId;
    private String name;
    private Integer familySize;
    private Integer simplicity;
    private MenuType menuType;
    private Integer existingRecipeRatio;
}
