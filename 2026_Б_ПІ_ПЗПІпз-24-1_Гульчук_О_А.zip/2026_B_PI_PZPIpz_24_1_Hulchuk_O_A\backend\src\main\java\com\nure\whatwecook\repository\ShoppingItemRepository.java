package com.nure.whatwecook.repository;

import com.nure.whatwecook.domain.entity.shopping.ShoppingItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface ShoppingItemRepository extends JpaRepository<ShoppingItem, UUID> {

    List<ShoppingItem> findByShoppingListId(UUID shoppingListId);

    void deleteByShoppingListId(UUID shoppingListId);
}
