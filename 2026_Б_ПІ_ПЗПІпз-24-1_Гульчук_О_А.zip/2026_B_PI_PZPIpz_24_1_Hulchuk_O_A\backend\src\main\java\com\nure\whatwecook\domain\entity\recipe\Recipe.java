package com.nure.whatwecook.domain.entity.recipe;

import com.nure.whatwecook.domain.entity.profile.User;
import com.nure.whatwecook.domain.enums.MealType;
import com.nure.whatwecook.domain.enums.MenuType;
import com.nure.whatwecook.domain.enums.RecipeSourceType;
import com.nure.whatwecook.domain.enums.RecipeStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "recipe")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Recipe {

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "name", nullable = false, length = 255)
    private String name;

    @Column(name = "description", columnDefinition = "text")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "source_type", nullable = false, length = 50)
    private RecipeSourceType sourceType;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 50)
    private RecipeStatus status;

    @Enumerated(EnumType.STRING)
    @Column(name = "menu_type", length = 50)
    private MenuType menuType;

    @Enumerated(EnumType.STRING)
    @Column(name = "meal_type", length = 50)
    private MealType mealType;

    @Column(name = "active_cooking_time_minutes")
    private Integer activeCookingTimeMinutes;

    @Column(name = "total_time_minutes", nullable = false)
    private Integer totalTimeMinutes;

    @Column(name = "default_servings", nullable = false)
    private Integer defaultServings;

    @Column(name = "complexity_rating", nullable = false)
    private Integer complexityRating;

    @Column(name = "taste_rating")
    private Integer tasteRating;

    @Column(name = "rating_comment", columnDefinition = "text")
    private String ratingComment;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @OneToMany(mappedBy = "recipe", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<RecipeIngredient> ingredients = new ArrayList<>();

    @OneToMany(mappedBy = "recipe", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<RecipeImage> images = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "recipe_step", joinColumns = @JoinColumn(name = "recipe_id"))
    @OrderColumn(name = "order_index")
    @Column(name = "description", nullable = false, columnDefinition = "text")
    @Builder.Default
    private List<String> steps = new ArrayList<>();

    @PrePersist
    public void prePersist() {
        if (id == null) {
            id = UUID.randomUUID();
        }
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
        if (this.complexityRating == null) {
            this.complexityRating = 1;
        }
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = Instant.now();
    }
}
