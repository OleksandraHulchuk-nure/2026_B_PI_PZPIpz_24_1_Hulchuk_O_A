package com.nure.whatwecook.domain.enums;

import lombok.Getter;

@Getter
public enum MenuType {

    BALANCED("Збалансоване"),
    VEGETARIAN("Вегетаріанське"),
    MORE_MEAT("Більше м'яса"),
    MORE_FISH("Більше риби"),
    MORE_VEGGIES("Більше овочів");

    private final String ukrainianName;

    MenuType(String ukrainianName) {
        this.ukrainianName = ukrainianName;
    }

}
