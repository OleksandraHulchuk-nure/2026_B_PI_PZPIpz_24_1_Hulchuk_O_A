import ShoppingListEntryClient from '@/components/shopping-list/ShoppingListEntryClient';

export default function ShoppingListEntryPage() {
    return <ShoppingListEntryClient />;
}
