import * as React from "react";

export default function StarRating({
                        value,
                        onChange,
                        disabled,
                        size = 'md',
                    }: {
    value: number;
    onChange?: (v: number) => void;
    disabled?: boolean;
    size?: 'sm' | 'md';
}) {
    const btnSize = size === 'sm' ? 'h-7 w-7' : 'h-8 w-8';
    const iconSize = size === 'sm' ? 'h-4 w-4' : 'h-5 w-5';
    const gap = size === 'sm' ? 'gap-0' : 'gap-0.5';

    const cl = (active: boolean) =>
        [
            'inline-flex items-center justify-center rounded-md',
            disabled ? 'cursor-default' : 'cursor-pointer hover:bg-background/70',
            btnSize,
            active ? 'text-accent-warm' : 'text-border',
        ].join(' ');

    return (
        <div className={`flex items-center ${gap}`}>
            {[1, 2, 3, 4, 5].map((i) => {
                const active = i <= value;
                const isInteractive = Boolean(onChange) && !disabled;

                return (
                    <button
                        key={i}
                        type="button"
                        className={cl(active)}
                        onClick={isInteractive ? () => onChange?.(i) : undefined}
                        disabled={!isInteractive}
                        aria-label={`Оцінка ${i} з 5`}
                        title={`${i}/5`}
                    >
                        <svg
                            viewBox="0 0 24 24"
                            className={iconSize}
                            fill={active ? 'currentColor' : 'none'}
                            stroke="currentColor"
                            strokeWidth="1.5"
                            aria-hidden="true"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M11.48 3.5a.75.75 0 0 1 1.04 0l2.7 2.61c.2.2.47.32.76.35l3.74.37c.7.07.98.93.45 1.4l-2.84 2.5c-.22.19-.33.48-.27.77l.77 3.64c.14.69-.6 1.22-1.2.9l-3.32-1.78a.98.98 0 0 0-.92 0l-3.32 1.78c-.6.32-1.34-.21-1.2-.9l.77-3.64a.94.94 0 0 0-.27-.77l-2.84-2.5c-.53-.47-.25-1.33.45-1.4l3.74-.37c.29-.03.56-.15.76-.35l2.7-2.61Z"
                            />
                        </svg>
                    </button>
                );
            })}
        </div>
    );
}
