package com.nure.whatwecook.dto.menu;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class MenuDayPlanDto {

    private LocalDate date;
    private List<MenuMealPlanDto> meals;
}
