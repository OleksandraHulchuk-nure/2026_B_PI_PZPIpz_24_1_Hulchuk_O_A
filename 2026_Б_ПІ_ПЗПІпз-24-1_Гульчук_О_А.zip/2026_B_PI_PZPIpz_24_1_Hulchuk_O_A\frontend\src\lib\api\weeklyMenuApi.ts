
import {MealType, MenuStatus, MenuType, RecipeSourceType, RecipeStatus} from "@/lib/constants/enums";
import {apiFetch} from "@/lib/api/apiClient";
import {API_ROUTES} from "@/lib/api/endpoints";

export interface RecipeListItemDto {
    id: string;
    name: string;
    sourceType?: RecipeSourceType;
    status?: RecipeStatus;
    menuType?: MenuType;
    mealType?: MealType;
    totalTimeMinutes?: number;
    activeCookingTimeMinutes?: number;
    defaultServings?: number;
    complexityRating?: number;
    tasteRating?: number;
}

export interface MenuMealPlanDto {
    id: string; // slotId
    mealType: MealType;
    recipeId: string;
    recipe?: RecipeListItemDto;
    servings?: number;
}

export interface MenuDayPlanDto {
    date: string; // YYYY-MM-DD
    meals: MenuMealPlanDto[];
}

export interface WeeklyMenuResponseDto {
    id: string;
    startDate: string; // YYYY-MM-DD
    status: MenuStatus;
    days: MenuDayPlanDto[];
}

export interface WeeklyMenuGenerateRequestDto {
    startDate: string; // YYYY-MM-DD
    days?: number;
    mealsPerDay?: MealType[];
    useProfilePreferences?: boolean;
}

export async function getWeeklyMenus(): Promise<WeeklyMenuResponseDto[]> {
    return apiFetch<WeeklyMenuResponseDto[]>(API_ROUTES.weeklyMenus.root, { method: 'GET' });
}

export async function getWeeklyMenu(id: string): Promise<WeeklyMenuResponseDto> {
    return apiFetch<WeeklyMenuResponseDto>(`${API_ROUTES.weeklyMenus.root}/${id}`, { method: 'GET' });
}

export async function getWeeklyMenuByStartDate(startDate: string): Promise<WeeklyMenuResponseDto> {
    return apiFetch<WeeklyMenuResponseDto>(
        `${API_ROUTES.weeklyMenus.byStartDate}?startDate=${startDate}`,
        { method: 'GET' },
    );
}

export async function generateWeeklyMenu(body: WeeklyMenuGenerateRequestDto): Promise<WeeklyMenuResponseDto> {
    return apiFetch<WeeklyMenuResponseDto>(API_ROUTES.weeklyMenus.generate, {
        method: 'POST',
        body: JSON.stringify(body),
    });
}

export async function replaceMenuMeal(menuId: string, slotId: string, recipeId: string): Promise<WeeklyMenuResponseDto> {
    return apiFetch<WeeklyMenuResponseDto>(`${API_ROUTES.weeklyMenus.root}/${menuId}/slots/${slotId}`, {
        method: 'PUT',
        body: JSON.stringify({ recipeId }),
    });
}

export async function approveWeeklyMenu(menuId: string): Promise<WeeklyMenuResponseDto> {
    return apiFetch<WeeklyMenuResponseDto>(`${API_ROUTES.weeklyMenus.root}/${menuId}/approve`, { method: 'POST' });
}
