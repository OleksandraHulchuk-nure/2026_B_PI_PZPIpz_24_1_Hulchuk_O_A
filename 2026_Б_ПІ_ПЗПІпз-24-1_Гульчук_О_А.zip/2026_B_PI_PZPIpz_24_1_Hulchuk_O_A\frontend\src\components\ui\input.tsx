import * as React from 'react';
import { cn } from '@/lib/utils';

export type InputVariant = 'default' | 'error';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
    variant?: InputVariant;
}

export function Input({ className, variant = 'default', ...props }: InputProps) {
    const base =
        'w-full rounded-lg border bg-surface px-3 py-2 ' +
        'text-text-primary placeholder:text-text-muted shadow-sm ' +
        'transition focus-visible:outline-none focus-visible:ring-2 ' +
        'disabled:cursor-not-allowed disabled:opacity-60';

    const variantClasses: Record<InputVariant, string> = {
        default: 'border-border focus-visible:ring-primary-soft',
        error: 'border-error bg-error/5 focus-visible:ring-error/40',
    };

    return (
        <input
            className={cn(base, variantClasses[variant], className)}
            {...props}
        />
    );
}
