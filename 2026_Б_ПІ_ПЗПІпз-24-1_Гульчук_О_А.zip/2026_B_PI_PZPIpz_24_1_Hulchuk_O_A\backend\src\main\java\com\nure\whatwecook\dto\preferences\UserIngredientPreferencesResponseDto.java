package com.nure.whatwecook.dto.preferences;

import com.nure.whatwecook.dto.ingredient.IngredientShortDto;
import lombok.Data;

import java.util.List;

@Data
public class UserIngredientPreferencesResponseDto {

    private List<IngredientShortDto> favorites;
    private List<IngredientShortDto> disliked;
    private List<IngredientShortDto> allergies;
    private List<IngredientShortDto> exclusions;
}
