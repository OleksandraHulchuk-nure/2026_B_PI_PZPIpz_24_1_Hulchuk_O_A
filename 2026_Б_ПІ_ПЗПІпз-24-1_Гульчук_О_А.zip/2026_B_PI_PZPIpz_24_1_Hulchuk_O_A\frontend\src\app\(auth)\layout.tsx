import React from "react";

export default function AuthLayout({
                                       children,
                                   }: {
    children: React.ReactNode;
}) {
    return (
        <div className="min-h-screen bg-background text-text-primary flex items-center justify-center px-4">
            {children}
        </div>
    );
}
