import type { ComponentProps } from 'react';
import type { BadgeProps } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

type MaterialIconVariant = NonNullable<BadgeProps['variant']> | 'default';

type MaterialIconProps = Omit<ComponentProps<'span'>, 'children'> & {
    name: string;
    variant?: MaterialIconVariant;
    label?: string;
};

const variantClasses: Record<MaterialIconVariant, string> = {
    default: 'text-text-muted',

    soft: 'text-primary',
    secondary: 'text-secondary',
    ai: 'text-accent-ai',
    warm: 'text-accent-warm',
    info: 'text-accent-info',
    status: 'text-success',
    statusWarning: 'text-warning',
    statusError: 'text-error',
    outline: 'text-surface',
};

export function MaterialIcon({
                                 name,
                                 variant = 'default',
                                 label,
                                 className,
                                 title,
                                 ...props
                             }: MaterialIconProps) {
    const resolvedTitle = title ?? label;

    return (
        <span
            className={cn(
                'material-symbols-outlined leading-none align-middle select-none',
                variantClasses[variant],
                className,
            )}
            title={resolvedTitle}
            role={label ? 'img' : undefined}
            aria-label={label ?? undefined}
            aria-hidden={label ? undefined : 'true'}
            {...props}
        >
      {name}
    </span>
    );
}
